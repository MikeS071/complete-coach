
  # Complete Coach

  This is a code bundle for Complete Coach. The original project is available at https://www.figma.com/design/g51indcBk3IOhM1jIrh4Pv/Complete-Coach.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  