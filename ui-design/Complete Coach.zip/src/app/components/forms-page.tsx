import { useState } from "react";
import { FormManagement } from "./forms/form-management";
import { FormBuilder } from "./forms/form-builder";

export function FormsPage() {
  const [currentView, setCurrentView] = useState<"management" | "builder">("management");
  const [selectedFormId, setSelectedFormId] = useState<string | null>(null);

  const handleCreateForm = (templateType?: string) => {
    setCurrentView("builder");
    setSelectedFormId(templateType || "new");
  };

  const handleBackToManagement = () => {
    setCurrentView("management");
    setSelectedFormId(null);
  };

  return (
    <>
      {currentView === "management" ? (
        <FormManagement onCreateForm={handleCreateForm} />
      ) : (
        <FormBuilder onBack={handleBackToManagement} formId={selectedFormId} />
      )}
    </>
  );
}
