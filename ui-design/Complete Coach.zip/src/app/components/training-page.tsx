import { Plus, Filter, Search, Calendar, Users, TrendingUp, Clock } from "lucide-react";

export function TrainingPage() {
  const programs = [
    {
      id: 1,
      name: "Elite Strength - Phase 2",
      clients: 12,
      duration: "8 weeks",
      progress: 45,
      nextSession: "Tomorrow, 6:00 AM",
      status: "active",
    },
    {
      id: 2,
      name: "Endurance Foundation",
      clients: 8,
      duration: "12 weeks",
      progress: 30,
      nextSession: "Today, 4:00 PM",
      status: "active",
    },
    {
      id: 3,
      name: "Olympic Weightlifting Prep",
      clients: 5,
      duration: "6 weeks",
      progress: 80,
      nextSession: "Wednesday, 8:00 AM",
      status: "active",
    },
    {
      id: 4,
      name: "Mobility & Recovery",
      clients: 15,
      duration: "4 weeks",
      progress: 60,
      nextSession: "Friday, 10:00 AM",
      status: "active",
    },
  ];

  const recentWorkouts = [
    {
      client: "Marcus Rodriguez",
      program: "Elite Strength - Phase 2",
      date: "2h ago",
      performance: "+8%",
      trend: "up",
    },
    {
      client: "Emma Thompson",
      program: "Endurance Foundation",
      date: "4h ago",
      performance: "+5%",
      trend: "up",
    },
    {
      client: "David Chen",
      program: "Olympic Weightlifting Prep",
      date: "Yesterday",
      performance: "-2%",
      trend: "down",
    },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold mb-2">Training Programs</h2>
          <p className="text-gray-600">Manage workout plans and track athlete progress</p>
        </div>
        <button className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Create Program
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">40</div>
          <div className="text-sm text-gray-600">Active Athletes</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">92%</div>
          <div className="text-sm text-gray-600">Avg. Compliance</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">156</div>
          <div className="text-sm text-gray-600">Sessions This Week</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">2,340</div>
          <div className="text-sm text-gray-600">Hours Trained</div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search programs..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <Filter className="w-4 h-4" />
          Filters
        </button>
      </div>

      {/* Programs Grid */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        {programs.map((program) => (
          <div key={program.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-40 bg-gradient-to-br from-indigo-500 to-purple-600 relative overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1669807164466-10a6584a067e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJlbmd0aCUyMHRyYWluaW5nJTIwd29ya291dCUyMGd5bXxlbnwxfHx8fDE3NzY2NzE0Njh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt={program.name}
                className="w-full h-full object-cover opacity-40"
              />
              <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
                {program.clients} athletes
              </div>
            </div>
            <div className="p-6">
              <h3 className="font-bold text-lg mb-2">{program.name}</h3>
              <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                <span>{program.duration}</span>
                <span>•</span>
                <span>{program.nextSession}</span>
              </div>
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Progress</span>
                  <span className="font-medium">{program.progress}%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div
                    className="bg-indigo-600 h-2 rounded-full transition-all"
                    style={{ width: `${program.progress}%` }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors">
                  View Details
                </button>
                <button className="px-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  Edit
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="font-bold text-lg mb-4">Recent Workout Completions</h3>
        <div className="space-y-4">
          {recentWorkouts.map((workout, i) => (
            <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <span className="font-semibold text-sm">{workout.client.split(' ').map(n => n[0]).join('')}</span>
                </div>
                <div>
                  <div className="font-medium">{workout.client}</div>
                  <div className="text-sm text-gray-500">{workout.program}</div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <span className="text-sm text-gray-500">{workout.date}</span>
                <div className={`flex items-center gap-1 ${workout.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                  <TrendingUp className={`w-4 h-4 ${workout.trend === 'down' ? 'rotate-180' : ''}`} />
                  <span className="font-medium">{workout.performance}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
