import { Search, Plus, Download, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

export function FoodDatabasePage() {
  const [selectedCategory, setSelectedCategory] = useState("All Ingredients");
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");

  const categories = ["All Ingredients", "Proteins", "Carbs", "Fats", "Custom"];

  const ingredients = [
    {
      id: 1,
      name: "Chicken Breast",
      serving: "100g, Boneless",
      image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=200&h=200&fit=crop",
      calories: 165,
      protein: 31,
      carbs: 0,
      fats: 3.6,
      category: "Proteins",
    },
    {
      id: 2,
      name: "Basmati Rice",
      serving: "100g, Long Grain",
      image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=200&h=200&fit=crop",
      calories: 121,
      protein: 3,
      carbs: 25,
      fats: 0.4,
      category: "Carbs",
    },
    {
      id: 3,
      name: "Raw Avocado",
      serving: "100g",
      image: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=200&h=200&fit=crop",
      calories: 160,
      protein: 2,
      carbs: 9,
      fats: 15,
      category: "Fats",
    },
    {
      id: 4,
      name: "Boiled Oats",
      serving: "100g",
      image: "https://images.unsplash.com/photo-1517673132405-a56a62b18caf?w=200&h=200&fit=crop",
      calories: 389,
      protein: 13,
      carbs: 66,
      fats: 7,
      category: "Carbs",
    },
    {
      id: 5,
      name: "Whey Isolate",
      serving: "30g Scoop",
      image: "https://images.unsplash.com/photo-1579722820308-d746b13b215b?w=200&h=200&fit=crop",
      calories: 120,
      protein: 27,
      carbs: 1,
      fats: 0.5,
      category: "Proteins",
    },
  ];

  const filteredIngredients = ingredients
    .filter(ing => selectedCategory === "All Ingredients" || ing.category === selectedCategory)
    .filter(ing =>
      ing.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ing.category.toLowerCase().includes(searchQuery.toLowerCase())
    );

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h2 className="text-3xl font-bold mb-2">Food Database</h2>
            <p className="text-gray-600">
              Curate your custom ingredients or import from verified global libraries.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-2 px-5 py-2.5 bg-white border border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors">
              <Download className="w-4 h-4" />
              Import
            </button>
            <button className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-lg hover:bg-indigo-700 transition-colors">
              <Plus className="w-4 h-4" />
              Create New Food
            </button>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search thousands of ingredients..."
          className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-3 mb-8">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedCategory === category
                ? "bg-orange-500 text-white"
                : "bg-white text-gray-700 border border-gray-200 hover:border-orange-300"
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Info Card */}
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 rounded-xl p-6 mb-8 flex items-center justify-between">
        <div className="text-white flex-1">
          <h3 className="text-xl font-bold mb-2">Unlock Global Food Database</h3>
          <p className="text-indigo-100 text-sm mb-4">
            Access 50,000+ verified ingredients with complete macro breakdowns and international serving sizes
          </p>
          <button className="bg-white text-indigo-700 px-5 py-2 rounded-lg hover:bg-indigo-50 transition-colors font-medium text-sm">
            Sync Now
          </button>
        </div>
        <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center">
          <Database className="w-12 h-12 text-white" />
        </div>
      </div>

      {/* Recent Ingredients Section */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold">Recent Ingredients</h3>
          <span className="text-sm text-gray-500">Showing {filteredIngredients.length} results</span>
        </div>

        {/* Ingredients Grid */}
        <div className="grid grid-cols-4 gap-6">
          {filteredIngredients.map((ingredient) => (
            <div
              key={ingredient.id}
              className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg hover:border-indigo-300 transition-all cursor-pointer group"
            >
              {/* Ingredient Image */}
              <div className="relative mb-4">
                <div className="w-20 h-20 mx-auto bg-gray-100 rounded-full overflow-hidden">
                  <img
                    src={ingredient.image}
                    alt={ingredient.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <button className="absolute top-0 right-0 w-8 h-8 bg-white border border-gray-200 rounded-full flex items-center justify-center hover:bg-indigo-50 hover:border-indigo-300 transition-colors opacity-0 group-hover:opacity-100">
                  <Plus className="w-4 h-4 text-indigo-600" />
                </button>
              </div>

              {/* Ingredient Info */}
              <div className="text-center mb-4">
                <h4 className="font-semibold text-gray-900 mb-1">{ingredient.name}</h4>
                <p className="text-xs text-gray-500">{ingredient.serving}</p>
              </div>

              {/* Macros */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Calories</span>
                  <span className="font-semibold text-gray-900">{ingredient.calories}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Protein</span>
                  <span className="font-semibold text-blue-600">{ingredient.protein}g</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Carbs</span>
                  <span className="font-semibold text-green-600">{ingredient.carbs}g</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Fats</span>
                  <span className="font-semibold text-orange-600">{ingredient.fats}g</span>
                </div>
              </div>
            </div>
          ))}

          {/* Add New Card */}
          <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl p-5 flex flex-col items-center justify-center hover:border-indigo-400 hover:bg-indigo-50 transition-all cursor-pointer group min-h-[280px]">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mb-3 group-hover:bg-indigo-100 transition-colors">
              <Plus className="w-6 h-6 text-gray-400 group-hover:text-indigo-600" />
            </div>
            <h4 className="font-semibold text-gray-700 group-hover:text-indigo-600 transition-colors">
              Add New Ingredient
            </h4>
          </div>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-center gap-2 mt-8">
        <button
          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
          className="w-8 h-8 flex items-center justify-center rounded border border-gray-200 hover:bg-gray-50 transition-colors disabled:opacity-50"
          disabled={currentPage === 1}
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <button className="w-8 h-8 flex items-center justify-center rounded bg-indigo-600 text-white font-medium text-sm">
          1
        </button>
        <button className="w-8 h-8 flex items-center justify-center rounded border border-gray-200 hover:bg-gray-50 transition-colors font-medium text-sm">
          2
        </button>
        <button className="w-8 h-8 flex items-center justify-center rounded border border-gray-200 hover:bg-gray-50 transition-colors font-medium text-sm">
          3
        </button>
        <button className="w-8 h-8 flex items-center justify-center rounded border border-gray-200 hover:bg-gray-50 transition-colors font-medium text-sm">
          12
        </button>
        <button
          onClick={() => setCurrentPage(currentPage + 1)}
          className="w-8 h-8 flex items-center justify-center rounded border border-gray-200 hover:bg-gray-50 transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function Database({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <ellipse cx="12" cy="5" rx="9" ry="3" />
      <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
      <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
    </svg>
  );
}
