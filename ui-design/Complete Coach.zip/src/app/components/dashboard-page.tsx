import { TrendingUp, UserPlus, FileEdit, CreditCard, FileText, Calendar as CalendarIcon, AlertCircle, CheckCircle2, Circle, ChevronDown, X, MessageSquare } from "lucide-react";
import { useState } from "react";
import { DateRange } from "react-day-picker";
import { format } from "date-fns";
import { Calendar } from "./ui/calendar";
import { useNavigate } from "react-router";
import { WorkloadBoard } from "./workload-board";
import { TaskCreationPanel } from "./task-creation-panel";

export function DashboardPage() {
  const navigate = useNavigate();
  const [timePeriod, setTimePeriod] = useState<"weekly" | "monthly" | "quarterly" | "yearly" | "custom">("monthly");
  const [showPeriodDropdown, setShowPeriodDropdown] = useState(false);
  const [showCustomCalendar, setShowCustomCalendar] = useState(false);
  const [customDateRange, setCustomDateRange] = useState<DateRange | undefined>();
  const [showWorkloadBoard, setShowWorkloadBoard] = useState(false);
  const [showTaskCreation, setShowTaskCreation] = useState(false);
  
  const [clientWorkTasks, setClientWorkTasks] = useState([
    { id: 1, text: "Review Jordan's progress check-in", completed: false },
    { id: 2, text: "Update Marcus's meal plan", completed: true },
    { id: 3, text: "Schedule call with Sarah J.", completed: false },
    { id: 4, text: "Send workout adjustments to Emma", completed: false },
  ]);

  const [socialMediaTasks, setSocialMediaTasks] = useState([
    { id: 5, text: "Post transformation Tuesday content", completed: false },
    { id: 6, text: "Respond to DM inquiries", completed: true },
    { id: 7, text: "Schedule week's Instagram stories", completed: false },
    { id: 8, text: "Film testimonial video", completed: false },
  ]);

  const [businessOpsTasks, setBusinessOpsTasks] = useState([
    { id: 9, text: "Process monthly invoices", completed: false },
    { id: 10, text: "Update CRM database", completed: true },
    { id: 11, text: "Review supplement inventory", completed: false },
    { id: 12, text: "Quarterly tax prep review", completed: false },
  ]);

  const toggleTask = (taskId: number, category: 'client' | 'social' | 'business') => {
    if (category === 'client') {
      setClientWorkTasks(tasks =>
        tasks.map(task => task.id === taskId ? { ...task, completed: !task.completed } : task)
      );
    } else if (category === 'social') {
      setSocialMediaTasks(tasks =>
        tasks.map(task => task.id === taskId ? { ...task, completed: !task.completed } : task)
      );
    } else {
      setBusinessOpsTasks(tasks =>
        tasks.map(task => task.id === taskId ? { ...task, completed: !task.completed } : task)
      );
    }
  };

  const handleCreateTask = (task: {
    text: string;
    date: Date | undefined;
    priority: "high" | "medium" | "low";
    category: string;
  }) => {
    const newTask = {
      id: Date.now(),
      text: task.text,
      completed: false,
    };

    switch (task.category) {
      case "current-client-care":
        setClientWorkTasks(prev => [...prev, newTask]);
        break;
      case "social-media":
        setSocialMediaTasks(prev => [...prev, newTask]);
        break;
      case "business-operations":
        setBusinessOpsTasks(prev => [...prev, newTask]);
        break;
      // Client leads don't go to workload board yet
      default:
        break;
    }
  };

  const teamMembers = [
    "https://images.unsplash.com/photo-1758875569220-6934933d443c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBhdGhsZXRlJTIwZml0bmVzcyUyMGNvYWNofGVufDF8fHx8MTc3NjY3MTM3N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1689600944138-da3b150d9cb8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHdvbWFuJTIwaGVhZHNob3R8ZW58MXx8fHwxNzc2NjE4NzU1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1530029081-120107a0c377?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwYXRobGV0ZSUyMHBvcnRyYWl0fGVufDF8fHx8MTc3NjY3MTM3OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  ];

  const pipelineItems = [
    {
      id: 1,
      type: "payment",
      title: "Payment Secured",
      description: "Leo G. has paid for Platinum tier...",
      time: "4m ago",
      color: "bg-green-50 text-green-600",
      icon: CreditCard,
    },
    {
      id: 2,
      type: "form",
      title: "Form Received",
      description: "Elena Rossi submitted health wai...",
      time: "22m ago",
      color: "bg-blue-50 text-blue-600",
      icon: FileText,
    },
    {
      id: 3,
      type: "call",
      title: "Call Scheduled",
      description: "Initial consult booked for Marcus...",
      time: "2h ago",
      color: "bg-gray-50 text-gray-600",
      icon: CalendarIcon,
    },
  ];

  // Financial data based on time period
  const financialData = {
    weekly: {
      label: "Weekly Revenue",
      value: "$6,212",
      change: "+8.2%",
      bars: [65, 70, 85, 60, 75, 80, 90],
    },
    monthly: {
      label: "Monthly Revenue",
      value: "$24,850",
      change: "+12.5%",
      bars: [30, 35, 25, 40, 32, 38, 28, 42, 36, 45, 50, 65, 70, 85],
    },
    quarterly: {
      label: "Quarterly Revenue",
      value: "$74,550",
      change: "+18.3%",
      bars: [45, 52, 58, 62, 70, 75, 80, 85, 88, 92, 90, 95],
    },
    yearly: {
      label: "Yearly Revenue",
      value: "$298,200",
      change: "+24.7%",
      bars: [40, 42, 45, 50, 55, 58, 62, 68, 72, 78, 85, 95],
    },
    custom: {
      label: "Custom Period",
      value: "$18,420",
      change: "+10.1%",
      bars: [50, 55, 48, 60, 58, 65, 70, 75, 72, 80, 85, 90],
    },
  };

  const currentFinancialData = financialData[timePeriod];

  const periodOptions: Array<{ value: typeof timePeriod; label: string }> = [
    { value: "weekly", label: "Weekly" },
    { value: "monthly", label: "Monthly" },
    { value: "quarterly", label: "Quarterly" },
    { value: "yearly", label: "Yearly" },
    { value: "custom", label: "Custom" },
  ];

  return (
    <div className="p-8">
      {/* Page Title */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Coach Operations Dashboard</h2>
        <p className="text-gray-600">Monday, October 24th — 12 pipeline actions require attention.</p>
      </div>

      {/* Top Row - Metrics & Team */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        {/* Financial Analytics with Time Period Filter */}
        <div className="bg-white rounded-xl p-6 border border-gray-200 relative">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-gray-500 uppercase tracking-wider">
              {currentFinancialData.label}
            </span>
            <div className="flex items-center gap-2">
              <span className="text-xs text-green-600 font-medium">
                {currentFinancialData.change}
              </span>
              <div className="relative">
                <button
                  onClick={() => setShowPeriodDropdown(!showPeriodDropdown)}
                  className="flex items-center gap-1 text-xs bg-gray-100 hover:bg-gray-200 px-2 py-1 rounded transition-colors"
                >
                  <span className="capitalize">{timePeriod}</span>
                  <ChevronDown className="w-3 h-3" />
                </button>
                {showPeriodDropdown && (
                  <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-10 min-w-[120px]">
                    {periodOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          if (option.value === "custom") {
                            setShowCustomCalendar(true);
                            setShowPeriodDropdown(false);
                          } else {
                            setTimePeriod(option.value);
                            setShowPeriodDropdown(false);
                          }
                        }}
                        className={`w-full text-left px-3 py-2 text-xs hover:bg-gray-50 transition-colors first:rounded-t-lg last:rounded-b-lg ${
                          timePeriod === option.value ? "bg-indigo-50 text-indigo-600 font-medium" : "text-gray-700"
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                )}
                {showCustomCalendar && (
                  <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-20 p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-sm">Select Date Range</h3>
                      <button
                        onClick={() => setShowCustomCalendar(false)}
                        className="p-1 hover:bg-gray-100 rounded transition-colors"
                      >
                        <X className="w-4 h-4 text-gray-500" />
                      </button>
                    </div>
                    
                    {customDateRange?.from && (
                      <div className="mb-3 p-2 bg-indigo-50 rounded text-center">
                        <p className="text-xs font-medium text-indigo-700">
                          {format(customDateRange.from, "MMM dd, yyyy")}
                          {customDateRange.to && ` - ${format(customDateRange.to, "MMM dd, yyyy")}`}
                        </p>
                      </div>
                    )}

                    <Calendar
                      mode="range"
                      selected={customDateRange}
                      onSelect={setCustomDateRange}
                      numberOfMonths={1}
                      className="rounded-lg"
                    />

                    <div className="flex gap-2 mt-3">
                      <button
                        onClick={() => {
                          setCustomDateRange(undefined);
                          setShowCustomCalendar(false);
                        }}
                        className="flex-1 px-3 py-1.5 border border-gray-200 rounded hover:bg-gray-50 transition-colors text-xs font-medium"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => {
                          if (customDateRange?.from && customDateRange?.to) {
                            setTimePeriod("custom");
                            setShowCustomCalendar(false);
                          }
                        }}
                        disabled={!customDateRange?.from || !customDateRange?.to}
                        className="flex-1 px-3 py-1.5 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-colors text-xs font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="text-3xl font-bold mb-4">{currentFinancialData.value}</div>
          <div className="flex gap-1 h-16 items-end">
            {currentFinancialData.bars.map((height, i) => (
              <div
                key={i}
                className={`flex-1 rounded-t transition-all ${
                  i >= currentFinancialData.bars.length - 2 ? "bg-indigo-600" : "bg-gray-200"
                }`}
                style={{ height: `${height}%` }}
              />
            ))}
          </div>
        </div>

        {/* Client Capacity */}
        <div 
          onClick={() => navigate("/clients")}
          className="bg-white rounded-xl p-6 border border-gray-200 cursor-pointer hover:shadow-lg hover:border-indigo-200 transition-all"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-gray-500 uppercase tracking-wider">Client Capacity</span>
            <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded">50% LOAD</span>
          </div>
          <div className="mb-4">
            <span className="text-3xl font-bold">42</span>
            <span className="text-gray-400 text-xl">/84</span>
          </div>
          <div className="w-full bg-gray-100 rounded-full h-3 mb-2">
            <div className="bg-indigo-600 h-3 rounded-full" style={{ width: "50%" }} />
          </div>
          <p className="text-xs text-gray-500">Room for 42 more premium athletes</p>
        </div>

        {/* Priority Tasks */}
        <div
          onClick={() => navigate("/clients/check-ins")}
          className="bg-white rounded-xl p-6 border border-gray-200 relative cursor-pointer hover:shadow-lg hover:border-indigo-200 transition-all"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-gray-500 uppercase tracking-wider">CHECK INS</span>
            <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
          </div>
          <div className="mb-6"><span className="text-3xl font-bold">5</span><span className="text-gray-400 text-xl"> Pending</span></div>
          <div className="flex gap-4">
            <div className="flex-1 bg-orange-50 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-orange-600 mb-1">5</div>
              <div className="text-xs text-gray-600 uppercase tracking-wider">Checks</div>
            </div>

          </div>
        </div>
      </div>

      {/* Middle Row - Work To-Do & Live Pipeline */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        {/* Work To-Do - Takes 2 columns */}
        <div className="col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Work To-Do</h3>
            
          </div>

          <div className="grid grid-cols-3 gap-4">
            {/* Client Work */}
            <div className="bg-white rounded-xl p-5 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-sm">Client Work</h4>
                <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded">
                  {clientWorkTasks.filter(t => !t.completed).length}
                </span>
              </div>
              <div className="space-y-2">
                {clientWorkTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-start gap-2 group cursor-pointer"
                    onClick={() => toggleTask(task.id, 'client')}
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-gray-300 group-hover:text-indigo-400 mt-0.5 flex-shrink-0" />
                    )}
                    <span className={`text-xs ${task.completed ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                      {task.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Social Media */}
            <div className="bg-white rounded-xl p-5 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-sm">Social Media</h4>
                <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded">
                  {socialMediaTasks.filter(t => !t.completed).length}
                </span>
              </div>
              <div className="space-y-2">
                {socialMediaTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-start gap-2 group cursor-pointer"
                    onClick={() => toggleTask(task.id, 'social')}
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-gray-300 group-hover:text-purple-400 mt-0.5 flex-shrink-0" />
                    )}
                    <span className={`text-xs ${task.completed ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                      {task.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Business Ops/Admin */}
            <div className="bg-white rounded-xl p-5 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-sm">Business Ops/Admin</h4>
                <span className="text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded">
                  {businessOpsTasks.filter(t => !t.completed).length}
                </span>
              </div>
              <div className="space-y-2">
                {businessOpsTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-start gap-2 group cursor-pointer"
                    onClick={() => toggleTask(task.id, 'business')}
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-gray-300 group-hover:text-orange-400 mt-0.5 flex-shrink-0" />
                    )}
                    <span className={`text-xs ${task.completed ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                      {task.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Live Pipeline */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Client Activity</h3>
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
              12
            </div>
          </div>

          <div className="space-y-3">
            {pipelineItems.map((item) => (
              <div key={item.id} className="bg-white rounded-lg p-4 border border-gray-200 flex items-start gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${item.color}`}>
                  <item.icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="font-medium text-sm mb-1">{item.title}</div>
                  <div className="text-xs text-gray-500 mb-1">{item.description}</div>
                  <div className="text-xs text-gray-400">{item.time}</div>
                </div>
              </div>
            ))}

            <button className="w-full bg-black text-white py-3 rounded-lg text-sm hover:bg-gray-800 transition-colors">FULL CLIENT ACTIVITY</button>

            <div className="grid grid-cols-2 gap-3 mt-4">
              <button
                onClick={() => setShowTaskCreation(true)}
                className="bg-white border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors"
              >
                <div className="text-orange-500 mb-2">
                  <TrendingUp className="w-5 h-5 mx-auto" />
                </div>
                <div className="text-xs font-medium">ADD TASK</div>
              </button>
              <button 
                onClick={() => navigate("/messages")}
                className="bg-white border border-gray-200 rounded-lg p-3 hover:bg-indigo-50 hover:border-indigo-300 transition-colors"
              >
                <div className="text-indigo-600 mb-2">
                  <MessageSquare className="w-5 h-5 mx-auto" />
                </div>
                <div className="text-xs font-medium">MESSAGES</div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row - Pipeline Stall Alert */}

      {/* Workload Management Board */}
      <WorkloadBoard
        isOpen={showWorkloadBoard}
        onClose={() => setShowWorkloadBoard(false)}
        initialTasks={{
          clientWork: clientWorkTasks,
          socialMedia: socialMediaTasks,
          businessOps: businessOpsTasks,
        }}
      />

      {/* Task Creation Panel */}
      <TaskCreationPanel
        isOpen={showTaskCreation}
        onClose={() => setShowTaskCreation(false)}
        onCreateTask={handleCreateTask}
      />
    </div>
  );
}