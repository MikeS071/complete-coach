import { useState } from "react";
import { X, Plus, GripVertical, Trash2 } from "lucide-react";

interface Task {
  id: number;
  text: string;
  category?: string;
  completed?: boolean;
}

interface Column {
  id: string;
  title: string;
  color: string;
  tasks: Task[];
}

interface WorkloadBoardProps {
  isOpen: boolean;
  onClose: () => void;
  initialTasks: {
    clientWork: Task[];
    socialMedia: Task[];
    businessOps: Task[];
  };
}

export function WorkloadBoard({ isOpen, onClose, initialTasks }: WorkloadBoardProps) {
  const [columns, setColumns] = useState<Column[]>([
    {
      id: "client-work",
      title: "Client Work",
      color: "bg-indigo-100 text-indigo-700",
      tasks: initialTasks.clientWork,
    },
    {
      id: "social-media",
      title: "Social Media",
      color: "bg-purple-100 text-purple-700",
      tasks: initialTasks.socialMedia,
    },
    {
      id: "business-ops",
      title: "Business Ops/Admin",
      color: "bg-orange-100 text-orange-700",
      tasks: initialTasks.businessOps,
    },
  ]);

  const [draggedTask, setDraggedTask] = useState<{ task: Task; fromColumn: string } | null>(null);
  const [newTaskColumn, setNewTaskColumn] = useState<string | null>(null);
  const [newTaskText, setNewTaskText] = useState("");
  const [newColumnName, setNewColumnName] = useState("");
  const [showNewColumnInput, setShowNewColumnInput] = useState(false);

  if (!isOpen) return null;

  const handleDragStart = (task: Task, columnId: string) => {
    setDraggedTask({ task, fromColumn: columnId });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (targetColumnId: string) => {
    if (!draggedTask) return;

    const { task, fromColumn } = draggedTask;

    if (fromColumn === targetColumnId) {
      setDraggedTask(null);
      return;
    }

    setColumns((prev) =>
      prev.map((col) => {
        if (col.id === fromColumn) {
          return {
            ...col,
            tasks: col.tasks.filter((t) => t.id !== task.id),
          };
        }
        if (col.id === targetColumnId) {
          return {
            ...col,
            tasks: [...col.tasks, { ...task, category: targetColumnId }],
          };
        }
        return col;
      })
    );

    setDraggedTask(null);
  };

  const addTask = (columnId: string) => {
    if (!newTaskText.trim()) return;

    const newTask: Task = {
      id: Date.now(),
      text: newTaskText,
      category: columnId,
    };

    setColumns((prev) =>
      prev.map((col) =>
        col.id === columnId ? { ...col, tasks: [...col.tasks, newTask] } : col
      )
    );

    setNewTaskText("");
    setNewTaskColumn(null);
  };

  const deleteTask = (taskId: number, columnId: string) => {
    setColumns((prev) =>
      prev.map((col) =>
        col.id === columnId
          ? { ...col, tasks: col.tasks.filter((t) => t.id !== taskId) }
          : col
      )
    );
  };

  const addColumn = () => {
    if (!newColumnName.trim()) return;

    const colors = [
      "bg-pink-100 text-pink-700",
      "bg-blue-100 text-blue-700",
      "bg-green-100 text-green-700",
      "bg-yellow-100 text-yellow-700",
      "bg-red-100 text-red-700",
      "bg-teal-100 text-teal-700",
    ];

    const newColumn: Column = {
      id: `column-${Date.now()}`,
      title: newColumnName,
      color: colors[columns.length % colors.length],
      tasks: [],
    };

    setColumns([...columns, newColumn]);
    setNewColumnName("");
    setShowNewColumnInput(false);
  };

  const deleteColumn = (columnId: string) => {
    if (columns.length <= 1) return; // Keep at least one column
    setColumns((prev) => prev.filter((col) => col.id !== columnId));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Blurred backdrop */}
      <div
        className="absolute inset-0 bg-black/30 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal content */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-7xl max-h-[90vh] overflow-hidden m-4">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-1">Workload Management</h2>
            <p className="text-indigo-100 text-sm">
              Organize and manage all your tasks across categories
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Board */}
        <div className="p-6 overflow-x-auto">
          <div className="flex gap-4 min-h-[600px]">
            {columns.map((column) => (
              <div
                key={column.id}
                className="bg-gray-50 rounded-xl p-4 min-w-[320px] flex flex-col"
                onDragOver={handleDragOver}
                onDrop={() => handleDrop(column.id)}
              >
                {/* Column Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{column.title}</h3>
                    <span className={`text-xs px-2 py-1 rounded ${column.color}`}>
                      {column.tasks.length}
                    </span>
                  </div>
                  {columns.length > 1 && (
                    <button
                      onClick={() => deleteColumn(column.id)}
                      className="p-1 hover:bg-red-100 rounded text-red-600 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Tasks */}
                <div className="flex-1 space-y-2 overflow-y-auto mb-4">
                  {column.tasks.map((task) => (
                    <div
                      key={task.id}
                      draggable
                      onDragStart={() => handleDragStart(task, column.id)}
                      className="bg-white rounded-lg p-3 border border-gray-200 cursor-move hover:shadow-md transition-all group"
                    >
                      <div className="flex items-start gap-2">
                        <GripVertical className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                        <p className="text-sm flex-1">{task.text}</p>
                        <button
                          onClick={() => deleteTask(task.id, column.id)}
                          className="opacity-0 group-hover:opacity-100 p-1 hover:bg-red-50 rounded text-red-500 transition-all"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add Task */}
                {newTaskColumn === column.id ? (
                  <div className="space-y-2">
                    <textarea
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                      placeholder="Enter task description..."
                      className="w-full p-2 border border-gray-300 rounded-lg text-sm resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      rows={3}
                      autoFocus
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={() => addTask(column.id)}
                        className="flex-1 bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
                      >
                        Add Task
                      </button>
                      <button
                        onClick={() => {
                          setNewTaskColumn(null);
                          setNewTaskText("");
                        }}
                        className="px-4 bg-gray-200 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-300 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setNewTaskColumn(column.id)}
                    className="flex items-center justify-center gap-2 w-full py-2 border-2 border-dashed border-gray-300 rounded-lg text-sm text-gray-600 hover:border-indigo-400 hover:text-indigo-600 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    Add Task
                  </button>
                )}
              </div>
            ))}

            {/* Add Column */}
            {showNewColumnInput ? (
              <div className="bg-gray-50 rounded-xl p-4 min-w-[320px]">
                <h3 className="font-semibold mb-4">New Category</h3>
                <input
                  type="text"
                  value={newColumnName}
                  onChange={(e) => setNewColumnName(e.target.value)}
                  placeholder="Category name..."
                  className="w-full p-2 border border-gray-300 rounded-lg text-sm mb-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  autoFocus
                />
                <div className="flex gap-2">
                  <button
                    onClick={addColumn}
                    className="flex-1 bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
                  >
                    Create
                  </button>
                  <button
                    onClick={() => {
                      setShowNewColumnInput(false);
                      setNewColumnName("");
                    }}
                    className="px-4 bg-gray-200 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-300 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setShowNewColumnInput(true)}
                className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl p-4 min-w-[320px] flex flex-col items-center justify-center gap-2 hover:border-indigo-400 hover:bg-indigo-50 transition-colors group"
              >
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center group-hover:bg-indigo-100 transition-colors">
                  <Plus className="w-6 h-6 text-gray-400 group-hover:text-indigo-600" />
                </div>
                <span className="text-sm font-medium text-gray-600 group-hover:text-indigo-600">
                  Add New Category
                </span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
