import { Plus, Play, Eye, ChevronRight } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router";

export function EducationPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"all" | "training" | "nutrition" | "videos">("all");
  const latestResources = [
    {
      id: 1,
      title: "Nutrition Guide",
      image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=400&h=300&fit=crop",
      type: "PDF",
    },
    {
      id: 2,
      title: "Workout Video",
      image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400&h=300&fit=crop",
      type: "Video",
    },
    {
      id: 3,
      title: "Recovery Tips",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop",
      type: "Article",
    },
    {
      id: 4,
      title: "Anatomy Guide",
      image: "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=400&h=300&fit=crop",
      type: "PDF",
    },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-4xl font-bold mb-2">
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Elevate Your Athletes.
            </span>
          </h2>
          <p className="text-gray-600">
            The definitive hub for performance-boosting material. Distribute training guides, nutrition resources, video tutorials to your clients in one centralized library.
          </p>
        </div>
        <button
          onClick={() => navigate("/education/add")}
          className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Create New Resource
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-3 mb-8">
        <button
          onClick={() => setActiveTab("all")}
          className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
            activeTab === "all"
              ? "bg-orange-500 text-white"
              : "bg-white text-gray-700 border border-gray-200 hover:border-orange-300"
          }`}
        >
          All Content
        </button>
        <button
          onClick={() => setActiveTab("training")}
          className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
            activeTab === "training"
              ? "bg-orange-500 text-white"
              : "bg-white text-gray-700 border border-gray-200 hover:border-orange-300"
          }`}
        >
          Training Sessions
        </button>
        <button
          onClick={() => setActiveTab("nutrition")}
          className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
            activeTab === "nutrition"
              ? "bg-orange-500 text-white"
              : "bg-white text-gray-700 border border-gray-200 hover:border-orange-300"
          }`}
        >
          Nutrition Kit
        </button>
        <button
          onClick={() => setActiveTab("videos")}
          className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
            activeTab === "videos"
              ? "bg-orange-500 text-white"
              : "bg-white text-gray-700 border border-gray-200 hover:border-orange-300"
          }`}
        >
          Member Success
        </button>
        <button className="px-5 py-2.5 rounded-full text-sm font-medium bg-white text-gray-700 border border-gray-200 hover:border-orange-300">
          Video Masterclasses
        </button>
      </div>

      {/* Featured Content */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        {/* Main Featured */}
        <div className="col-span-2 bg-gray-900 rounded-2xl overflow-hidden relative h-96 group cursor-pointer">
          <img
            src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&h=600&fit=crop"
            alt="Featured"
            className="w-full h-full object-cover opacity-70 group-hover:opacity-80 transition-opacity"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-xs font-medium mb-3 inline-block">
              Featured Content
            </span>
            <h3 className="text-3xl font-bold text-white mb-3">
              Advanced Hypertrophy Mechanisms & Periodization
            </h3>
            <div className="flex items-center gap-4">
              <button className="bg-white text-gray-900 px-6 py-2.5 rounded-lg hover:bg-gray-100 transition-colors font-medium text-sm flex items-center gap-2">
                <Play className="w-4 h-4" />
                Watch Video
              </button>
              <button className="bg-white/20 backdrop-blur-sm text-white px-6 py-2.5 rounded-lg hover:bg-white/30 transition-colors font-medium text-sm">
                Assign to Client
              </button>
            </div>
          </div>
        </div>

        {/* Side Card */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <h4 className="font-bold text-lg mb-4">Macro Tracking for Performance</h4>
          <p className="text-sm text-gray-600 mb-6">
            A step-by-step guide for how to measure nutrition success for athletes.
          </p>
          <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm flex items-center gap-1">
            Assign Now
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Latest Resources */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold">Latest Resources</h3>
          <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
            View archive →
          </button>
        </div>

        <div className="grid grid-cols-5 gap-4">
          {latestResources.map((resource) => (
            <div
              key={resource.id}
              className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg hover:border-indigo-300 transition-all cursor-pointer group"
            >
              <div className="relative h-32 bg-gray-900 overflow-hidden">
                <img
                  src={resource.image}
                  alt={resource.title}
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors" />
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-xs font-medium text-gray-900">
                  {resource.type}
                </div>
              </div>
              <div className="p-3">
                <h4 className="font-semibold text-sm text-gray-900 line-clamp-2">
                  {resource.title}
                </h4>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
