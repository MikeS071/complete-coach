import { useState } from "react";
import { Search, Filter, ChevronDown, Check } from "lucide-react";

export function CheckInManagementPage() {
  const [activeTab, setActiveTab] = useState<"pending" | "completed">("pending");
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const [sortBy, setSortBy] = useState<"recent" | "oldest" | "name">("recent");

  // Helper function to determine check-in timing status
  const getTimingStatus = (submittedAt: Date, assignedDay: Date) => {
    const deadline = new Date(assignedDay);
    deadline.setHours(9, 0, 0, 0); // 9am deadline

    const assignedDayStart = new Date(assignedDay);
    assignedDayStart.setHours(0, 0, 0, 0);

    // Early: submitted before the assigned day
    if (submittedAt < assignedDayStart) {
      return {
        label: "Early",
        color: "text-blue-600 bg-blue-50",
      };
    }

    // On Time: submitted on assigned day by 9am
    if (submittedAt <= deadline) {
      return {
        label: "On Time",
        color: "text-green-600 bg-green-50",
      };
    }

    // Late: submitted after 9am deadline
    return {
      label: "Late",
      color: "text-red-600 bg-red-50",
    };
  };

  const pendingCheckIns = [
    {
      id: 1,
      name: "Julian Reynolds",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
      submittedAt: new Date(2026, 3, 18, 8, 30), // April 18, 2026, 8:30 AM
      assignedDay: new Date(2026, 3, 18), // April 18, 2026
      lastCheckIn: "2 days ago",
    },
    {
      id: 2,
      name: "Elena Rodriguez",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
      submittedAt: new Date(2026, 3, 19, 10, 15), // April 19, 2026, 10:15 AM
      assignedDay: new Date(2026, 3, 19), // April 19, 2026
      lastCheckIn: "1 day ago",
    },
    {
      id: 3,
      name: "Marcus Chen",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      submittedAt: new Date(2026, 3, 19, 6, 45), // April 19, 2026, 6:45 AM
      assignedDay: new Date(2026, 3, 20), // April 20, 2026
      lastCheckIn: "3 hours ago",
    },
    {
      id: 4,
      name: "Sarah Williams",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
      submittedAt: new Date(2026, 3, 20, 8, 0), // April 20, 2026, 8:00 AM
      assignedDay: new Date(2026, 3, 20), // April 20, 2026
      lastCheckIn: "5 hours ago",
    },
    {
      id: 5,
      name: "David Thompson",
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400",
      submittedAt: new Date(2026, 3, 19, 11, 30), // April 19, 2026, 11:30 AM
      assignedDay: new Date(2026, 3, 19), // April 19, 2026
      lastCheckIn: "1 day ago",
    },
  ];

  const completedCheckIns = [
    {
      id: 6,
      name: "Alex Rivera",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400",
      submittedAt: new Date(2026, 3, 13, 8, 20), // April 13, 2026, 8:20 AM
      assignedDay: new Date(2026, 3, 13), // April 13, 2026
      lastCheckIn: "1 week ago",
    },
    {
      id: 7,
      name: "Jordan Smith",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400",
      submittedAt: new Date(2026, 3, 16, 7, 45), // April 16, 2026, 7:45 AM
      assignedDay: new Date(2026, 3, 16), // April 16, 2026
      lastCheckIn: "4 days ago",
    },
  ];

  const getSortedCheckIns = (checkIns: typeof pendingCheckIns) => {
    const sorted = [...checkIns];
    if (sortBy === "recent") {
      return sorted.sort((a, b) => b.submittedAt.getTime() - a.submittedAt.getTime());
    } else if (sortBy === "oldest") {
      return sorted.sort((a, b) => a.submittedAt.getTime() - b.submittedAt.getTime());
    } else if (sortBy === "name") {
      return sorted.sort((a, b) => a.name.localeCompare(b.name));
    }
    return sorted;
  };

  const displayedCheckIns = getSortedCheckIns(activeTab === "pending" ? pendingCheckIns : completedCheckIns);

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Check In Review Center</h2>
        <p className="text-gray-600"></p>
      </div>

      {/* Tabs and Actions */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveTab("pending")}
            className={`pb-3 px-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "pending"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Pending Review
          </button>
          <button
            onClick={() => setActiveTab("completed")}
            className={`pb-3 px-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "completed"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Completed
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setShowFilterDropdown(!showFilterDropdown)}
              className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm"
            >
              <span className="text-gray-600">
                SORT BY: {sortBy === "recent" ? "Most Recent" : sortBy === "oldest" ? "Oldest First" : "By Name"}
              </span>
              <ChevronDown className="w-4 h-4 text-gray-600" />
            </button>
            {showFilterDropdown && (
              <div className="absolute right-0 top-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10 min-w-[160px]">
                <button
                  onClick={() => {
                    setSortBy("recent");
                    setShowFilterDropdown(false);
                  }}
                  className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors first:rounded-t-lg"
                >
                  Most Recent
                </button>
                <button
                  onClick={() => {
                    setSortBy("oldest");
                    setShowFilterDropdown(false);
                  }}
                  className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors"
                >
                  Oldest First
                </button>
                <button
                  onClick={() => {
                    setSortBy("name");
                    setShowFilterDropdown(false);
                  }}
                  className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors last:rounded-b-lg"
                >
                  By Name
                </button>
              </div>
            )}
          </div>
          <button className="bg-indigo-600 text-white px-5 py-2 rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium">
            Queue First
          </button>
        </div>
      </div>

      {/* Status Info */}
      <div className="mb-6">
        <p className="text-sm text-gray-600">
          Reviewing <span className="font-semibold text-gray-900">{displayedCheckIns.length}</span> pending check-ins
        </p>
      </div>

      {/* Check-Ins List */}
      <div className="space-y-4">
        {displayedCheckIns.map((checkIn) => (
          <div
            key={checkIn.id}
            className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg hover:border-indigo-200 transition-all"
          >
            <div className="flex items-center justify-between">
              {/* Client Info */}
              <div className="flex items-center gap-4">
                <img
                  src={checkIn.avatar}
                  alt={checkIn.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{checkIn.name}</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getTimingStatus(checkIn.submittedAt, checkIn.assignedDay).color}`}>
                      {getTimingStatus(checkIn.submittedAt, checkIn.assignedDay).label}
                    </span>
                    <span className="text-sm text-gray-500">
                      Submitted: {checkIn.submittedAt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} at {checkIn.submittedAt.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3">
                <button className="px-5 py-2.5 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
                  View Full Check-In
                </button>
                {activeTab === "pending" && (
                  null
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* End of List Message */}
      {displayedCheckIns.length > 0 && (
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">End of current pending list</p>
        </div>
      )}
    </div>
  );
}
