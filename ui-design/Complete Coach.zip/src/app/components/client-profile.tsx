import { useParams, Link, useNavigate } from "react-router";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ChevronLeft, MessageSquare, Edit, Calendar as CalendarIcon, Check, X, ChevronRight, GripVertical, Plus, Search, Trash2, Video, Phone, Users, Target } from "lucide-react";
import { useState, useRef } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

type TimeRange = "week" | "month" | "year";
type TabType = "dashboard" | "training" | "nutrition" | "supplementation";
type SelectedDay = "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday" | "sunday" | null;
type EventType = "phase" | "face-to-face" | "video-call" | "phone-call" | "milestone";

interface WorkoutSession {
  type: "strength" | "cardio" | "rest";
  name: string;
  duration?: string;
  notes?: string;
  exercises?: string[];
}

interface Exercise {
  id: string;
  name: string;
  sets: string;
  reps: string;
  rest: string;
  tempo: string;
  notes: string;
  imageUrl?: string;
}

interface WorkoutProgram {
  day: string;
  name: string;
  focus: string;
  duration: string;
  exercises: Exercise[];
}

interface WeeklyProgram {
  [key: string]: WorkoutProgram;
}

interface CalendarEvent {
  id: string;
  type: EventType;
  title: string;
  date: string;
  time?: string;
  duration?: string;
  notes?: string;
  meetingLink?: string;
  location?: string;
}

export function ClientProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState<TimeRange>("month");
  const [activeTab, setActiveTab] = useState<TabType>("dashboard");
  const [showMetricDropdown, setShowMetricDropdown] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date(2026, 3, 20)); // April 20, 2026
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [showWorkoutModal, setShowWorkoutModal] = useState(false);
  const [selectedTrainingDay, setSelectedTrainingDay] = useState<SelectedDay>('monday');
  const [showEditProgramModal, setShowEditProgramModal] = useState(false);
  const [editingWeeklyProgram, setEditingWeeklyProgram] = useState<WeeklyProgram | null>(null);
  const [activeEditDay, setActiveEditDay] = useState<string>("monday");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddEventModal, setShowAddEventModal] = useState(false);
  const [newEvent, setNewEvent] = useState<CalendarEvent>({
    id: "",
    type: "face-to-face",
    title: "",
    date: "",
    time: "",
    duration: "60",
    notes: "",
    meetingLink: "",
    location: ""
  });
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([
    {
      id: "1",
      type: "phase",
      title: "Hypertrophy Phase II",
      date: "2026-04-01",
      notes: "12-week hypertrophy block focusing on progressive overload"
    },
    {
      id: "2",
      type: "video-call",
      title: "Monthly Check-In",
      date: "2026-04-20",
      time: "14:00",
      duration: "30",
      meetingLink: "https://zoom.us/j/example",
      notes: "Review progress and adjust macros"
    }
  ]);

  // Meal Plan State
  const [mealPlans, setMealPlans] = useState([
    {
      id: "1",
      name: "Aggressive Cutting Week 01",
      phase: "Cutting",
      targetCalories: 2850,
      protein: 210,
      carbs: 320,
      fats: 85,
      active: true,
    },
    {
      id: "2",
      name: "Maintenance Phase",
      phase: "Maintenance",
      targetCalories: 3200,
      protein: 185,
      carbs: 380,
      fats: 95,
      active: false,
    },
    {
      id: "3",
      name: "Bulk Phase II",
      phase: "Bulking",
      targetCalories: 3600,
      protein: 220,
      carbs: 450,
      fats: 100,
      active: false,
    },
  ]);
  const [activeMealPlanId, setActiveMealPlanId] = useState("1");
  const [showMealPlanSelector, setShowMealPlanSelector] = useState(false);
  const [showManageMealPlansModal, setShowManageMealPlansModal] = useState(false);
  
  // Refs for workout sections
  const mondayRef = useRef<HTMLDivElement>(null);
  const tuesdayRef = useRef<HTMLDivElement>(null);
  const wednesdayRef = useRef<HTMLDivElement>(null);
  const thursdayRef = useRef<HTMLDivElement>(null);
  const fridayRef = useRef<HTMLDivElement>(null);
  const saturdayRef = useRef<HTMLDivElement>(null);
  const sundayRef = useRef<HTMLDivElement>(null);
  const [activeMetrics, setActiveMetrics] = useState({
    weight: true,
    waist: true,
    calories: false,
    protein: false,
    carbs: false,
    fat: false
  });

  // Mock workout data - in a real app, this would be fetched from a database
  const workoutHistory: Record<string, WorkoutSession> = {
    "2026-04-01": { type: "strength", name: "Upper Power", duration: "75 min", exercises: ["Bench Press 5x5", "Barbell Row 4x8", "Overhead Press 4x6", "Pull-ups 3x10"] },
    "2026-04-03": { type: "strength", name: "Lower Strength", duration: "80 min", exercises: ["Squat 5x5", "Romanian Deadlift 4x8", "Leg Press 3x12", "Leg Curls 3x15"] },
    "2026-04-05": { type: "cardio", name: "HIIT Cardio", duration: "30 min", notes: "Bike intervals: 30s sprint / 90s recovery x 10 rounds" },
    "2026-04-07": { type: "strength", name: "Upper Hypertrophy", duration: "70 min", exercises: ["Incline DB Press 4x10", "Cable Row 4x12", "Lateral Raises 4x15", "Face Pulls 3x20"] },
    "2026-04-10": { type: "strength", name: "Lower Volume", duration: "65 min", exercises: ["Front Squat 4x8", "Bulgarian Split Squat 3x10", "Leg Extensions 3x15", "Calf Raises 4x20"] },
    "2026-04-12": { type: "cardio", name: "Zone 2 Cardio", duration: "45 min", notes: "Steady state rowing at 65% max HR" },
    "2026-04-14": { type: "strength", name: "Upper Power", duration: "75 min", exercises: ["Bench Press 5x5", "Barbell Row 4x8", "Overhead Press 4x6", "Pull-ups 3x10"] },
    "2026-04-16": { type: "strength", name: "Lower Strength", duration: "80 min", exercises: ["Squat 5x5", "Romanian Deadlift 4x8", "Leg Press 3x12", "Leg Curls 3x15"] },
    "2026-04-18": { type: "cardio", name: "Metcon", duration: "25 min", notes: "AMRAP: 10 KB Swings, 8 Box Jumps, 6 Burpees" },
    "2026-04-20": { type: "strength", name: "Upper Hypertrophy", duration: "70 min", exercises: ["Incline DB Press 4x10", "Cable Row 4x12", "Lateral Raises 4x15", "Face Pulls 3x20"] },
    "2026-03-15": { type: "strength", name: "Full Body", duration: "60 min", exercises: ["Deadlift 5x5", "Bench Press 4x8", "Front Squat 3x10"] },
    "2026-03-18": { type: "cardio", name: "Running", duration: "40 min", notes: "Easy run at conversational pace" },
    "2026-03-22": { type: "strength", name: "Upper Focus", duration: "65 min", exercises: ["Overhead Press 5x5", "Weighted Dips 4x8", "Barbell Curl 3x12"] }
  };

  // Mock client data
  const clientData = {
    1: {
      name: "Marcus Rodriguez",
      age: 32,
      weeksWithCoach: 24,
      image: "https://images.unsplash.com/photo-1530029081-120107a0c377?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRpYyUyMG1hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc3NjY3MzYyMnww&ixlib=rb-4.1.0&q=80&w=1080",
      protocol: "Hypertrophy II",
      checkInDay: "Monday",
      bio: "Dedicated performance athlete focusing on functional strength and metabolic conditioning. Current Cycle: Peak Week Phase.",
      currentWeight: 88.4,
      weightChange: -0.4,
      bodyFat: 12.8,
      bodyFatChange: -0.2,
      habitStreak: 14,
      recoveryScore: 92
    },
    2: {
      name: "Emma Thompson",
      age: 28,
      weeksWithCoach: 12,
      image: "https://images.unsplash.com/photo-1580058572462-98e2c0e0e2f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRpYyUyMHdvbWFuJTIwZml0bmVzc3xlbnwxfHx8fDE3NzY2NzM2MjN8MA&ixlib=rb-4.1.0&q=80&w=1080",
      protocol: "Endurance Base",
      checkInDay: "Tuesday",
      bio: "Endurance athlete training for competitive marathons. Current Cycle: Base Building Phase.",
      currentWeight: 62.1,
      weightChange: 0.2,
      bodyFat: 18.5,
      bodyFatChange: -0.5,
      habitStreak: 21,
      recoveryScore: 85
    }
  };

  const client = clientData[id as keyof typeof clientData] || clientData[1];

  // Generate data based on time range
  const generateData = () => {
    if (timeRange === "week") {
      return [
        { date: "Mon", weight: 88.2, waist: 82.1, calories: 2750, protein: 185, carbs: 280, fat: 72 },
        { date: "Tue", weight: 88.3, waist: 82.0, calories: 2800, protein: 190, carbs: 285, fat: 75 },
        { date: "Wed", weight: 88.1, waist: 81.9, calories: 2720, protein: 182, carbs: 275, fat: 70 },
        { date: "Thu", weight: 88.4, waist: 82.0, calories: 2780, protein: 188, carbs: 282, fat: 73 },
        { date: "Fri", weight: 88.2, waist: 81.8, calories: 2740, protein: 184, carbs: 278, fat: 71 },
        { date: "Sat", weight: 88.5, waist: 81.9, calories: 2900, protein: 195, carbs: 295, fat: 78 },
        { date: "Sun", weight: 88.4, waist: 81.7, calories: 2650, protein: 180, carbs: 270, fat: 68 }
      ];
    } else if (timeRange === "month") {
      return [
        { date: "Week 1", weight: 90.2, waist: 83.5, calories: 2820, protein: 190, carbs: 285, fat: 75 },
        { date: "Week 2", weight: 89.8, waist: 83.2, calories: 2780, protein: 188, carbs: 280, fat: 73 },
        { date: "Week 3", weight: 89.5, waist: 82.9, calories: 2750, protein: 185, carbs: 275, fat: 72 },
        { date: "Week 4", weight: 89.1, waist: 82.6, calories: 2720, protein: 183, carbs: 272, fat: 70 },
        { date: "Week 5", weight: 88.9, waist: 82.3, calories: 2700, protein: 180, carbs: 270, fat: 69 },
        { date: "Week 6", weight: 88.7, waist: 82.1, calories: 2680, protein: 178, carbs: 268, fat: 68 },
        { date: "Week 7", weight: 88.6, waist: 81.9, calories: 2660, protein: 175, carbs: 265, fat: 67 },
        { date: "Week 8", weight: 88.4, waist: 81.7, calories: 2750, protein: 185, carbs: 280, fat: 72 }
      ];
    } else {
      return [
        { date: "Jan", weight: 93.5, waist: 86.2, calories: 2900, protein: 195, carbs: 300, fat: 78 },
        { date: "Feb", weight: 92.8, waist: 85.5, calories: 2850, protein: 192, carbs: 295, fat: 76 },
        { date: "Mar", weight: 92.1, waist: 84.9, calories: 2820, protein: 190, carbs: 290, fat: 75 },
        { date: "Apr", weight: 91.4, waist: 84.3, calories: 2780, protein: 188, carbs: 285, fat: 73 },
        { date: "May", weight: 90.7, waist: 83.8, calories: 2750, protein: 185, carbs: 280, fat: 72 },
        { date: "Jun", weight: 90.2, waist: 83.4, calories: 2720, protein: 183, carbs: 275, fat: 70 },
        { date: "Jul", weight: 89.6, waist: 83.0, calories: 2700, protein: 180, carbs: 272, fat: 69 },
        { date: "Aug", weight: 89.1, waist: 82.5, calories: 2680, protein: 178, carbs: 268, fat: 68 },
        { date: "Sep", weight: 88.7, waist: 82.1, calories: 2660, protein: 175, carbs: 265, fat: 67 },
        { date: "Oct", weight: 88.4, waist: 81.7, calories: 2750, protein: 185, carbs: 280, fat: 72 }
      ];
    }
  };

  const chartData = generateData();

  const metricOptions = [
    { key: "weight" as const, label: "Body Weight (kg)", color: "#6366f1" },
    { key: "waist" as const, label: "Waist Circumference (cm)", color: "#f59e0b" },
    { key: "calories" as const, label: "Total Calories/Day", color: "#10b981" },
    { key: "protein" as const, label: "Protein Intake/Day (g)", color: "#ec4899" },
    { key: "carbs" as const, label: "Carbohydrate Intake/Day (g)", color: "#8b5cf6" },
    { key: "fat" as const, label: "Fat Intake/Day (g)", color: "#f97316" }
  ];

  const toggleMetric = (key: keyof typeof activeMetrics) => {
    setActiveMetrics(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Generate calendar days for the current month
  const generateCalendarDays = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    
    const firstDayWeekday = firstDayOfMonth.getDay();
    const adjustedFirstDay = firstDayWeekday === 0 ? 6 : firstDayWeekday - 1; // Monday = 0
    
    const days = [];
    
    // Add empty cells for days before the first of the month
    for (let i = 0; i < adjustedFirstDay; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= lastDayOfMonth.getDate(); day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const calendarDays = generateCalendarDays();

  const getWorkoutForDate = (date: Date | null): WorkoutSession | null => {
    if (!date) return null;
    const dateKey = date.toISOString().split('T')[0];
    return workoutHistory[dateKey] || null;
  };

  const handleDayClick = (date: Date | null) => {
    if (!date) return;
    const workout = getWorkoutForDate(date);
    if (workout) {
      setSelectedDay(date);
      setShowWorkoutModal(true);
    }
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const formatMonthYear = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  const isToday = (date: Date | null) => {
    if (!date) return false;
    const today = new Date(2026, 3, 20); // April 20, 2026
    return date.toDateString() === today.toDateString();
  };

  const selectTrainingDay = (day: SelectedDay) => {
    setSelectedTrainingDay(day);
  };

  // Exercise library for search
  const exerciseLibrary = [
    "Barbell Bench Press", "Incline Dumbbell Press", "Decline Bench Press", "Push-ups", "Dips",
    "Barbell Row", "Dumbbell Row", "Cable Row", "T-Bar Row", "Lat Pulldown",
    "Overhead Press", "Arnold Press", "Lateral Raises", "Front Raises", "Face Pulls",
    "Pull-ups", "Chin-ups", "Assisted Pull-ups", "Band Pull-aparts",
    "Back Squat", "Front Squat", "Goblet Squat", "Leg Press", "Hack Squat",
    "Romanian Deadlift", "Conventional Deadlift", "Sumo Deadlift", "Trap Bar Deadlift",
    "Bulgarian Split Squat", "Walking Lunges", "Reverse Lunges", "Step-ups",
    "Leg Curls", "Leg Extensions", "Calf Raises", "Seated Calf Raises",
    "Barbell Curl", "Dumbbell Curl", "Hammer Curl", "Cable Curl", "Preacher Curl",
    "Tricep Extensions", "Skull Crushers", "Close-Grip Bench", "Tricep Dips",
    "Plank", "Russian Twists", "Dead Bugs", "Ab Wheel", "Hanging Leg Raises"
  ];

  const openEditProgramModal = () => {
    // Create a full weekly program
    const weeklyProgram: WeeklyProgram = {
      monday: {
        day: "Monday",
        name: "Upper Power",
        focus: "Compound movements, low reps, heavy weight",
        duration: "75",
        exercises: [
          { id: "1", name: "Barbell Bench Press", sets: "5", reps: "5", rest: "3 min", tempo: "Controlled", notes: "85% 1RM", imageUrl: "https://images.unsplash.com/photo-1775993703558-e7afab02b7bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZW5jaCUyMHByZXNzJTIwd29ya291dHxlbnwxfHx8fDE3NzY2NzY3NDF8MA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "2", name: "Barbell Row", sets: "4", reps: "8", rest: "2.5 min", tempo: "Controlled", notes: "75% 1RM", imageUrl: "https://images.unsplash.com/photo-1692369608021-c722c4fc7088?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb3dpbmclMjBleGVyY2lzZSUyMGNhYmxlfGVufDF8fHx8MTc3NjY3Njc0MXww&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "3", name: "Overhead Press", sets: "4", reps: "6", rest: "2.5 min", tempo: "Controlled", notes: "80% 1RM", imageUrl: "https://images.unsplash.com/photo-1772450014702-498a8a3f61ae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdmVyaGVhZCUyMHByZXNzJTIwYmFyYmVsbHxlbnwxfHx8fDE3NzY2NzY3MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "4", name: "Pull-ups", sets: "3", reps: "10", rest: "2 min", tempo: "Controlled", notes: "RPE 8", imageUrl: "https://images.unsplash.com/photo-1701826510567-8880c3fa1e98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdWxsJTIwdXBzJTIwZXhlcmNpc2V8ZW58MXx8fHwxNzc2Njc2NzM2fDA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "5", name: "Barbell Curl", sets: "3", reps: "12", rest: "90s", tempo: "2-0-2", notes: "Moderate weight", imageUrl: "https://images.unsplash.com/photo-1759300642647-cfe1e9bf7225?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXJiZWxsJTIwY3VybCUyMGJpY2VwfGVufDF8fHx8MTc3NjY3NjczN3ww&ixlib=rb-4.1.0&q=80&w=1080" }
        ]
      },
      tuesday: {
        day: "Tuesday",
        name: "Lower Power",
        focus: "Heavy squats and deadlifts",
        duration: "80",
        exercises: [
          { id: "6", name: "Back Squat", sets: "5", reps: "5", rest: "3 min", tempo: "Controlled", notes: "85% 1RM", imageUrl: "https://images.unsplash.com/photo-1775993719568-290840203239?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWclMjBwcmVzcyUyMG1hY2hpbmV8ZW58MXx8fHwxNzc2NjI2NzQyfDA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "7", name: "Romanian Deadlift", sets: "4", reps: "8", rest: "2.5 min", tempo: "Controlled", notes: "75% 1RM", imageUrl: "https://images.unsplash.com/photo-1558611848-73f7eb4001a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWFkbGlmdCUyMGJhcmJlbGwlMjBleGVyY2lzZXxlbnwxfHx8fDE3NzY2NzY3Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "8", name: "Leg Press", sets: "4", reps: "12", rest: "2 min", tempo: "Controlled", notes: "Moderate weight", imageUrl: "https://images.unsplash.com/photo-1775993719568-290840203239?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWclMjBwcmVzcyUyMG1hY2hpbmV8ZW58MXx8fHwxNzc2NjI2NzQyfDA&ixlib=rb-4.1.0&q=80&w=1080" }
        ]
      },
      wednesday: {
        day: "Wednesday",
        name: "Rest / Active Recovery",
        focus: "Light cardio or mobility work",
        duration: "30",
        exercises: []
      },
      thursday: {
        day: "Thursday",
        name: "Upper Hypertrophy",
        focus: "Higher volume, moderate weight",
        duration: "70",
        exercises: [
          { id: "9", name: "Incline Dumbbell Press", sets: "4", reps: "12", rest: "90s", tempo: "2-0-2", notes: "RPE 7-8", imageUrl: "https://images.unsplash.com/photo-1600878601444-d5d1e8fa6069?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdW1iYmVsbCUyMHByZXNzJTIwZXhlcmNpc2V8ZW58MXx8fHwxNzc2Njc2NzM3fDA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "10", name: "Cable Row", sets: "4", reps: "15", rest: "90s", tempo: "2-1-2", notes: "Focus on contraction", imageUrl: "https://images.unsplash.com/photo-1692369608021-c722c4fc7088?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb3dpbmclMjBleGVyY2lzZSUyMGNhYmxlfGVufDF8fHx8MTc3NjY3Njc0MXww&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "11", name: "Lateral Raises", sets: "3", reps: "15", rest: "60s", tempo: "2-1-2", notes: "Light weight", imageUrl: "https://images.unsplash.com/photo-1600878601444-d5d1e8fa6069?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdW1iYmVsbCUyMHByZXNzJTIwZXhlcmNpc2V8ZW58MXx8fHwxNzc2Njc2NzM3fDA&ixlib=rb-4.1.0&q=80&w=1080" }
        ]
      },
      friday: {
        day: "Friday",
        name: "Lower Hypertrophy",
        focus: "Higher volume leg work",
        duration: "75",
        exercises: [
          { id: "12", name: "Front Squat", sets: "4", reps: "10", rest: "2 min", tempo: "Controlled", notes: "RPE 7-8", imageUrl: "https://images.unsplash.com/photo-1775993719568-290840203239?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWclMjBwcmVzcyUyMG1hY2hpbmV8ZW58MXx8fHwxNzc2NjI2NzQyfDA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "13", name: "Bulgarian Split Squat", sets: "3", reps: "12", rest: "90s", tempo: "2-1-2", notes: "Each leg", imageUrl: "https://images.unsplash.com/photo-1775993719568-290840203239?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWclMjBwcmVzcyUyMG1hY2hpbmV8ZW58MXx8fHwxNzc2NjI2NzQyfDA&ixlib=rb-4.1.0&q=80&w=1080" },
          { id: "14", name: "Leg Curls", sets: "4", reps: "15", rest: "60s", tempo: "2-1-2", notes: "Focus on contraction", imageUrl: "https://images.unsplash.com/photo-1775993719568-290840203239?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWclMjBwcmVzcyUyMG1hY2hpbmV8ZW58MXx8fHwxNzc2NjI2NzQyfDA&ixlib=rb-4.1.0&q=80&w=1080" }
        ]
      },
      saturday: {
        day: "Saturday",
        name: "Conditioning",
        focus: "Cardio and core work",
        duration: "45",
        exercises: []
      },
      sunday: {
        day: "Sunday",
        name: "Rest Day",
        focus: "Full recovery",
        duration: "0",
        exercises: []
      }
    };
    setEditingWeeklyProgram(weeklyProgram);
    setActiveEditDay("monday");
    setShowEditProgramModal(true);
  };

  const closeEditProgramModal = () => {
    setShowEditProgramModal(false);
    setEditingWeeklyProgram(null);
    setSearchQuery("");
  };

  const saveProgram = () => {
    // In a real app, this would save to database
    console.log("Saving weekly program:", editingWeeklyProgram);
    closeEditProgramModal();
  };

  const updateProgramField = (field: keyof WorkoutProgram, value: string) => {
    if (editingWeeklyProgram && activeEditDay) {
      setEditingWeeklyProgram({
        ...editingWeeklyProgram,
        [activeEditDay]: {
          ...editingWeeklyProgram[activeEditDay],
          [field]: value
        }
      });
    }
  };

  const updateExercise = (exerciseId: string, field: keyof Exercise, value: string) => {
    if (editingWeeklyProgram && activeEditDay) {
      const currentDay = editingWeeklyProgram[activeEditDay];
      setEditingWeeklyProgram({
        ...editingWeeklyProgram,
        [activeEditDay]: {
          ...currentDay,
          exercises: currentDay.exercises.map(ex =>
            ex.id === exerciseId ? { ...ex, [field]: value } : ex
          )
        }
      });
    }
  };

  const removeExercise = (exerciseId: string) => {
    if (editingWeeklyProgram && activeEditDay) {
      const currentDay = editingWeeklyProgram[activeEditDay];
      setEditingWeeklyProgram({
        ...editingWeeklyProgram,
        [activeEditDay]: {
          ...currentDay,
          exercises: currentDay.exercises.filter(ex => ex.id !== exerciseId)
        }
      });
    }
  };

  const addExercise = (exerciseName: string) => {
    if (editingWeeklyProgram && activeEditDay) {
      const currentDay = editingWeeklyProgram[activeEditDay];
      const newExercise: Exercise = {
        id: Date.now().toString(),
        name: exerciseName,
        sets: "3",
        reps: "10",
        rest: "90s",
        tempo: "Controlled",
        notes: "",
        imageUrl: "https://images.unsplash.com/photo-1600878601444-d5d1e8fa6069?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdW1iYmVsbCUyMHByZXNzJTIwZXhlcmNpc2V8ZW58MXx8fHwxNzc2Njc2NzM3fDA&ixlib=rb-4.1.0&q=80&w=1080"
      };
      setEditingWeeklyProgram({
        ...editingWeeklyProgram,
        [activeEditDay]: {
          ...currentDay,
          exercises: [...currentDay.exercises, newExercise]
        }
      });
      setSearchQuery("");
    }
  };

  const moveExercise = (dragIndex: number, hoverIndex: number) => {
    if (editingWeeklyProgram && activeEditDay) {
      const currentDay = editingWeeklyProgram[activeEditDay];
      const updatedExercises = [...currentDay.exercises];
      const [draggedExercise] = updatedExercises.splice(dragIndex, 1);
      updatedExercises.splice(hoverIndex, 0, draggedExercise);
      setEditingWeeklyProgram({ 
        ...editingWeeklyProgram, 
        [activeEditDay]: {
          ...currentDay,
          exercises: updatedExercises
        }
      });
    }
  };

  const filteredExercises = exerciseLibrary.filter(ex =>
    ex.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Event management functions
  const openAddEventModal = () => {
    setNewEvent({
      id: "",
      type: "face-to-face",
      title: "",
      date: new Date(2026, 3, 20).toISOString().split('T')[0],
      time: "10:00",
      duration: "60",
      notes: "",
      meetingLink: "",
      location: ""
    });
    setShowAddEventModal(true);
  };

  const closeAddEventModal = () => {
    setShowAddEventModal(false);
  };

  const updateEventField = (field: keyof CalendarEvent, value: string) => {
    setNewEvent({ ...newEvent, [field]: value });
  };

  const saveEvent = () => {
    const eventToSave = {
      ...newEvent,
      id: Date.now().toString()
    };
    setCalendarEvents([...calendarEvents, eventToSave]);
    closeAddEventModal();
  };

  const getEventsForDate = (date: Date | null): CalendarEvent[] => {
    if (!date) return [];
    const dateKey = date.toISOString().split('T')[0];
    return calendarEvents.filter(event => event.date === dateKey);
  };

  // Draggable Exercise Component
  const DraggableExercise = ({ exercise, index }: { exercise: Exercise; index: number }) => {
    const [{ isDragging }, drag] = useDrag({
      type: "EXERCISE",
      item: { index },
      collect: (monitor) => ({
        isDragging: monitor.isDragging(),
      }),
    });

    const [, drop] = useDrop({
      accept: "EXERCISE",
      hover: (item: { index: number }) => {
        if (item.index !== index) {
          moveExercise(item.index, index);
          item.index = index;
        }
      },
    });

    return (
      <div
        ref={(node) => drag(drop(node))}
        className={`bg-white border border-gray-200 rounded-lg overflow-hidden ${isDragging ? "opacity-50" : ""}`}
      >
        <div className="flex items-start gap-4">
          {/* Exercise Image/Video Thumbnail */}
          {exercise.imageUrl && (
            <div className="w-32 h-32 flex-shrink-0 bg-gray-100 relative">
              <ImageWithFallback
                src={exercise.imageUrl}
                alt={exercise.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-30 transition-opacity">
                <Video className="w-8 h-8 text-white opacity-0 hover:opacity-100 transition-opacity" />
              </div>
            </div>
          )}
          
          {/* Exercise Details */}
          <div className="flex-1 p-4 flex items-start gap-3">
            <div className="mt-1 cursor-move text-gray-400 hover:text-gray-600">
              <GripVertical className="w-5 h-5" />
            </div>
            <div className="flex-1 space-y-3">
              <div className="flex items-center justify-between">
                <input
                  type="text"
                  value={exercise.name}
                  onChange={(e) => updateExercise(exercise.id, "name", e.target.value)}
                  className="font-medium text-sm bg-transparent border-b border-transparent hover:border-gray-300 focus:border-indigo-500 focus:outline-none px-1 -mx-1"
                />
                <button
                  onClick={() => removeExercise(exercise.id)}
                  className="text-red-500 hover:text-red-700 p-1"
                >
                  <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-4 gap-3 text-xs">
              <div>
                <label className="text-gray-500 block mb-1">Sets</label>
                <input
                  type="text"
                  value={exercise.sets}
                  onChange={(e) => updateExercise(exercise.id, "sets", e.target.value)}
                  className="w-full px-2 py-1 border border-gray-300 rounded focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-gray-500 block mb-1">Reps</label>
                <input
                  type="text"
                  value={exercise.reps}
                  onChange={(e) => updateExercise(exercise.id, "reps", e.target.value)}
                  className="w-full px-2 py-1 border border-gray-300 rounded focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-gray-500 block mb-1">Rest</label>
                <input
                  type="text"
                  value={exercise.rest}
                  onChange={(e) => updateExercise(exercise.id, "rest", e.target.value)}
                  className="w-full px-2 py-1 border border-gray-300 rounded focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-gray-500 block mb-1">Tempo</label>
                <input
                  type="text"
                  value={exercise.tempo}
                  onChange={(e) => updateExercise(exercise.id, "tempo", e.target.value)}
                  className="w-full px-2 py-1 border border-gray-300 rounded focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label className="text-gray-500 block mb-1 text-xs">Notes</label>
              <input
                type="text"
                value={exercise.notes}
                onChange={(e) => updateExercise(exercise.id, "notes", e.target.value)}
                placeholder="Additional notes..."
                className="w-full px-2 py-1 border border-gray-300 rounded focus:border-indigo-500 focus:outline-none text-xs"
              />
            </div>
          </div>
          </div>
        </div>
      </div>
    );
  };

  const checkIns = [
    {
      date: "Oct 14, 2024",
      week: "Week 24",
      weight: 88.4,
      notes: "Strong progress on squat volume. Sleep quality improving with new recovery protocol. Energy levels high throughout training sessions."
    },
    {
      date: "Oct 7, 2024",
      week: "Week 23",
      weight: 88.6,
      notes: "Minor fatigue mid-week. Adjusted training volume accordingly. Nutrition compliance at 95%. Recovery metrics stable."
    },
    {
      date: "Sept 30, 2024",
      week: "Week 22",
      weight: 88.7,
      notes: "Excellent check-in. All lifts progressing on schedule. Body composition changes visible. Client motivation remains high."
    },
    {
      date: "Sept 23, 2024",
      week: "Week 21",
      weight: 88.9,
      notes: "Introduced new accessory work. Client responding well to increased volume. Waist measurement down 0.4cm from last week."
    }
  ];

  const trainingContent = (
    <div className="space-y-6">
      {/* Program Header */}
      <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-200">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h3 className="text-lg font-bold text-indigo-900">Current Block: Hypertrophy II</h3>
            <div className="text-sm text-indigo-600 mt-1">Phase 2 of 3 • Week 8 of 12 • 4-Day Upper/Lower Split</div>
          </div>
          <button 
            onClick={openEditProgramModal}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors"
          >
            Edit Program
          </button>
        </div>
      </div>

      {/* Weekly Structure Overview */}
      <div>
        <h4 className="font-semibold mb-3">Weekly Training Schedule</h4>
        <div className="grid grid-cols-7 gap-2 text-sm">
          <button 
            onClick={() => selectTrainingDay('monday')}
            className={`p-3 rounded-lg text-center font-medium transition-all ${
              selectedTrainingDay === 'monday' 
                ? 'bg-indigo-700 text-white ring-2 ring-indigo-400 ring-offset-2' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <div className="text-xs opacity-80 mb-1">MON</div>
            <div className="text-xs">Upper Power</div>
          </button>
          <button 
            onClick={() => selectTrainingDay('tuesday')}
            className={`p-3 rounded-lg text-center font-medium transition-all ${
              selectedTrainingDay === 'tuesday' 
                ? 'bg-indigo-700 text-white ring-2 ring-indigo-400 ring-offset-2' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <div className="text-xs opacity-80 mb-1">TUE</div>
            <div className="text-xs">Lower Strength</div>
          </button>
          <button 
            onClick={() => selectTrainingDay('wednesday')}
            className={`p-3 rounded-lg text-center font-medium transition-all ${
              selectedTrainingDay === 'wednesday' 
                ? 'bg-orange-600 text-white ring-2 ring-orange-400 ring-offset-2' 
                : 'bg-orange-500 text-white hover:bg-orange-600'
            }`}
          >
            <div className="text-xs opacity-80 mb-1">WED</div>
            <div className="text-xs">HIIT Cardio</div>
          </button>
          <button 
            onClick={() => selectTrainingDay('thursday')}
            className={`p-3 rounded-lg text-center font-medium transition-all ${
              selectedTrainingDay === 'thursday' 
                ? 'bg-indigo-700 text-white ring-2 ring-indigo-400 ring-offset-2' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <div className="text-xs opacity-80 mb-1">THU</div>
            <div className="text-xs">Upper Hypertrophy</div>
          </button>
          <button 
            onClick={() => selectTrainingDay('friday')}
            className={`p-3 rounded-lg text-center font-medium transition-all ${
              selectedTrainingDay === 'friday' 
                ? 'bg-indigo-700 text-white ring-2 ring-indigo-400 ring-offset-2' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <div className="text-xs opacity-80 mb-1">FRI</div>
            <div className="text-xs">Lower Volume</div>
          </button>
          <button 
            onClick={() => selectTrainingDay('saturday')}
            className={`p-3 rounded-lg text-center font-medium transition-all ${
              selectedTrainingDay === 'saturday' 
                ? 'bg-gray-200 text-gray-700 ring-2 ring-gray-400 ring-offset-2' 
                : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
            }`}
          >
            <div className="text-xs opacity-80 mb-1">SAT</div>
            <div className="text-xs">Rest Day</div>
          </button>
          <button 
            onClick={() => selectTrainingDay('sunday')}
            className={`p-3 rounded-lg text-center font-medium transition-all ${
              selectedTrainingDay === 'sunday' 
                ? 'bg-green-200 text-green-800 ring-2 ring-green-400 ring-offset-2' 
                : 'bg-green-100 text-green-700 hover:bg-green-200'
            }`}
          >
            <div className="text-xs opacity-80 mb-1">SUN</div>
            <div className="text-xs">Active Recovery</div>
          </button>
        </div>
      </div>

      {/* Workout Details */}
      <div className="space-y-4">
        <h4 className="font-semibold">Workout Details</h4>

        {selectedTrainingDay === 'monday' && (
        <div ref={mondayRef} className="border border-gray-200 rounded-lg overflow-hidden scroll-mt-6">
          <div className="bg-indigo-50 px-4 py-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-indigo-900">Monday - Upper Power</h5>
                <p className="text-xs text-indigo-600 mt-0.5">Focus: Compound movements, low reps, heavy weight</p>
              </div>
              <span className="text-xs text-indigo-600 font-medium">~75 min</span>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">1</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Barbell Bench Press</div>
                <div className="text-xs text-gray-600 mt-0.5">5 sets × 5 reps • 85% 1RM • 3 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">2</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Barbell Row</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 8 reps • 75% 1RM • 2.5 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">3</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Overhead Press</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 6 reps • 80% 1RM • 2.5 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">4</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Weighted Pull-ups</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 10 reps • RPE 8 • 2 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">5</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Barbell Curl</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 12 reps • Moderate weight • 90s rest</div>
              </div>
            </div>
          </div>
        </div>
        )}

        {selectedTrainingDay === 'tuesday' && (
        <div ref={tuesdayRef} className="border border-gray-200 rounded-lg overflow-hidden scroll-mt-6">
          <div className="bg-indigo-50 px-4 py-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-indigo-900">Tuesday - Lower Strength</h5>
                <p className="text-xs text-indigo-600 mt-0.5">Focus: Squat and hinge patterns, progressive overload</p>
              </div>
              <span className="text-xs text-indigo-600 font-medium">~80 min</span>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">1</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Back Squat</div>
                <div className="text-xs text-gray-600 mt-0.5">5 sets × 5 reps • 85% 1RM • 3-4 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">2</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Romanian Deadlift</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 8 reps • 75% 1RM • 2.5 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">3</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Leg Press</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 12 reps • RPE 8 • 2 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">4</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Leg Curls</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 15 reps • Controlled tempo • 90s rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">5</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Standing Calf Raises</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 20 reps • Stretch at bottom • 60s rest</div>
              </div>
            </div>
          </div>
        </div>
        )}

        {selectedTrainingDay === 'wednesday' && (
        <div ref={wednesdayRef} className="border border-gray-200 rounded-lg overflow-hidden scroll-mt-6">
          <div className="bg-orange-50 px-4 py-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-orange-900">Wednesday - HIIT Cardio</h5>
                <p className="text-xs text-orange-600 mt-0.5">Focus: Metabolic conditioning, fat loss</p>
              </div>
              <span className="text-xs text-orange-600 font-medium">~30 min</span>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-orange-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">1</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Assault Bike Intervals</div>
                <div className="text-xs text-gray-600 mt-0.5">10 rounds × (30s sprint / 90s recovery) • Max effort sprints</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-orange-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">2</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Core Circuit (optional)</div>
                <div className="text-xs text-gray-600 mt-0.5">3 rounds: Plank 45s, Russian Twists 20 reps, Dead Bugs 15/side</div>
              </div>
            </div>
          </div>
        </div>
        )}

        {selectedTrainingDay === 'thursday' && (
        <div ref={thursdayRef} className="border border-gray-200 rounded-lg overflow-hidden scroll-mt-6">
          <div className="bg-indigo-50 px-4 py-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-indigo-900">Thursday - Upper Hypertrophy</h5>
                <p className="text-xs text-indigo-600 mt-0.5">Focus: Higher volume, muscle building, controlled tempo</p>
              </div>
              <span className="text-xs text-indigo-600 font-medium">~70 min</span>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">1</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Incline Dumbbell Press</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 10 reps • 3-1-1 tempo • 2 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">2</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Cable Row (Wide Grip)</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 12 reps • Squeeze at peak • 90s rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">3</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Dumbbell Lateral Raises</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 15 reps • Strict form • 60s rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">4</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Face Pulls</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 20 reps • External rotation • 60s rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">5</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Cable Tricep Extensions</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 15 reps • Full ROM • 60s rest</div>
              </div>
            </div>
          </div>
        </div>
        )}

        {selectedTrainingDay === 'friday' && (
        <div ref={fridayRef} className="border border-gray-200 rounded-lg overflow-hidden scroll-mt-6">
          <div className="bg-indigo-50 px-4 py-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-indigo-900">Friday - Lower Volume</h5>
                <p className="text-xs text-indigo-600 mt-0.5">Focus: Unilateral work, muscle balance, higher reps</p>
              </div>
              <span className="text-xs text-indigo-600 font-medium">~65 min</span>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">1</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Front Squat</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 8 reps • Upright torso • 2 min rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">2</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Bulgarian Split Squat</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 10 reps/leg • Dumbbells • 90s rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">3</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Leg Extensions</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 15 reps • Pause at top • 60s rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">4</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Walking Lunges</div>
                <div className="text-xs text-gray-600 mt-0.5">3 sets × 20 steps total • Bodyweight or light DBs • 90s rest</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-indigo-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">5</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Seated Calf Raises</div>
                <div className="text-xs text-gray-600 mt-0.5">4 sets × 20 reps • Full stretch • 45s rest</div>
              </div>
            </div>
          </div>
        </div>
        )}

        {selectedTrainingDay === 'saturday' && (
        <div ref={saturdayRef} className="border border-gray-200 rounded-lg overflow-hidden scroll-mt-6">
          <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-gray-900">Saturday - Rest Day</h5>
                <p className="text-xs text-gray-600 mt-0.5">Focus: Complete recovery and tissue repair</p>
              </div>
              <span className="text-xs text-gray-600 font-medium">Rest</span>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-700 mb-2">
                <strong>No scheduled training today.</strong> This is a complete rest day to allow your body to recover and adapt to the training stimulus.
              </p>
              <div className="text-xs text-gray-600 space-y-1">
                <p>• Prioritize 8-9 hours of quality sleep</p>
                <p>• Stay hydrated: minimum 3L water</p>
                <p>• Light mobility work or stretching if needed (10-15 min)</p>
                <p>• Focus on nutrition: hit protein target (185g)</p>
                <p>• Avoid strenuous physical activity</p>
              </div>
            </div>
          </div>
        </div>
        )}

        {selectedTrainingDay === 'sunday' && (
        <div ref={sundayRef} className="border border-gray-200 rounded-lg overflow-hidden scroll-mt-6">
          <div className="bg-green-50 px-4 py-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-green-900">Sunday - Active Recovery</h5>
                <p className="text-xs text-green-600 mt-0.5">Focus: Low-intensity movement and mobility</p>
              </div>
              <span className="text-xs text-green-600 font-medium">~30-45 min</span>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-green-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">1</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Low-Intensity Walk or Bike</div>
                <div className="text-xs text-gray-600 mt-0.5">20-30 minutes • Zone 1-2 (conversational pace) • Promotes blood flow without fatigue</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-green-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">2</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Full Body Stretching or Yoga</div>
                <div className="text-xs text-gray-600 mt-0.5">15-20 minutes • Focus on tight areas (hips, shoulders, hamstrings) • Gentle flow or static holds</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-green-500 text-white rounded-lg flex items-center justify-center text-sm font-semibold flex-shrink-0">3</div>
              <div className="flex-1">
                <div className="font-medium text-sm">Foam Rolling & Mobility Drills (Optional)</div>
                <div className="text-xs text-gray-600 mt-0.5">10-15 minutes • Target sore muscle groups • Improve range of motion for upcoming week</div>
              </div>
            </div>
          </div>
        </div>
        )}
      </div>

      {/* Program Notes */}
      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h5 className="font-semibold text-blue-900 mb-2 text-sm">Coach Notes</h5>
        <ul className="text-xs text-blue-800 space-y-1 list-disc list-inside">
          <li>Progressive overload priority: Add 2.5-5kg to main lifts when all sets completed with good form</li>
          <li>Rest days are crucial - prioritize sleep (7-9 hours) and hydration (3-4L daily)</li>
          <li>Active recovery on Sunday: Light walk 20-30min, stretching, or yoga</li>
          <li>Deload scheduled for Week 12 (50% volume reduction)</li>
        </ul>
      </div>
    </div>
  );

  const activeMealPlan = mealPlans.find(plan => plan.id === activeMealPlanId) || mealPlans[0];

  const nutritionContent = (
    <div className="grid grid-cols-3 gap-6">
      {/* Left Column - Daily Architecture & Meal Architecture */}
      <div className="col-span-2 space-y-6">
        {/* Meal Plan Selector */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="text-xl font-bold">Active Meal Plan</h3>
                <div className="relative">
                  <button
                    onClick={() => setShowMealPlanSelector(!showMealPlanSelector)}
                    className="flex items-center gap-2 bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition-colors"
                  >
                    <span className="font-medium">{activeMealPlan.name}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  {showMealPlanSelector && (
                    <div className="absolute top-full left-0 mt-2 bg-white rounded-lg shadow-xl border border-gray-200 min-w-[300px] z-10">
                      {mealPlans.map((plan) => (
                        <button
                          key={plan.id}
                          onClick={() => {
                            setActiveMealPlanId(plan.id);
                            setShowMealPlanSelector(false);
                          }}
                          className={`w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors first:rounded-t-lg last:rounded-b-lg ${
                            plan.id === activeMealPlanId ? "bg-indigo-50" : ""
                          }`}
                        >
                          <div className="font-medium text-gray-900">{plan.name}</div>
                          <div className="text-sm text-gray-500">
                            {plan.targetCalories} cal • {plan.protein}g P • {plan.carbs}g C • {plan.fats}g F
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <p className="text-indigo-100 text-sm">Phase: {activeMealPlan.phase}</p>
            </div>
            <button
              onClick={() => setShowManageMealPlansModal(true)}
              className="bg-white/20 hover:bg-white/30 px-5 py-2.5 rounded-lg transition-colors font-medium"
            >
              Manage All Plans
            </button>
          </div>
        </div>

        {/* Daily Architecture */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold">Daily Architecture</h3>
              <p className="text-sm text-gray-500">Phase: {activeMealPlan.name}</p>
            </div>
            <button className="text-indigo-600 hover:text-indigo-700 text-sm font-medium">Adjust Targets</button>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {/* Total Calories */}
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="text-xs text-gray-500 uppercase mb-2">Target</div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{activeMealPlan.targetCalories.toLocaleString()}</div>
              <div className="text-xs text-gray-500">cals</div>

              {/* Progress Circle */}
              <div className="mt-4 flex items-center justify-center">
                <div className="relative w-20 h-20">
                  <svg className="w-20 h-20 transform -rotate-90">
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      stroke="#e5e7eb"
                      strokeWidth="6"
                      fill="none"
                    />
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      stroke="#6366f1"
                      strokeWidth="6"
                      fill="none"
                      strokeDasharray={`${(892 / activeMealPlan.targetCalories) * 201} 201`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs font-semibold text-gray-700">{Math.round((892 / activeMealPlan.targetCalories) * 100)}%</span>
                  </div>
                </div>
              </div>
              <div className="text-center text-xs text-gray-500 mt-2">892 consumed</div>
            </div>

            {/* Protein */}
            <div className="bg-blue-50 rounded-xl p-4">
              <div className="text-xs text-blue-600 uppercase mb-2">Protein</div>
              <div className="text-3xl font-bold text-blue-700 mb-1">{activeMealPlan.protein}g</div>
              <div className="text-xs text-gray-500">lean on 30 days ever</div>
              <div className="mt-4 bg-blue-100 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${(53 / activeMealPlan.protein) * 100}%` }} />
              </div>
              <div className="text-xs text-gray-600 mt-2">53g / {activeMealPlan.protein}g</div>
            </div>

            {/* Carbs */}
            <div className="bg-green-50 rounded-xl p-4">
              <div className="text-xs text-green-600 uppercase mb-2">Carbs</div>
              <div className="text-3xl font-bold text-green-700 mb-1">{activeMealPlan.carbs}g</div>
              <div className="text-xs text-gray-500">high-hitting day testing</div>
              <div className="mt-4 bg-green-100 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: `${(100 / activeMealPlan.carbs) * 100}%` }} />
              </div>
              <div className="text-xs text-gray-600 mt-2">100g / {activeMealPlan.carbs}g</div>
            </div>

            {/* Fats */}
            <div className="bg-orange-50 rounded-xl p-4">
              <div className="text-xs text-orange-600 uppercase mb-2">Fats</div>
              <div className="text-3xl font-bold text-orange-700 mb-1">{activeMealPlan.fats}g</div>
              <div className="text-xs text-gray-500">Low on average 2 months</div>
              <div className="mt-4 bg-orange-100 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: `${(52 / activeMealPlan.fats) * 100}%` }} />
              </div>
              <div className="text-xs text-gray-600 mt-2">52g / {activeMealPlan.fats}g</div>
            </div>
          </div>
        </div>

        {/* Meal Architecture */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold">Meal Architecture</h3>
            <div className="flex items-center gap-2">
              <button className="text-sm text-gray-600 hover:text-gray-900">Evening Snip</button>
              <button className="text-sm text-indigo-600 hover:text-indigo-700">Next Day</button>
            </div>
          </div>

          <div className="space-y-6">
            {/* Meal 1 */}
            <div className="border-l-4 border-purple-500 pl-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-semibold text-gray-900">01 Breakfast: High Protein Start</h4>
                  <p className="text-xs text-gray-500">7:30 AM</p>
                </div>
                <button className="p-2 hover:bg-gray-100 rounded transition-colors">
                  <Edit className="w-4 h-4 text-gray-500" />
                </button>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                  <img
                    src="https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=60&h=60&fit=crop"
                    alt="Eggs"
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-sm">Large Omega-3 Egg</div>
                    <div className="text-xs text-gray-500">x3 eggs</div>
                  </div>
                  <div className="text-sm font-semibold text-gray-900">280 kcal</div>
                </div>

                <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                  <img
                    src="https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=60&h=60&fit=crop"
                    alt="Avocado"
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-sm">Micro Avocado</div>
                    <div className="text-xs text-gray-500">50g serving</div>
                  </div>
                  <div className="text-sm font-semibold text-gray-900">110 kcal</div>
                </div>

                <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                  <img
                    src="https://images.unsplash.com/photo-1509440159596-0249088772ff?w=60&h=60&fit=crop"
                    alt="Bread"
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-sm">Artisan Sourdough</div>
                    <div className="text-xs text-gray-500">2 slices</div>
                  </div>
                  <div className="text-sm font-semibold text-gray-900">120 kcal</div>
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <div className="flex items-center gap-6">
                  <div>
                    <span className="font-bold text-gray-900">892</span>
                    <span className="text-gray-500"> / {activeMealPlan.targetCalories.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <div>
                      <span className="font-semibold text-blue-600">53g</span>
                      <span className="text-gray-500"> / {activeMealPlan.protein}g</span>
                    </div>
                    <div>
                      <span className="font-semibold text-green-600">100g</span>
                      <span className="text-gray-500"> / {activeMealPlan.carbs}g</span>
                    </div>
                    <div>
                      <span className="font-semibold text-orange-600">52g</span>
                      <span className="text-gray-500"> / {activeMealPlan.fats}g</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column - Ingredient Database */}
      <div className="space-y-6">
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="font-bold text-gray-900 mb-4">Ingredient Database</h3>

          <div className="relative mb-4">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search ingredients..."
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {/* Ingredient Card */}
            <div className="border border-gray-200 rounded-lg p-3 hover:border-indigo-300 transition-colors cursor-pointer">
              <div className="flex items-center gap-3 mb-2">
                <img
                  src="https://images.unsplash.com/photo-1588137378633-dea1336ce1e2?w=60&h=60&fit=crop"
                  alt="Grass-fed Beef"
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-sm">Grass-fed Beef</h4>
                  <p className="text-xs text-gray-500">100g, Lean Mince</p>
                </div>
                <button className="p-1 hover:bg-indigo-50 rounded">
                  <Plus className="w-4 h-4 text-indigo-600" />
                </button>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div><span className="font-semibold">250</span> cal</div>
                <div><span className="font-semibold text-blue-600">26g</span> pro</div>
                <div><span className="font-semibold text-green-600">0g</span> carb</div>
                <div><span className="font-semibold text-orange-600">17g</span> fat</div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-3 hover:border-indigo-300 transition-colors cursor-pointer">
              <div className="flex items-center gap-3 mb-2">
                <img
                  src="https://images.unsplash.com/photo-1586201375761-83865001e31c?w=60&h=60&fit=crop"
                  alt="Basmati Rice"
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-sm">Basmati Rice</h4>
                  <p className="text-xs text-gray-500">100g, Long Grain</p>
                </div>
                <button className="p-1 hover:bg-indigo-50 rounded">
                  <Plus className="w-4 h-4 text-indigo-600" />
                </button>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div><span className="font-semibold">121</span> cal</div>
                <div><span className="font-semibold text-blue-600">3g</span> pro</div>
                <div><span className="font-semibold text-green-600">25g</span> carb</div>
                <div><span className="font-semibold text-orange-600">0.4g</span> fat</div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-3 hover:border-indigo-300 transition-colors cursor-pointer">
              <div className="flex items-center gap-3 mb-2">
                <img
                  src="https://images.unsplash.com/photo-1517673132405-a56a62b18caf?w=60&h=60&fit=crop"
                  alt="Rolled Oats"
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-sm">Rolled Oats</h4>
                  <p className="text-xs text-gray-500">50g serving</p>
                </div>
                <button className="p-1 hover:bg-indigo-50 rounded">
                  <Plus className="w-4 h-4 text-indigo-600" />
                </button>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div><span className="font-semibold">195</span> cal</div>
                <div><span className="font-semibold text-blue-600">7g</span> pro</div>
                <div><span className="font-semibold text-green-600">33g</span> carb</div>
                <div><span className="font-semibold text-orange-600">4g</span> fat</div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-3 hover:border-indigo-300 transition-colors cursor-pointer">
              <div className="flex items-center gap-3 mb-2">
                <img
                  src="https://images.unsplash.com/photo-1579722820308-d746b13b215b?w=60&h=60&fit=crop"
                  alt="Whey Isolate"
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-sm">Whey Isolate</h4>
                  <p className="text-xs text-gray-500">30g scoop</p>
                </div>
                <button className="p-1 hover:bg-indigo-50 rounded">
                  <Plus className="w-4 h-4 text-indigo-600" />
                </button>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div><span className="font-semibold">120</span> cal</div>
                <div><span className="font-semibold text-blue-600">27g</span> pro</div>
                <div><span className="font-semibold text-green-600">1g</span> carb</div>
                <div><span className="font-semibold text-orange-600">0.5g</span> fat</div>
              </div>
            </div>
          </div>

          <button className="w-full mt-4 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium">
            Explore Food
          </button>
        </div>
      </div>
    </div>
  );

  const supplementationContent = (
    <div className="space-y-4">
      <div className="p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="font-semibold">Advanced Recovery Pack</div>
          <button className="text-indigo-600 hover:text-indigo-700 text-sm font-medium">Edit</button>
        </div>
        <div className="text-sm text-gray-600">Optimized for strength and hypertrophy goals</div>
      </div>
      <div className="space-y-3">
        <div className="p-3 bg-white border border-gray-200 rounded-lg">
          <div className="font-medium text-sm">Creatine Monohydrate</div>
          <div className="text-xs text-gray-500 mt-1">5g daily • Post-workout or with breakfast</div>
        </div>
        <div className="p-3 bg-white border border-gray-200 rounded-lg">
          <div className="font-medium text-sm">Whey Protein Isolate</div>
          <div className="text-xs text-gray-500 mt-1">25g per serving • 2x daily (post-workout + evening)</div>
        </div>
        <div className="p-3 bg-white border border-gray-200 rounded-lg">
          <div className="font-medium text-sm">Omega-3 Fish Oil</div>
          <div className="text-xs text-gray-500 mt-1">2g EPA/DHA • With largest meal</div>
        </div>
        <div className="p-3 bg-white border border-gray-200 rounded-lg">
          <div className="font-medium text-sm">Vitamin D3 + Magnesium</div>
          <div className="text-xs text-gray-500 mt-1">5000 IU D3 + 400mg Mg • Before bed</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center gap-2 text-sm">
        <Link to="/clients" className="text-gray-500 hover:text-gray-700">Clients</Link>
        <span className="text-gray-400">/</span>
        <span className="text-gray-900 font-medium">{client.name}</span>
      </div>

      {/* Header Section */}
      <div className="bg-white rounded-xl border border-gray-200 p-8 mb-6">
        <div className="flex items-start justify-between mb-6">
          <div className="flex gap-6">
            {/* Profile Photo */}
            <div className="relative">
              <div className="w-32 h-32 rounded-2xl overflow-hidden bg-gray-200">
                <ImageWithFallback
                  src={client.image}
                  alt={client.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
            </div>

            {/* Info */}
            <div>
              <div className="flex gap-3 mb-3">
                <span className="px-3 py-1 bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-md uppercase">
                  Active Protocol: {client.protocol}
                </span>
              </div>
              <div className="mb-3">
                <span className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-md uppercase">
                  Assigned Check-in: Every {client.checkInDay}
                </span>
              </div>
              <h1 className="text-4xl font-bold mb-3">{client.name}</h1>
              
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button 
              onClick={() => navigate(`/messages?client=${id}`)}
              className="px-6 py-3 bg-white border-2 border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 flex items-center gap-2 transition-colors"
            >
              <MessageSquare className="w-5 h-5" />
              Message
            </button>
            <button className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 flex items-center gap-2 transition-colors">
              <Edit className="w-5 h-5" />
              Edit Protocol
            </button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-6 gap-4">
          <div className="border-l-4 border-indigo-500 pl-4">
            <div className="text-xs text-gray-500 uppercase mb-1">Current Weight</div>
            <div className="text-2xl font-bold mb-1">{client.currentWeight}<span className="text-sm text-gray-500">kg</span></div>
            <div className="text-xs text-green-600 flex items-center gap-1">
              <span>↓ {Math.abs(client.weightChange)}kg</span>
            </div>
          </div>

          <div className="border-l-4 border-orange-500 pl-4">
            <div className="text-xs text-gray-500 uppercase mb-1">Body Fat %</div>
            <div className="text-2xl font-bold mb-1">{client.bodyFat}<span className="text-sm text-gray-500">%</span></div>
            <div className="text-xs text-green-600 flex items-center gap-1">
              <span>↓ {Math.abs(client.bodyFatChange)}%</span>
            </div>
          </div>

          <div className="border-l-4 border-green-500 pl-4">
            <div className="text-xs text-gray-500 uppercase mb-1">Daily Habit Streak</div>
            <div className="text-2xl font-bold mb-1">{client.habitStreak}<span className="text-sm text-gray-500">days</span></div>
            <div className="text-xs text-orange-600 flex items-center gap-1">
              <span>⭐ Consistent</span>
            </div>
          </div>

          <div className="border-l-4 border-purple-500 pl-4">
            <div className="text-xs text-gray-500 uppercase mb-1">Recovery Score</div>
            <div className="text-2xl font-bold mb-1">{client.recoveryScore}<span className="text-sm text-gray-500">/100</span></div>
            <div className="text-xs text-green-600 flex items-center gap-1">
              <span>⚡ Ready</span>
            </div>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <div className="text-xs text-gray-500 uppercase mb-1">Time with Coach</div>
            <div className="text-2xl font-bold mb-1">{client.weeksWithCoach}<span className="text-sm text-gray-500">wks</span></div>
            <div className="text-xs text-blue-600 flex items-center gap-1">
              <span>📅 {Math.floor(client.weeksWithCoach / 4)}mo</span>
            </div>
          </div>

          <div className="border-l-4 border-pink-500 pl-4">
            <div className="text-xs text-gray-500 uppercase mb-1">Age</div>
            <div className="text-2xl font-bold mb-1">{client.age}<span className="text-sm text-gray-500">yrs</span></div>
            <div className="text-xs text-gray-500">
              <span>Born 1994</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-6">
        <div className="flex gap-1 bg-white rounded-lg border border-gray-200 p-1 w-fit">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "dashboard"
                ? "bg-indigo-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab("training")}
            className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "training"
                ? "bg-indigo-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            Training
          </button>
          <button
            onClick={() => setActiveTab("nutrition")}
            className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "nutrition"
                ? "bg-indigo-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            Nutrition
          </button>
          <button
            onClick={() => setActiveTab("supplementation")}
            className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "supplementation"
                ? "bg-indigo-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            Supplementation
          </button>
        </div>
      </div>

      {/* Main Content Grid */}
      {activeTab === "dashboard" ? (
        <div className="grid grid-cols-3 gap-6">
          {/* Left Column - Progress Analytics & Calendar */}
          <div className="col-span-2 space-y-6">
            {/* Progress Analytics */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold">Progress Analytics</h2>
                <p className="text-sm text-gray-500">Multi-metric tracking over time</p>
              </div>
              <div className="flex items-center gap-3">
                {/* Time Range Selector */}
                <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => setTimeRange("week")}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      timeRange === "week"
                        ? "bg-white text-gray-900 shadow-sm"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Week
                  </button>
                  <button
                    onClick={() => setTimeRange("month")}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      timeRange === "month"
                        ? "bg-white text-gray-900 shadow-sm"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Month
                  </button>
                  <button
                    onClick={() => setTimeRange("year")}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      timeRange === "year"
                        ? "bg-white text-gray-900 shadow-sm"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Year
                  </button>
                </div>

                {/* Metrics Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setShowMetricDropdown(!showMetricDropdown)}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
                  >
                    Metrics ({Object.values(activeMetrics).filter(Boolean).length})
                  </button>
                  {showMetricDropdown && (
                    <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-lg border border-gray-200 p-2 z-10">
                      {metricOptions.map((option) => (
                        <button
                          key={option.key}
                          onClick={() => toggleMetric(option.key)}
                          className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: option.color }}
                            />
                            <span className="text-sm text-gray-700">{option.label}</span>
                          </div>
                          {activeMetrics[option.key] && (
                            <Check className="w-4 h-4 text-indigo-600" />
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Line Chart */}
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                    fontSize: "12px"
                  }}
                />
                <Legend 
                  wrapperStyle={{ fontSize: "12px" }}
                  iconType="line"
                />
                {activeMetrics.weight && (
                  <Line
                    key="line-weight"
                    id="line-weight"
                    type="monotone"
                    dataKey="weight"
                    stroke="#6366f1"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Body Weight (kg)"
                    animationDuration={300}
                  />
                )}
                {activeMetrics.waist && (
                  <Line
                    key="line-waist"
                    id="line-waist"
                    type="monotone"
                    dataKey="waist"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Waist (cm)"
                    animationDuration={300}
                  />
                )}
                {activeMetrics.calories && (
                  <Line
                    key="line-calories"
                    id="line-calories"
                    type="monotone"
                    dataKey="calories"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Calories"
                    animationDuration={300}
                  />
                )}
                {activeMetrics.protein && (
                  <Line
                    key="line-protein"
                    id="line-protein"
                    type="monotone"
                    dataKey="protein"
                    stroke="#ec4899"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Protein (g)"
                    animationDuration={300}
                  />
                )}
                {activeMetrics.carbs && (
                  <Line
                    key="line-carbs"
                    id="line-carbs"
                    type="monotone"
                    dataKey="carbs"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Carbs (g)"
                    animationDuration={300}
                  />
                )}
                {activeMetrics.fat && (
                  <Line
                    key="line-fat"
                    id="line-fat"
                    type="monotone"
                    dataKey="fat"
                    stroke="#f97316"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Fat (g)"
                    animationDuration={300}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Calendar */}
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">Calendar</h2>
              <div className="flex items-center gap-3">
                <button
                  onClick={openAddEventModal}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Event
                </button>
                <span className="text-xs font-medium">{formatMonthYear(currentMonth)}</span>
                <div className="flex gap-1">
                  <button 
                    onClick={() => navigateMonth('prev')}
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={() => navigateMonth('next')}
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-1.5">
              {["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"].map((day) => (
                <div key={day} className="text-[10px] text-gray-500 text-center py-1 font-medium">
                  {day}
                </div>
              ))}
              {calendarDays.map((date, index) => {
                const workout = getWorkoutForDate(date);
                const hasWorkout = !!workout;
                const events = getEventsForDate(date);
                const hasEvents = events.length > 0;
                const today = isToday(date);
                
                return (
                  <button
                    key={index}
                    onClick={() => handleDayClick(date)}
                    disabled={!date}
                    className={`aspect-square flex flex-col items-center justify-center rounded-md text-xs font-medium transition-colors relative ${
                      !date
                        ? "bg-transparent cursor-default"
                        : today
                        ? "bg-indigo-100 border-2 border-indigo-600 text-indigo-900"
                        : workout?.type === "strength"
                        ? "bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer"
                        : workout?.type === "cardio"
                        ? "bg-orange-500 text-white hover:bg-orange-600 cursor-pointer"
                        : hasEvents
                        ? "bg-purple-50 text-purple-700 hover:bg-purple-100 cursor-pointer border border-purple-300"
                        : "bg-gray-50 text-gray-400 hover:bg-gray-100"
                    }`}
                  >
                    {date && (
                      <>
                        <div>{date.getDate()}</div>
                        {(hasWorkout || hasEvents) && (
                          <div className="flex gap-0.5 mt-0.5">
                            {hasWorkout && (
                              <div className="w-0.5 h-0.5 bg-current rounded-full" />
                            )}
                            {hasEvents && (
                              <div className="w-0.5 h-0.5 bg-purple-600 rounded-full" />
                            )}
                          </div>
                        )}
                      </>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="flex gap-4 mt-3 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
                <span className="text-gray-600">Strength</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-orange-500" />
                <span className="text-gray-600">Cardio</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-purple-600" />
                <span className="text-gray-600">Events</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Weekly Check-In History */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold">Weekly Check-In History</h2>
                <p className="text-xs text-gray-500 mt-1">Recent coach check-ins</p>
              </div>
            </div>
            <div className="space-y-4">
              {checkIns.map((checkIn, index) => (
                <div key={index} className="pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                  <div className="flex items-start gap-3 mb-2">
                    <div className="w-2 h-2 bg-indigo-600 rounded-full mt-1.5 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <div className="text-xs text-gray-500">{checkIn.date}</div>
                        <div className="text-xs font-semibold text-indigo-600">{checkIn.week}</div>
                      </div>
                      <div className="text-xs font-medium text-gray-700 mb-1">
                        Weight: {checkIn.weight}kg
                      </div>
                      <div className="text-sm text-gray-600 leading-relaxed">{checkIn.notes}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-4 px-4 py-2 text-sm font-medium text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 rounded-lg transition-colors">
              View All Check-Ins →
            </button>
          </div>
        </div>
      </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          {activeTab === "training" && trainingContent}
          {activeTab === "nutrition" && nutritionContent}
          {activeTab === "supplementation" && supplementationContent}
        </div>
      )}

      {/* Workout Detail Modal */}
      {showWorkoutModal && selectedDay && (
        <div className="fixed inset-0 backdrop-blur-md bg-black bg-opacity-20 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold mb-1">
                    {getWorkoutForDate(selectedDay)?.name}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {selectedDay.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
                  </p>
                </div>
                <button
                  onClick={() => setShowWorkoutModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className={`px-4 py-2 rounded-lg text-sm font-medium ${
                    getWorkoutForDate(selectedDay)?.type === "strength"
                      ? "bg-indigo-100 text-indigo-700"
                      : "bg-orange-100 text-orange-700"
                  }`}>
                    {getWorkoutForDate(selectedDay)?.type === "strength" ? "Strength Training" : "Cardio"}
                  </div>
                  {getWorkoutForDate(selectedDay)?.duration && (
                    <div className="text-sm text-gray-600">
                      ⏱ {getWorkoutForDate(selectedDay)?.duration}
                    </div>
                  )}
                </div>

                {getWorkoutForDate(selectedDay)?.exercises && (
                  <div>
                    <h4 className="font-semibold mb-3">Exercises:</h4>
                    <div className="space-y-2">
                      {getWorkoutForDate(selectedDay)?.exercises?.map((exercise, idx) => (
                        <div key={idx} className="flex items-start gap-2 p-3 bg-gray-50 rounded-lg">
                          <div className="w-6 h-6 bg-indigo-600 text-white rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0">
                            {idx + 1}
                          </div>
                          <div className="text-sm text-gray-700">{exercise}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {getWorkoutForDate(selectedDay)?.notes && (
                  <div>
                    <h4 className="font-semibold mb-2">Notes:</h4>
                    <p className="text-sm text-gray-600 p-3 bg-gray-50 rounded-lg">
                      {getWorkoutForDate(selectedDay)?.notes}
                    </p>
                  </div>
                )}
              </div>

              <div className="mt-6 flex gap-3">
                <button
                  onClick={() => setShowWorkoutModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
                <button className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors">
                  Edit Workout
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Program Modal */}
      {showEditProgramModal && editingWeeklyProgram && (
        <DndProvider backend={HTML5Backend}>
          <div className="fixed inset-0 backdrop-blur-md bg-black bg-opacity-20 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
              {/* Modal Header */}
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold text-gray-900">Edit Weekly Training Program</h2>
                  <button
                    onClick={closeEditProgramModal}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                {/* Day Tabs */}
                <div className="flex gap-2 overflow-x-auto">
                  {Object.keys(editingWeeklyProgram).map((day) => (
                    <button
                      key={day}
                      onClick={() => setActiveEditDay(day)}
                      className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
                        activeEditDay === day
                          ? "bg-indigo-600 text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {editingWeeklyProgram[day].day}
                    </button>
                  ))}
                </div>
              </div>

              {/* Current Day Details */}
              <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Workout Name</label>
                    <input
                      type="text"
                      value={editingWeeklyProgram[activeEditDay].name}
                      onChange={(e) => updateProgramField("name", e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Focus</label>
                    <input
                      type="text"
                      value={editingWeeklyProgram[activeEditDay].focus}
                      onChange={(e) => updateProgramField("focus", e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Duration (min)</label>
                    <input
                      type="text"
                      value={editingWeeklyProgram[activeEditDay].duration}
                      onChange={(e) => updateProgramField("duration", e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Modal Content */}
              <div className="flex-1 overflow-y-auto p-6">
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900">Exercises</h3>
                    <span className="text-sm text-gray-500">Drag to reorder</span>
                  </div>

                  {/* Exercise List */}
                  {editingWeeklyProgram[activeEditDay].exercises.length > 0 ? (
                    <div className="space-y-3 mb-4">
                      {editingWeeklyProgram[activeEditDay].exercises.map((exercise, index) => (
                        <DraggableExercise key={exercise.id} exercise={exercise} index={index} />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg mb-4">
                      <p>No exercises added yet. Add exercises below.</p>
                    </div>
                  )}

                  {/* Add Exercise Section */}
                  <div className="border-t border-gray-200 pt-4 mt-4">
                    <h4 className="text-sm font-semibold text-gray-700 mb-3">Add Exercise</h4>
                    
                    {/* Search Box */}
                    <div className="relative mb-3">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search exercises..."
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none text-sm"
                      />
                    </div>

                    {/* Exercise Library */}
                    {searchQuery && (
                      <div className="border border-gray-200 rounded-lg max-h-48 overflow-y-auto">
                        {filteredExercises.length > 0 ? (
                          filteredExercises.map((exerciseName) => (
                            <button
                              key={exerciseName}
                              onClick={() => addExercise(exerciseName)}
                              className="w-full text-left px-4 py-2 hover:bg-indigo-50 transition-colors text-sm flex items-center justify-between group"
                            >
                              <span>{exerciseName}</span>
                              <Plus className="w-4 h-4 text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                            </button>
                          ))
                        ) : (
                          <div className="px-4 py-3 text-sm text-gray-500 text-center">
                            No exercises found
                          </div>
                        )}
                      </div>
                    )}

                    {/* Quick Add Button */}
                    {!searchQuery && (
                      <button
                        onClick={() => addExercise("New Exercise")}
                        className="w-full px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-indigo-500 hover:text-indigo-600 transition-colors flex items-center justify-center gap-2"
                      >
                        <Plus className="w-4 h-4" />
                        <span className="text-sm font-medium">Add Custom Exercise</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-6 border-t border-gray-200 flex gap-3">
                <button
                  onClick={closeEditProgramModal}
                  className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={saveProgram}
                  className="flex-1 px-6 py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </DndProvider>
      )}

      {/* Add Event Modal */}
      {showAddEventModal && (
        <div className="fixed inset-0 backdrop-blur-md bg-black bg-opacity-20 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Add Calendar Event</h2>
                <button
                  onClick={closeAddEventModal}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-4">
                {/* Event Type Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Event Type</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => updateEventField("type", "face-to-face")}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        newEvent.type === "face-to-face"
                          ? "border-indigo-600 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <Users className="w-5 h-5 mx-auto mb-2 text-indigo-600" />
                      <div className="text-sm font-medium">Face-to-Face</div>
                    </button>
                    <button
                      onClick={() => updateEventField("type", "video-call")}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        newEvent.type === "video-call"
                          ? "border-indigo-600 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <Video className="w-5 h-5 mx-auto mb-2 text-indigo-600" />
                      <div className="text-sm font-medium">Video Call</div>
                      <div className="text-xs text-gray-500 mt-1">Zoom/Meet</div>
                    </button>
                    <button
                      onClick={() => updateEventField("type", "phone-call")}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        newEvent.type === "phone-call"
                          ? "border-indigo-600 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <Phone className="w-5 h-5 mx-auto mb-2 text-indigo-600" />
                      <div className="text-sm font-medium">Phone Call</div>
                    </button>
                    <button
                      onClick={() => updateEventField("type", "phase")}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        newEvent.type === "phase"
                          ? "border-indigo-600 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <Target className="w-5 h-5 mx-auto mb-2 text-indigo-600" />
                      <div className="text-sm font-medium">Training Phase</div>
                    </button>
                    <button
                      onClick={() => updateEventField("type", "milestone")}
                      className={`p-4 rounded-lg border-2 transition-all col-span-2 ${
                        newEvent.type === "milestone"
                          ? "border-indigo-600 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <CalendarIcon className="w-5 h-5 mx-auto mb-2 text-indigo-600" />
                      <div className="text-sm font-medium">Milestone / Timeline Event</div>
                    </button>
                  </div>
                </div>

                {/* Event Title */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Event Title
                  </label>
                  <input
                    type="text"
                    value={newEvent.title}
                    onChange={(e) => updateEventField("title", e.target.value)}
                    placeholder="e.g., Monthly Progress Review"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none"
                  />
                </div>

                {/* Date and Time */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <input
                      type="date"
                      value={newEvent.date}
                      onChange={(e) => updateEventField("date", e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none"
                    />
                  </div>
                  {newEvent.type !== "phase" && newEvent.type !== "milestone" && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                      <input
                        type="time"
                        value={newEvent.time}
                        onChange={(e) => updateEventField("time", e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none"
                      />
                    </div>
                  )}
                </div>

                {/* Duration for calls/meetings */}
                {(newEvent.type === "face-to-face" || newEvent.type === "video-call" || newEvent.type === "phone-call") && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Duration (minutes)
                    </label>
                    <input
                      type="text"
                      value={newEvent.duration}
                      onChange={(e) => updateEventField("duration", e.target.value)}
                      placeholder="60"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none"
                    />
                  </div>
                )}

                {/* Meeting Link for video calls */}
                {newEvent.type === "video-call" && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Meeting Link (Zoom/Google Meet)
                    </label>
                    <input
                      type="url"
                      value={newEvent.meetingLink}
                      onChange={(e) => updateEventField("meetingLink", e.target.value)}
                      placeholder="https://zoom.us/j/..."
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none"
                    />
                  </div>
                )}

                {/* Location for face-to-face */}
                {newEvent.type === "face-to-face" && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      value={newEvent.location}
                      onChange={(e) => updateEventField("location", e.target.value)}
                      placeholder="e.g., Downtown Fitness Center"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none"
                    />
                  </div>
                )}

                {/* Notes */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notes / Description
                  </label>
                  <textarea
                    value={newEvent.notes}
                    onChange={(e) => updateEventField("notes", e.target.value)}
                    placeholder="Add any additional details..."
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:outline-none resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={closeAddEventModal}
                className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={saveEvent}
                className="flex-1 px-6 py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors"
              >
                Add Event
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manage All Meal Plans Modal */}
      {showManageMealPlansModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Blurred backdrop */}
          <div
            className="absolute inset-0 bg-black/30 backdrop-blur-sm"
            onClick={() => setShowManageMealPlansModal(false)}
          />

          {/* Modal content */}
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden m-4">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold mb-1">Manage All Meal Plans</h2>
                <p className="text-indigo-100 text-sm">
                  Create, edit, and switch between multiple nutrition protocols
                </p>
              </div>
              <button
                onClick={() => setShowManageMealPlansModal(false)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
              <div className="grid grid-cols-2 gap-6">
                {mealPlans.map((plan) => (
                  <div
                    key={plan.id}
                    className={`bg-white rounded-xl border-2 p-6 transition-all ${
                      plan.id === activeMealPlanId
                        ? "border-indigo-500 shadow-lg"
                        : "border-gray-200 hover:border-indigo-300"
                    }`}
                  >
                    {/* Plan Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-xl font-bold text-gray-900">{plan.name}</h3>
                          {plan.id === activeMealPlanId && (
                            <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-1 rounded font-medium">
                              ACTIVE
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-500">Phase: {plan.phase}</p>
                      </div>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Edit className="w-4 h-4 text-gray-600" />
                      </button>
                    </div>

                    {/* Macros Grid */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <div className="text-xs text-gray-500 uppercase mb-1">Calories</div>
                        <div className="text-2xl font-bold text-gray-900">
                          {plan.targetCalories.toLocaleString()}
                        </div>
                      </div>
                      <div className="bg-blue-50 rounded-lg p-3">
                        <div className="text-xs text-blue-600 uppercase mb-1">Protein</div>
                        <div className="text-2xl font-bold text-blue-700">{plan.protein}g</div>
                      </div>
                      <div className="bg-green-50 rounded-lg p-3">
                        <div className="text-xs text-green-600 uppercase mb-1">Carbs</div>
                        <div className="text-2xl font-bold text-green-700">{plan.carbs}g</div>
                      </div>
                      <div className="bg-orange-50 rounded-lg p-3">
                        <div className="text-xs text-orange-600 uppercase mb-1">Fats</div>
                        <div className="text-2xl font-bold text-orange-700">{plan.fats}g</div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      {plan.id !== activeMealPlanId && (
                        <button
                          onClick={() => {
                            setActiveMealPlanId(plan.id);
                          }}
                          className="flex-1 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium"
                        >
                          Set as Active
                        </button>
                      )}
                      <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
                        Duplicate
                      </button>
                      {mealPlans.length > 1 && plan.id !== activeMealPlanId && (
                        <button
                          onClick={() => {
                            setMealPlans(mealPlans.filter(p => p.id !== plan.id));
                          }}
                          className="px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors text-sm font-medium"
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                {/* Add New Plan Card */}
                <button
                  onClick={() => {
                    const newPlan = {
                      id: String(mealPlans.length + 1),
                      name: `New Meal Plan ${mealPlans.length + 1}`,
                      phase: "Custom",
                      targetCalories: 2500,
                      protein: 180,
                      carbs: 250,
                      fats: 80,
                      active: false,
                    };
                    setMealPlans([...mealPlans, newPlan]);
                  }}
                  className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center hover:border-indigo-400 hover:bg-indigo-50 transition-all group min-h-[320px]"
                >
                  <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-4 group-hover:bg-indigo-100 transition-colors">
                    <Plus className="w-8 h-8 text-gray-400 group-hover:text-indigo-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-700 group-hover:text-indigo-600 transition-colors">
                    Create New Meal Plan
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Add a custom nutrition protocol
                  </p>
                </button>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-gray-50 border-t border-gray-200 p-6 flex items-center justify-between">
              <p className="text-sm text-gray-600">
                {mealPlans.length} meal plan{mealPlans.length !== 1 ? 's' : ''} total
              </p>
              <button
                onClick={() => setShowManageMealPlansModal(false)}
                className="px-6 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
