import { Instagram, Facebook, Twitter, TrendingUp, Calendar, Image, BarChart3 } from "lucide-react";

export function SocialMediaPage() {
  const scheduledPosts = [
    {
      id: 1,
      platform: "Instagram",
      content: "Transformation Tuesday: Sarah's 12-week journey",
      scheduled: "Today, 2:00 PM",
      status: "scheduled",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwdHJhbnNmb3JtYXRpb258ZW58MXx8fHwxNzQ1MTYwMDAwfDA&ixlib=rb-4.1.0&q=80&w=400",
    },
    {
      id: 2,
      platform: "Facebook",
      content: "New nutrition guide: 5 Pre-Workout Meals",
      scheduled: "Tomorrow, 10:00 AM",
      status: "draft",
      image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwbWVhbCUyMGJvd2x8ZW58MXx8fHwxNzQ1MTYwMDAwfDA&ixlib=rb-4.1.0&q=80&w=400",
    },
    {
      id: 3,
      platform: "Twitter",
      content: "Quick tip: Hydration matters more than you think...",
      scheduled: "Tomorrow, 4:00 PM",
      status: "scheduled",
      image: null,
    },
  ];

  const analytics = [
    { label: "Reach", value: "24.5K", change: "+12%" },
    { label: "Engagement", value: "3.2K", change: "+8%" },
    { label: "New Followers", value: "342", change: "+23%" },
    { label: "Conversion Rate", value: "4.8%", change: "+2%" },
  ];

  return (
    <div className="p-8">
      {/* Page Title */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Social Media Hub</h2>
        <p className="text-gray-600">Manage your social presence and track engagement across platforms.</p>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        {analytics.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-500 uppercase tracking-wider">{stat.label}</span>
              <span className="text-xs text-green-600 font-medium">{stat.change}</span>
            </div>
            <div className="text-2xl font-bold">{stat.value}</div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Scheduled Posts */}
        <div className="col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Scheduled Posts</h3>
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition-colors">
              + New Post
            </button>
          </div>

          <div className="space-y-4">
            {scheduledPosts.map((post) => (
              <div key={post.id} className="bg-white rounded-xl p-5 border border-gray-200">
                <div className="flex gap-4">
                  {post.image && (
                    <img
                      src={post.image}
                      alt="Post preview"
                      className="w-24 h-24 rounded-lg object-cover"
                    />
                  )}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {post.platform === "Instagram" && <Instagram className="w-4 h-4 text-pink-600" />}
                      {post.platform === "Facebook" && <Facebook className="w-4 h-4 text-blue-600" />}
                      {post.platform === "Twitter" && <Twitter className="w-4 h-4 text-sky-500" />}
                      <span className="text-sm font-medium">{post.platform}</span>
                      <span className={`text-xs px-2 py-1 rounded ${
                        post.status === "scheduled" 
                          ? "bg-green-100 text-green-700" 
                          : "bg-gray-100 text-gray-700"
                      }`}>
                        {post.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 mb-2">{post.content}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Calendar className="w-3 h-3" />
                      <span>{post.scheduled}</span>
                    </div>
                  </div>
                  <button className="text-sm text-indigo-600 hover:text-indigo-700">Edit</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Platform Stats & Quick Actions */}
        <div>
          <h3 className="text-xl font-bold mb-4">Platform Overview</h3>
          
          <div className="space-y-4 mb-6">
            <div className="bg-white rounded-xl p-5 border border-gray-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-pink-50 rounded-full flex items-center justify-center">
                  <Instagram className="w-5 h-5 text-pink-600" />
                </div>
                <div className="flex-1">
                  <div className="font-medium text-sm">Instagram</div>
                  <div className="text-xs text-gray-500">12.4K followers</div>
                </div>
              </div>
              <div className="text-xs text-gray-600">Avg. engagement: 8.2%</div>
            </div>

            <div className="bg-white rounded-xl p-5 border border-gray-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center">
                  <Facebook className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="font-medium text-sm">Facebook</div>
                  <div className="text-xs text-gray-500">8.7K followers</div>
                </div>
              </div>
              <div className="text-xs text-gray-600">Avg. engagement: 5.4%</div>
            </div>

            <div className="bg-white rounded-xl p-5 border border-gray-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-sky-50 rounded-full flex items-center justify-center">
                  <Twitter className="w-5 h-5 text-sky-500" />
                </div>
                <div className="flex-1">
                  <div className="font-medium text-sm">Twitter</div>
                  <div className="text-xs text-gray-500">3.2K followers</div>
                </div>
              </div>
              <div className="text-xs text-gray-600">Avg. engagement: 3.1%</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button className="bg-white border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors">
              <BarChart3 className="w-5 h-5 mx-auto mb-2 text-indigo-600" />
              <div className="text-xs font-medium">Analytics</div>
            </button>
            <button className="bg-white border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors">
              <Image className="w-5 h-5 mx-auto mb-2 text-purple-600" />
              <div className="text-xs font-medium">Media</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
