import { Search, Plus, Edit, MoreVertical, Users, Calendar, Zap, Filter } from "lucide-react";
import { useState } from "react";

export function TrainingProgramsPage() {
  const [activeTab, setActiveTab] = useState<"active" | "templates">("active");

  const activePrograms = [
    {
      id: 1,
      name: "Hypertrophy Phase II",
      client: {
        name: "Marcus Chen",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
      },
      progress: 65,
      weeksTotal: 8,
      startDate: "Oct 15, 2023",
      lastEdited: "Yesterday",
      color: "bg-purple-100 text-purple-700",
      icon: "A",
    },
    {
      id: 2,
      name: "Functional Power",
      client: {
        name: "Sarah Jenkins",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
      },
      progress: 45,
      weeksTotal: 12,
      startDate: "Oct 20, 2023",
      lastEdited: "Yesterday",
      color: "bg-orange-100 text-orange-700",
      icon: "B",
    },
    {
      id: 3,
      name: "Metabolic Reset",
      client: {
        name: "David Miller",
        avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400",
      },
      progress: 80,
      weeksTotal: 6,
      startDate: "Sep 28, 2023",
      lastEdited: "2h ago",
      color: "bg-blue-100 text-blue-700",
      icon: "C",
    },
  ];

  const masterTemplates = [
    {
      id: 1,
      name: "Body Recomp v3",
      description: "12-week evidence-based hypertrophy program with cardio integration.",
      uses: 8,
      weeks: 12,
      color: "bg-indigo-600",
      badge: "UPDATED",
    },
    {
      id: 2,
      name: "PowerBuilding Peak",
      description: "8-week strength-focused periodization plan integrating dynamic movements.",
      uses: 15,
      weeks: 8,
      color: "bg-purple-600",
      badge: "NEW",
    },
    {
      id: 3,
      name: "Hybrid Athlete v2",
      description: "10-week concurrent training template that balances strength and aerobic capacity.",
      uses: 12,
      weeks: 10,
      color: "bg-orange-600",
      badge: "TRENDING",
    },
  ];

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-3xl font-bold mb-2">Program Library</h2>
            <p className="text-gray-600">Manage and organize your coaching templates.</p>
          </div>
          <button className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-lg hover:bg-indigo-700 transition-colors">
            <Plus className="w-4 h-4" />
            Create New Program
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-8 mb-8 border-b border-gray-200">
        <button
          onClick={() => setActiveTab("active")}
          className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
            activeTab === "active"
              ? "border-indigo-600 text-indigo-600"
              : "border-transparent text-gray-600 hover:text-gray-900"
          }`}
        >
          Active Client Programs
        </button>
        <button
          onClick={() => setActiveTab("templates")}
          className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
            activeTab === "templates"
              ? "border-indigo-600 text-indigo-600"
              : "border-transparent text-gray-600 hover:text-gray-900"
          }`}
        >
          Master Templates
        </button>
      </div>

      {/* Active Programs View */}
      {activeTab === "active" && (
        <div>
          {/* Search and Filter */}
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search programs..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-white hover:bg-gray-50 transition-colors">
              <Filter className="w-4 h-4" />
              Filters
            </button>
          </div>

          {/* Programs Table */}
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Program Name
                  </th>
                  <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Assigned Client
                  </th>
                  <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Progress
                  </th>
                  <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Last Edited
                  </th>
                  <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {activePrograms.map((program) => (
                  <tr key={program.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg ${program.color} flex items-center justify-center font-bold`}>
                          {program.icon}
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{program.name}</div>
                          <div className="text-xs text-gray-500">
                            {program.weeksTotal} weeks • Started {program.startDate}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <img
                          src={program.client.avatar}
                          alt={program.client.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <span className="text-sm text-gray-700">{program.client.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[120px]">
                          <div
                            className="bg-indigo-600 h-2 rounded-full"
                            style={{ width: `${program.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-600">{program.progress}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-600">{program.lastEdited}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button className="p-2 hover:bg-indigo-50 rounded-lg transition-colors text-indigo-600">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-600">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* View All Link */}
          <div className="mt-4">
            <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
              View All Active Programs (29 total)
            </button>
          </div>
        </div>
      )}

      {/* Master Templates View */}
      {activeTab === "templates" && (
        <div>
          {/* Template Actions */}
          <div className="flex items-center gap-3 mb-6">
            <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-gray-50 transition-colors">
              All
            </button>
            <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-gray-50 transition-colors">
              Strength
            </button>
            <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-gray-50 transition-colors">
              Endurance
            </button>
          </div>

          {/* Templates Grid */}
          <div className="grid grid-cols-3 gap-6">
            {masterTemplates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg hover:border-indigo-300 transition-all cursor-pointer group"
              >
                {/* Template Header */}
                <div className={`${template.color} p-6 text-white relative`}>
                  <div className="absolute top-3 right-3">
                    <span className="bg-white/20 backdrop-blur-sm px-2 py-1 rounded text-xs font-medium">
                      {template.badge}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-5 h-5" />
                    <h3 className="font-bold text-lg">{template.name}</h3>
                  </div>
                  <p className="text-sm text-white/90 line-clamp-2">{template.description}</p>
                </div>

                {/* Template Info */}
                <div className="p-5">
                  <div className="flex items-center justify-between text-sm mb-4">
                    <div className="flex items-center gap-1 text-gray-600">
                      <Users className="w-4 h-4" />
                      <span>{template.uses} clients</span>
                    </div>
                    <div className="flex items-center gap-1 text-gray-600">
                      <Calendar className="w-4 h-4" />
                      <span>{template.weeks} weeks</span>
                    </div>
                  </div>
                  <button className="w-full bg-indigo-600 text-white py-2.5 rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium">
                    Use Template
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
