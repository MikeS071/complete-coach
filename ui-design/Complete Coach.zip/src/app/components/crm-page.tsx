import { Search, Plus, Mail, Phone, Calendar, MapPin, Tag, Clock, GripVertical } from "lucide-react";
import { useState } from "react";

interface Lead {
  id: number;
  name: string;
  email: string;
  phone: string;
  source: string;
  lastContact: string;
  notes: string;
  location: string;
  status: "hot" | "warm" | "cold";
  stage: string;
  daysInStage: number;
  avatar?: string;
}

export function CRMPage() {
  const [leads, setLeads] = useState<Lead[]>([
    {
      id: 1,
      name: "Jessica Martinez",
      email: "jessica.m@email.com",
      phone: "+1 (555) 123-4567",
      status: "hot",
      source: "Instagram",
      lastContact: "2 days ago",
      notes: "Interested in premium package",
      location: "Los Angeles, CA",
      stage: "initial-contact",
      daysInStage: 2,
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400",
    },
    {
      id: 2,
      name: "Michael Chen",
      email: "m.chen@email.com",
      phone: "+1 (555) 234-5678",
      status: "warm",
      source: "Referral",
      lastContact: "5 days ago",
      notes: "Looking for weight loss program",
      location: "San Francisco, CA",
      stage: "consultation",
      daysInStage: 5,
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
    },
    {
      id: 3,
      name: "Amanda Foster",
      email: "amanda.foster@email.com",
      phone: "+1 (555) 345-6789",
      status: "cold",
      source: "Website",
      lastContact: "2 weeks ago",
      notes: "Requested information packet",
      location: "Seattle, WA",
      stage: "initial-contact",
      daysInStage: 14,
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
    },
    {
      id: 4,
      name: "David Thompson",
      email: "d.thompson@email.com",
      phone: "+1 (555) 456-7890",
      status: "hot",
      source: "Facebook",
      lastContact: "1 day ago",
      notes: "Ready to start immediately",
      location: "Austin, TX",
      stage: "proposal",
      daysInStage: 1,
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
    },
    {
      id: 5,
      name: "Sarah Johnson",
      email: "sarah.j@email.com",
      phone: "+1 (555) 567-8901",
      status: "warm",
      source: "Instagram",
      lastContact: "4 days ago",
      notes: "Interested in nutrition coaching",
      location: "Miami, FL",
      stage: "negotiation",
      daysInStage: 4,
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
    },
    {
      id: 6,
      name: "Robert Lee",
      email: "r.lee@email.com",
      phone: "+1 (555) 678-9012",
      status: "hot",
      source: "Referral",
      lastContact: "3 hours ago",
      notes: "Former athlete, needs strength training",
      location: "Denver, CO",
      stage: "consultation",
      daysInStage: 1,
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400",
    },
    {
      id: 7,
      name: "Emily Rodriguez",
      email: "emily.r@email.com",
      phone: "+1 (555) 789-0123",
      status: "warm",
      source: "Website",
      lastContact: "1 week ago",
      notes: "Wants meal planning service",
      location: "Portland, OR",
      stage: "proposal",
      daysInStage: 7,
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400",
    },
  ]);

  const [draggedLead, setDraggedLead] = useState<Lead | null>(null);

  const statusConfig = {
    hot: { label: "Hot", color: "bg-red-100 text-red-700 border-red-200" },
    warm: { label: "Warm", color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
    cold: { label: "Cold", color: "bg-blue-100 text-blue-700 border-blue-200" },
  };

  const pipelineStages = [
    { id: "initial-contact", title: "Initial Contact", color: "bg-gray-50" },
    { id: "consultation", title: "Consultation Scheduled", color: "bg-blue-50" },
    { id: "proposal", title: "Proposal Sent", color: "bg-purple-50" },
    { id: "negotiation", title: "In Negotiation", color: "bg-yellow-50" },
    { id: "closed-won", title: "Closed - Won", color: "bg-green-50" },
  ];

  const getLeadsByStage = (stageId: string) => {
    return leads.filter(lead => lead.stage === stageId);
  };

  const handleDragStart = (lead: Lead) => {
    setDraggedLead(lead);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (stageId: string) => {
    if (!draggedLead) return;

    setLeads(prevLeads =>
      prevLeads.map(lead =>
        lead.id === draggedLead.id
          ? { ...lead, stage: stageId, daysInStage: 0 }
          : lead
      )
    );

    setDraggedLead(null);
  };

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Client Relationship Management</h2>
        <p className="text-gray-600">Manage leads and track client acquisition pipeline</p>
      </div>

      {/* Action Bar */}
      <div className="flex items-center justify-between mb-6">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search leads..."
            className="pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm w-80 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Add Lead Button */}
        <button className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-lg hover:bg-indigo-700 transition-colors">
          <Plus className="w-4 h-4" />
          Add New Lead
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-5 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Total Leads</div>
          <div className="text-3xl font-bold text-gray-900">{leads.length}</div>
        </div>
        <div className="bg-white rounded-xl p-5 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Hot Leads</div>
          <div className="text-3xl font-bold text-red-600">
            {leads.filter(l => l.status === "hot").length}
          </div>
        </div>
        <div className="bg-white rounded-xl p-5 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Warm Leads</div>
          <div className="text-3xl font-bold text-yellow-600">
            {leads.filter(l => l.status === "warm").length}
          </div>
        </div>
        <div className="bg-white rounded-xl p-5 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Cold Leads</div>
          <div className="text-3xl font-bold text-blue-600">
            {leads.filter(l => l.status === "cold").length}
          </div>
        </div>
      </div>

      {/* Pipeline Kanban Board */}
      <div className="overflow-x-auto pb-4">
        <div className="flex gap-4 min-h-[600px]">
          {pipelineStages.map((stage) => (
            <div
              key={stage.id}
              className={`${stage.color} rounded-xl p-4 min-w-[320px] flex flex-col border border-gray-200`}
              onDragOver={handleDragOver}
              onDrop={() => handleDrop(stage.id)}
            >
              {/* Stage Header */}
              <div className="mb-4">
                <h3 className="font-semibold text-gray-900 mb-1">{stage.title}</h3>
                <p className="text-xs text-gray-500">
                  {getLeadsByStage(stage.id).length} lead{getLeadsByStage(stage.id).length !== 1 ? 's' : ''}
                </p>
              </div>

              {/* Lead Cards */}
              <div className="flex-1 space-y-3 overflow-y-auto">
                {getLeadsByStage(stage.id).map((lead) => (
                  <div
                    key={lead.id}
                    draggable
                    onDragStart={() => handleDragStart(lead)}
                    className="bg-white rounded-lg p-4 border-2 border-gray-200 cursor-move hover:shadow-lg transition-all group"
                  >
                    {/* Lead Header */}
                    <div className="flex items-start gap-3 mb-3">
                      <GripVertical className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <img
                        src={lead.avatar}
                        alt={lead.name}
                        className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-gray-900 truncate">{lead.name}</h4>
                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3" />
                          {lead.location}
                        </p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs font-medium border ${statusConfig[lead.status].color} flex-shrink-0`}>
                        {statusConfig[lead.status].label}
                      </span>
                    </div>

                    {/* Notes */}
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">{lead.notes}</p>

                    {/* Contact Info */}
                    <div className="space-y-1.5 mb-3 text-xs">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Mail className="w-3.5 h-3.5 flex-shrink-0" />
                        <span className="truncate">{lead.email}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="w-3.5 h-3.5 flex-shrink-0" />
                        <span>{lead.phone}</span>
                      </div>
                    </div>

                    {/* Meta Info */}
                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Tag className="w-3.5 h-3.5" />
                          <span>{lead.source}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{lead.daysInStage}d in stage</span>
                        </div>
                      </div>
                    </div>

                    {/* Last Contact */}
                    <div className="mt-2 pt-2 border-t border-gray-100">
                      <p className="text-xs text-gray-500">
                        Last contact: <span className="font-medium text-gray-700">{lead.lastContact}</span>
                      </p>
                    </div>

                    {/* Quick Actions */}
                    <div className="flex gap-2 mt-3">
                      <button className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-indigo-50 hover:bg-indigo-100 rounded text-indigo-600 transition-colors">
                        <Mail className="w-3.5 h-3.5" />
                        <span className="text-xs font-medium">Email</span>
                      </button>
                      <button className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-green-50 hover:bg-green-100 rounded text-green-600 transition-colors">
                        <Phone className="w-3.5 h-3.5" />
                        <span className="text-xs font-medium">Call</span>
                      </button>
                      <button className="flex items-center justify-center px-2 py-1.5 bg-purple-50 hover:bg-purple-100 rounded text-purple-600 transition-colors">
                        <Calendar className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
