import { Search, Plus, Edit, MoreVertical, Calendar, Download } from "lucide-react";
import { useState } from "react";

export function MealPlansPage() {
  const [activeTab, setActiveTab] = useState<"active" | "templates">("active");

  const activeAssignments = [
    {
      id: 1,
      clientName: "James S. Miller",
      planName: "Hypertrophy Phase II",
      calories: 2800,
      protein: 210,
      carbs: 280,
      fats: 93,
      started: "Oct 15, 2023",
    },
    {
      id: 2,
      clientName: "Sarah Jenkins",
      planName: "Summer Shred v1",
      calories: 1800,
      protein: 140,
      carbs: 150,
      fats: 60,
      started: "Oct 12, 2023",
    },
  ];

  const masterTemplates = [
    {
      id: 1,
      name: "High-Protein Breakfast Bowl",
      description: "Protein-rich morning meal",
      image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop",
      calories: 520,
      protein: 35,
      carbs: 48,
      fats: 18,
    },
    {
      id: 2,
      name: "Performance Pre-Bed Meal",
      description: "Slow-digesting protein meal",
      image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=400&h=300&fit=crop",
      calories: 380,
      protein: 28,
      carbs: 32,
      fats: 14,
    },
    {
      id: 3,
      name: "Classic Optimization Bowl",
      description: "Balanced macro meal",
      image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop",
      calories: 650,
      protein: 42,
      carbs: 58,
      fats: 22,
    },
  ];

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold mb-2">Meal Plan Library</h2>
            <p className="text-gray-600">Manage client nutrition protocols</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="px-4 py-2.5 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors text-sm font-medium">
              Recipes
            </button>
            <button className="px-4 py-2.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              Keto
            </button>
            <button className="px-4 py-2.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              Low
            </button>
            <button className="px-4 py-2.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              Moderate
            </button>
            <button className="px-4 py-2.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              High
            </button>
          </div>
        </div>

        {/* Hero Banner */}
        <div className="relative bg-gradient-to-r from-green-600 to-green-700 rounded-2xl overflow-hidden h-64 mb-8">
          <img
            src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=1200&h=400&fit=crop"
            alt="Master Nutrition Protocol"
            className="absolute inset-0 w-full h-full object-cover opacity-40"
          />
          <div className="relative z-10 p-8 flex items-center justify-between h-full">
            <div className="text-white">
              <h3 className="text-3xl font-bold mb-2">Master Nutrition Protocol 2024</h3>
              <p className="text-green-100 text-lg">Complete evidence-based meal planning system</p>
            </div>
            <button className="bg-white text-green-700 px-6 py-3 rounded-lg hover:bg-green-50 transition-colors font-medium flex items-center gap-2">
              <Download className="w-4 h-4" />
              Access Protocol
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("active")}
            className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "active"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Active Client Assignments
          </button>
          <button
            onClick={() => setActiveTab("templates")}
            className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "templates"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Master Nutrition Templates
          </button>
        </div>
        {activeTab === "active" && (
          <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
            View All Active →
          </button>
        )}
      </div>

      {/* Active Assignments View */}
      {activeTab === "active" && (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Assigned Client
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Meal Plan Protocol
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Calories
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Protein
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Carbs
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Fats
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Started
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {activeAssignments.map((assignment) => (
                <tr key={assignment.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <span className="font-medium text-gray-900">{assignment.clientName}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-700">{assignment.planName}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-700">{assignment.calories}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-blue-600 font-medium">{assignment.protein}g</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-green-600 font-medium">{assignment.carbs}g</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-orange-600 font-medium">{assignment.fats}g</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">{assignment.started}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-indigo-50 rounded-lg transition-colors text-indigo-600">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-600">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Master Templates View */}
      {activeTab === "templates" && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-gray-50 transition-colors">
                All
              </button>
              <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-gray-50 transition-colors">
                Strength
              </button>
              <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-gray-50 transition-colors">
                Endurance
              </button>
            </div>
            <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
              View All →
            </button>
          </div>

          <div className="grid grid-cols-3 gap-6">
            {masterTemplates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg hover:border-indigo-300 transition-all cursor-pointer"
              >
                <div className="relative h-48 bg-gray-900 overflow-hidden">
                  <img
                    src={template.image}
                    alt={template.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-gray-900 mb-1">{template.name}</h3>
                  <p className="text-sm text-gray-500 mb-4">{template.description}</p>

                  <div className="flex items-center justify-between mb-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-600">{template.calories} cal</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs mb-4">
                    <div>
                      <span className="text-blue-600 font-medium">{template.protein}g</span>
                      <span className="text-gray-500 ml-1">PRO</span>
                    </div>
                    <div>
                      <span className="text-green-600 font-medium">{template.carbs}g</span>
                      <span className="text-gray-500 ml-1">CARB</span>
                    </div>
                    <div>
                      <span className="text-orange-600 font-medium">{template.fats}g</span>
                      <span className="text-gray-500 ml-1">FAT</span>
                    </div>
                  </div>

                  <button className="w-full bg-indigo-600 text-white py-2.5 rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium flex items-center justify-center gap-2">
                    <Plus className="w-4 h-4" />
                    Use Template
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
