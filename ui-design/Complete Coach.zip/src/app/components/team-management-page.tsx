import { UserPlus, Mail, Phone, MoreVertical, Clock, CheckCircle } from "lucide-react";

export function TeamManagementPage() {
  const teamMembers = [
    {
      id: 1,
      name: "Alex Rodriguez",
      role: "Strength Coach",
      email: "alex@completecoach.com",
      phone: "(555) 123-4567",
      status: "active",
      clients: 18,
      image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwZml0bmVzcyUyMGNvYWNofGVufDF8fHx8MTc0NTE2MDAwMHww&ixlib=rb-4.1.0&q=80&w=400",
    },
    {
      id: 2,
      name: "Maya Patel",
      role: "Nutritionist",
      email: "maya@completecoach.com",
      phone: "(555) 234-5678",
      status: "active",
      clients: 24,
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBudXRyaXRpb25pc3R8ZW58MXx8fHwxNzQ1MTYwMDAwfDA&ixlib=rb-4.1.0&q=80&w=400",
    },
    {
      id: 3,
      name: "Jordan Lee",
      role: "Cardio Specialist",
      email: "jordan@completecoach.com",
      phone: "(555) 345-6789",
      status: "active",
      clients: 15,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc0NTE2MDAwMHww&ixlib=rb-4.1.0&q=80&w=400",
    },
    {
      id: 4,
      name: "Sofia Martinez",
      role: "Admin Assistant",
      email: "sofia@completecoach.com",
      phone: "(555) 456-7890",
      status: "away",
      clients: 0,
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzQ1MTYwMDAwfDA&ixlib=rb-4.1.0&q=80&w=400",
    },
  ];

  const tasks = [
    { id: 1, assignee: "Alex Rodriguez", task: "Review Marcus Chen's program", dueDate: "Today" },
    { id: 2, assignee: "Maya Patel", task: "Create meal plans for 3 new clients", dueDate: "Tomorrow" },
    { id: 3, assignee: "Jordan Lee", task: "Conduct group cardio class", dueDate: "Wed, Oct 26" },
  ];

  return (
    <div className="p-8">
      {/* Page Title */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Team Management</h2>
        <p className="text-gray-600">Manage your coaching team and coordinate workloads.</p>
      </div>

      {/* Team Stats */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Total Team Members</div>
          <div className="text-3xl font-bold">4</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Active Coaches</div>
          <div className="text-3xl font-bold">3</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Total Clients</div>
          <div className="text-3xl font-bold">57</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Avg. Load</div>
          <div className="text-3xl font-bold">68%</div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-3 gap-6">
        {/* Team Members List */}
        <div className="col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Team Members</h3>
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition-colors flex items-center gap-2">
              <UserPlus className="w-4 h-4" />
              Add Member
            </button>
          </div>

          <div className="space-y-4">
            {teamMembers.map((member) => (
              <div key={member.id} className="bg-white rounded-xl p-5 border border-gray-200">
                <div className="flex items-start gap-4">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold">{member.name}</h4>
                      <span className={`text-xs px-2 py-1 rounded ${
                        member.status === "active"
                          ? "bg-green-100 text-green-700"
                          : "bg-yellow-100 text-yellow-700"
                      }`}>
                        {member.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{member.role}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Mail className="w-4 h-4" />
                        <span>{member.email}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Phone className="w-4 h-4" />
                        <span>{member.phone}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-indigo-600">{member.clients}</div>
                    <div className="text-xs text-gray-500">Clients</div>
                  </div>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <MoreVertical className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Task Assignment & Quick Actions */}
        <div>
          <h3 className="text-xl font-bold mb-4">Assigned Tasks</h3>

          <div className="space-y-3 mb-6">
            {tasks.map((task) => (
              <div key={task.id} className="bg-white rounded-xl p-4 border border-gray-200">
                <div className="flex items-start gap-2 mb-2">
                  <CheckCircle className="w-4 h-4 text-gray-300 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium mb-1">{task.task}</p>
                    <p className="text-xs text-gray-500 mb-2">{task.assignee}</p>
                    <div className="flex items-center gap-1 text-xs text-gray-400">
                      <Clock className="w-3 h-3" />
                      <span>{task.dueDate}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button className="w-full bg-black text-white py-3 rounded-lg text-sm hover:bg-gray-800 transition-colors mb-4">
            VIEW ALL TASKS
          </button>

          <div className="bg-white rounded-xl p-5 border border-gray-200">
            <h4 className="font-semibold text-sm mb-3">Team Capacity</h4>
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Alex Rodriguez</span>
                  <span className="text-xs font-medium">72%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div className="bg-indigo-600 h-2 rounded-full" style={{ width: "72%" }} />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Maya Patel</span>
                  <span className="text-xs font-medium">96%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div className="bg-orange-500 h-2 rounded-full" style={{ width: "96%" }} />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Jordan Lee</span>
                  <span className="text-xs font-medium">60%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: "60%" }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
