import { Plus, Filter, Search, Users, TrendingUp, Apple, Flame } from "lucide-react";

export function NutritionPage() {
  const mealPlans = [
    {
      id: 1,
      name: "High Performance Macro Split",
      clients: 18,
      calories: "2800-3200",
      macros: { protein: 40, carbs: 35, fats: 25 },
      adherence: 88,
    },
    {
      id: 2,
      name: "Lean Muscle Building",
      clients: 12,
      calories: "2400-2800",
      macros: { protein: 35, carbs: 40, fats: 25 },
      adherence: 92,
    },
    {
      id: 3,
      name: "Endurance Athlete Fuel",
      clients: 9,
      calories: "3000-3500",
      macros: { protein: 25, carbs: 55, fats: 20 },
      adherence: 85,
    },
    {
      id: 4,
      name: "Body Recomposition",
      clients: 14,
      calories: "2000-2400",
      macros: { protein: 45, carbs: 30, fats: 25 },
      adherence: 90,
    },
  ];

  const recentLogs = [
    { client: "Sarah Martinez", meal: "Breakfast", calories: 620, time: "1h ago", status: "on-track" },
    { client: "Alex Johnson", meal: "Post-Workout", calories: 450, time: "2h ago", status: "on-track" },
    { client: "Emily Davis", meal: "Lunch", calories: 780, time: "3h ago", status: "over" },
    { client: "Michael Lee", meal: "Dinner", calories: 550, time: "5h ago", status: "under" },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold mb-2">Nutrition Plans</h2>
          <p className="text-gray-600">Design meal plans and track client nutrition</p>
        </div>
        <button className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Create Meal Plan
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
              <Apple className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">53</div>
          <div className="text-sm text-gray-600">Active Meal Plans</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
              <Flame className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">89%</div>
          <div className="text-sm text-gray-600">Avg. Adherence</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">428</div>
          <div className="text-sm text-gray-600">Meals Logged Today</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">+12%</div>
          <div className="text-sm text-gray-600">Compliance vs Last Week</div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search meal plans..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <Filter className="w-4 h-4" />
          Filters
        </button>
      </div>

      {/* Meal Plans Grid */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        {mealPlans.map((plan) => (
          <div key={plan.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-40 bg-gradient-to-br from-green-500 to-emerald-600 relative overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1606859191214-25806e8e2423?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwbWVhbCUyMHByZXAlMjBudXRyaXRpb258ZW58MXx8fHwxNzc2NjcxNDY5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt={plan.name}
                className="w-full h-full object-cover opacity-40"
              />
              <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
                {plan.clients} athletes
              </div>
            </div>
            <div className="p-6">
              <h3 className="font-bold text-lg mb-3">{plan.name}</h3>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-gray-600">Daily Calories</span>
                  <span className="font-semibold">{plan.calories}</span>
                </div>
                <div className="space-y-2">
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-gray-600">Protein</span>
                      <span className="font-medium">{plan.macros.protein}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${plan.macros.protein}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-gray-600">Carbs</span>
                      <span className="font-medium">{plan.macros.carbs}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div className="bg-green-500 h-1.5 rounded-full" style={{ width: `${plan.macros.carbs}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-gray-600">Fats</span>
                      <span className="font-medium">{plan.macros.fats}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div className="bg-orange-500 h-1.5 rounded-full" style={{ width: `${plan.macros.fats}%` }} />
                    </div>
                  </div>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Adherence Rate</span>
                  <span className="font-medium text-green-600">{plan.adherence}%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div
                    className="bg-green-600 h-2 rounded-full transition-all"
                    style={{ width: `${plan.adherence}%` }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors">
                  View Plan
                </button>
                <button className="px-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  Edit
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Meal Logs */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="font-bold text-lg mb-4">Recent Meal Logs</h3>
        <div className="space-y-4">
          {recentLogs.map((log, i) => (
            <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Apple className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <div className="font-medium">{log.client}</div>
                  <div className="text-sm text-gray-500">{log.meal} - {log.calories} cal</div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <span className="text-sm text-gray-500">{log.time}</span>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  log.status === 'on-track' ? 'bg-green-100 text-green-700' :
                  log.status === 'over' ? 'bg-orange-100 text-orange-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  {log.status === 'on-track' ? 'On Track' : log.status === 'over' ? 'Over Target' : 'Under Target'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
