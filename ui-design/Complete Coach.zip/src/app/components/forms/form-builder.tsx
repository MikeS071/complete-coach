import { useState } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import {
  ArrowLeft,
  Search,
  Bell,
  Settings as SettingsIcon,
  AlignLeft,
  AlignJustify,
  CheckSquare,
  Phone,
  Mail,
  Calendar,
  Image as ImageIcon,
  ChevronDown,
  Check,
  Plus,
  Eye,
  Send,
  Grip,
  Trash2,
} from "lucide-react";
import { FormElement } from "./form-element";
import { DraggableFormElement } from "./draggable-form-element";

interface FormBuilderProps {
  onBack: () => void;
  formId: string | null;
}

export function FormBuilder({ onBack, formId }: FormBuilderProps) {
  const [formFields, setFormFields] = useState([
    {
      id: "field-1",
      type: "short-text",
      label: "Full Legal Name",
      placeholder: "e.g. Johnathan",
      required: true,
    },
    {
      id: "field-2",
      type: "multiple-choice",
      label: "Current Activity Level",
      options: ["Sedentary (Office job, no exercise)", "Moderately Active (3-5 workouts per week)"],
      required: false,
    },
  ]);

  const [headerImage, setHeaderImage] = useState(
    "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxneW0lMjBlcXVpcG1lbnQlMjBmaXRuZXNzfGVufDF8fHx8MTc0NTE2MDAwMHww&ixlib=rb-4.1.0&q=80&w=1080"
  );
  const [primaryColor, setPrimaryColor] = useState("#6366f1"); // Indigo
  const [successMessage, setSuccessMessage] = useState(
    "Thanks for applying! Our elite performance team will review your application within 24 hours."
  );

  const formElements = [
    { id: "short-text", label: "Short Text", icon: AlignLeft, color: "bg-indigo-50 text-indigo-600" },
    { id: "long-text", label: "Long Text", icon: AlignJustify, color: "bg-orange-50 text-orange-600" },
    { id: "multiple-choice", label: "Multiple Choice", icon: CheckSquare, color: "bg-blue-50 text-blue-600" },
    { id: "phone", label: "Phone Number", icon: Phone, color: "bg-green-50 text-green-600" },
    { id: "email", label: "Email", icon: Mail, color: "bg-purple-50 text-purple-600" },
    { id: "date", label: "Date of Birth", icon: Calendar, color: "bg-red-50 text-red-600" },
    { id: "photo", label: "Photo Upload", icon: ImageIcon, color: "bg-yellow-50 text-yellow-600" },
    { id: "dropdown", label: "Dropdown", icon: ChevronDown, color: "bg-teal-50 text-teal-600" },
    { id: "checkbox", label: "Checkbox", icon: Check, color: "bg-pink-50 text-pink-600" },
  ];

  const colorOptions = [
    { value: "#6366f1", label: "Indigo" },
    { value: "#f97316", label: "Orange" },
    { value: "#10b981", label: "Green" },
    { value: "#1f2937", label: "Dark" },
  ];

  const handleAddField = (elementType: string) => {
    const newField = {
      id: `field-${Date.now()}`,
      type: elementType,
      label: `New ${elementType.replace("-", " ")} field`,
      placeholder: "",
      required: false,
      options: elementType === "multiple-choice" ? ["Option 1"] : undefined,
    };
    setFormFields([...formFields, newField]);
  };

  const handleRemoveField = (fieldId: string) => {
    setFormFields(formFields.filter((field) => field.id !== fieldId));
  };

  const handleUpdateField = (fieldId: string, updates: any) => {
    setFormFields(formFields.map((field) => (field.id === fieldId ? { ...field, ...updates } : field)));
  };

  const handleMoveField = (dragIndex: number, hoverIndex: number) => {
    const updatedFields = [...formFields];
    const [movedField] = updatedFields.splice(dragIndex, 1);
    updatedFields.splice(hoverIndex, 0, movedField);
    setFormFields(updatedFields);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-screen flex flex-col bg-gray-50">
        {/* Top Navigation */}
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div>
              <h1 className="font-bold text-lg">Form Builder</h1>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span>Drafts</span>
                <span>/</span>
                <span className="text-indigo-600">New Client Intake v2</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search components..."
                className="pl-9 pr-4 py-1.5 border border-gray-200 rounded-lg text-sm w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative">
              <Bell className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <SettingsIcon className="w-5 h-5 text-gray-600" />
            </button>
            <button className="bg-indigo-600 text-white px-5 py-2 rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium">
              Save Changes
            </button>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Sidebar - Form Elements */}
          <aside className="w-64 bg-white border-r border-gray-200 overflow-y-auto">
            <div className="p-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">
                FORM ELEMENTS
              </h3>
              <div className="space-y-2">
                {formElements.map((element) => (
                  <button
                    key={element.id}
                    onClick={() => handleAddField(element.id)}
                    className={`w-full ${element.color} rounded-lg p-3 flex items-center gap-3 hover:opacity-80 transition-opacity`}
                  >
                    <element.icon className="w-4 h-4" />
                    <span className="text-sm font-medium">{element.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Center - Form Preview */}
          <main className="flex-1 overflow-y-auto p-8">
            <div className="max-w-2xl mx-auto">
              {/* Form Preview Card */}
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                {/* Header Image */}
                <div className="relative h-48 overflow-hidden">
                  <img src={headerImage} alt="Form header" className="w-full h-full object-cover" />
                </div>

                {/* Form Content */}
                <div className="p-8">
                  <h2 className="text-3xl font-bold mb-2">New Client Intake</h2>
                  <p className="text-gray-600 mb-8">Please provide your details for</p>

                  {/* Form Fields */}
                  <div className="space-y-6">
                    {formFields.map((field, index) => (
                      <DraggableFormElement
                        key={field.id}
                        field={field}
                        index={index}
                        onMove={handleMoveField}
                        onRemove={() => handleRemoveField(field.id)}
                        onUpdate={(updates) => handleUpdateField(field.id, updates)}
                        primaryColor={primaryColor}
                      />
                    ))}

                    {/* Drop Zone */}
                    <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center">
                      <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Plus className="w-6 h-6 text-gray-400" />
                      </div>
                      <p className="text-sm text-gray-500 font-medium mb-1">
                        Drag and drop elements here to build your form
                      </p>
                      <p className="text-xs text-gray-400">
                        Or click on elements from the left sidebar
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>

          {/* Right Sidebar - Global Settings */}
          <aside className="w-80 bg-white border-l border-gray-200 overflow-y-auto">
            <div className="p-5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-4">
                GLOBAL SETTINGS
              </h3>

              {/* Form Header Image */}
              <div className="mb-6">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Form Header Image
                </label>
                <div className="relative rounded-lg overflow-hidden">
                  <img src={headerImage} alt="Header preview" className="w-full h-32 object-cover" />
                  <button className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all flex items-center justify-center">
                    <ImageIcon className="w-6 h-6 text-white opacity-0 hover:opacity-100" />
                  </button>
                </div>
              </div>

              {/* Primary Color */}
              <div className="mb-6">
                <label className="text-sm font-medium text-gray-700 mb-2 block">Primary Color</label>
                <div className="flex gap-2">
                  {colorOptions.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setPrimaryColor(color.value)}
                      className={`w-10 h-10 rounded-lg border-2 transition-all ${
                        primaryColor === color.value ? "border-gray-900 scale-110" : "border-gray-200"
                      }`}
                      style={{ backgroundColor: color.value }}
                    />
                  ))}
                </div>
              </div>

              {/* Success Message */}
              <div className="mb-6">
                <label className="text-sm font-medium text-gray-700 mb-2 block">Success Message</label>
                <textarea
                  value={successMessage}
                  onChange={(e) => setSuccessMessage(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  rows={4}
                />
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-4 border-t border-gray-200">
                <button className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2 text-sm font-medium">
                  <Eye className="w-4 h-4" />
                  Preview Form
                </button>
                <button
                  style={{ backgroundColor: primaryColor }}
                  className="w-full text-white py-3 rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2 text-sm font-medium"
                >
                  <Send className="w-4 h-4" />
                  Publish Form
                </button>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </DndProvider>
  );
}
