import { useRef } from "react";
import { useDrag, useDrop } from "react-dnd";
import { Grip, Trash2, Copy, Plus } from "lucide-react";

interface DraggableFormElementProps {
  field: any;
  index: number;
  onMove: (dragIndex: number, hoverIndex: number) => void;
  onRemove: () => void;
  onUpdate: (updates: any) => void;
  primaryColor: string;
}

export function DraggableFormElement({
  field,
  index,
  onMove,
  onRemove,
  onUpdate,
  primaryColor,
}: DraggableFormElementProps) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ handlerId }, drop] = useDrop({
    accept: "form-field",
    collect(monitor) {
      return {
        handlerId: monitor.getHandlerId(),
      };
    },
    hover(item: any, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.index;
      const hoverIndex = index;

      if (dragIndex === hoverIndex) {
        return;
      }

      const hoverBoundingRect = ref.current?.getBoundingClientRect();
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
      const clientOffset = monitor.getClientOffset();
      const hoverClientY = clientOffset!.y - hoverBoundingRect.top;

      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }

      onMove(dragIndex, hoverIndex);
      item.index = hoverIndex;
    },
  });

  const [{ isDragging }, drag, preview] = useDrag({
    type: "form-field",
    item: () => {
      return { id: field.id, index };
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  preview(drop(ref));

  const handleAddOption = () => {
    if (field.options) {
      onUpdate({ options: [...field.options, `Option ${field.options.length + 1}`] });
    }
  };

  return (
    <div
      ref={ref}
      data-handler-id={handlerId}
      className={`border-2 rounded-xl p-5 bg-white transition-all ${
        isDragging ? "opacity-50 border-indigo-400" : "border-gray-200 hover:border-indigo-300"
      }`}
    >
      <div className="flex items-start gap-3 mb-4">
        <button
          ref={drag}
          className="p-1.5 hover:bg-gray-100 rounded cursor-move flex-shrink-0 mt-1"
        >
          <Grip className="w-4 h-4 text-gray-400" />
        </button>
        <div className="flex-1">
          <div className="flex items-start gap-2 mb-2">
            <input
              type="text"
              value={field.label}
              onChange={(e) => onUpdate({ label: e.target.value })}
              className="flex-1 font-medium text-sm border-0 border-b border-transparent hover:border-gray-300 focus:border-indigo-500 focus:outline-none px-0 py-1"
              placeholder="Field Label"
            />
            <label className="flex items-center gap-2 cursor-pointer flex-shrink-0">
              <input
                type="checkbox"
                checked={field.required}
                onChange={(e) => onUpdate({ required: e.target.checked })}
                className="rounded"
                style={{ accentColor: primaryColor }}
              />
              <span className="text-xs text-gray-500 uppercase tracking-wider">REQ.</span>
            </label>
          </div>

          {/* Field Type Specific Rendering */}
          {field.type === "short-text" && (
            <div>
              <label className="text-xs text-gray-500 mb-1 block uppercase tracking-wider">
                Placeholder Text
              </label>
              <input
                type="text"
                value={field.placeholder || ""}
                onChange={(e) => onUpdate({ placeholder: e.target.value })}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="e.g. Johnathan"
              />
            </div>
          )}

          {field.type === "long-text" && (
            <div>
              <label className="text-xs text-gray-500 mb-1 block uppercase tracking-wider">
                Placeholder Text
              </label>
              <textarea
                value={field.placeholder || ""}
                onChange={(e) => onUpdate({ placeholder: e.target.value })}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                rows={3}
                placeholder="Enter description..."
              />
            </div>
          )}

          {field.type === "multiple-choice" && (
            <div>
              <label className="text-xs text-gray-500 mb-2 block uppercase tracking-wider">Options</label>
              <div className="space-y-2">
                {field.options?.map((option: string, idx: number) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name={`field-${field.id}`}
                      disabled
                      className="flex-shrink-0"
                      style={{ accentColor: primaryColor }}
                    />
                    <input
                      type="text"
                      value={option}
                      onChange={(e) => {
                        const newOptions = [...field.options];
                        newOptions[idx] = e.target.value;
                        onUpdate({ options: newOptions });
                      }}
                      className="flex-1 text-sm border-0 border-b border-transparent hover:border-gray-300 focus:border-indigo-500 focus:outline-none px-0 py-1"
                    />
                  </div>
                ))}
                <button
                  onClick={handleAddOption}
                  className="text-indigo-600 text-xs font-medium flex items-center gap-1 hover:text-indigo-700 mt-2"
                >
                  <Plus className="w-3 h-3" />
                  ADD OPTION
                </button>
              </div>
            </div>
          )}

          {field.type === "phone" && (
            <input
              type="tel"
              disabled
              placeholder="(555) 123-4567"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50"
            />
          )}

          {field.type === "email" && (
            <input
              type="email"
              disabled
              placeholder="your@email.com"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50"
            />
          )}

          {field.type === "date" && (
            <input
              type="date"
              disabled
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50"
            />
          )}

          {field.type === "photo" && (
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Plus className="w-5 h-5 text-gray-400" />
              </div>
              <p className="text-xs text-gray-500">Click or drag to upload</p>
            </div>
          )}

          {field.type === "dropdown" && (
            <select
              disabled
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50"
            >
              <option>Select an option...</option>
            </select>
          )}

          {field.type === "checkbox" && (
            <label className="flex items-center gap-2 cursor-not-allowed">
              <input
                type="checkbox"
                disabled
                className="rounded"
                style={{ accentColor: primaryColor }}
              />
              <span className="text-sm text-gray-700">Checkbox label</span>
            </label>
          )}
        </div>

        <div className="flex gap-1 flex-shrink-0">
          <button className="p-1.5 hover:bg-gray-100 rounded transition-colors">
            <Copy className="w-4 h-4 text-gray-400" />
          </button>
          <button
            onClick={onRemove}
            className="p-1.5 hover:bg-red-50 rounded transition-colors"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
          </button>
        </div>
      </div>
    </div>
  );
}
