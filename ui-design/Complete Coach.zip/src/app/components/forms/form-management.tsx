import { FileText, ClipboardList, CheckSquare, Users, Mail, MoreVertical } from "lucide-react";

interface FormManagementProps {
  onCreateForm: (templateType?: string) => void;
}

export function FormManagement({ onCreateForm }: FormManagementProps) {
  const formTemplates = [
    {
      id: "check-in",
      name: "Check-in Forms",
      description: "Track physique progress, energy levels, and weekly qualitative data.",
      icon: ClipboardList,
      color: "bg-indigo-50 text-indigo-600",
      tags: ["WEIGHT TRACKING", "PHOTO UPLOADS"],
    },
    {
      id: "habit-tracker",
      name: "Daily Habit Trackers",
      description: "Create recurring checklists for hydration, steps, and sleep targets.",
      icon: CheckSquare,
      color: "bg-orange-50 text-orange-600",
      tags: ["CHECKBOXES", "DAILY FREQUENCY"],
    },
    {
      id: "application",
      name: "Application Forms",
      description: "Qualify potential athletes with background info and health history.",
      icon: Users,
      color: "bg-green-50 text-green-600",
      tags: ["LONG TEXT", "FILE UPLOAD"],
    },
    {
      id: "contact",
      name: "Contact Forms",
      description: "Simple intake for general inquiries and feedback from your team.",
      icon: Mail,
      color: "bg-blue-50 text-blue-600",
      tags: ["SHORT ANSWER", "EMAIL FIELD"],
    },
  ];

  const recentForms = [
    {
      id: 1,
      name: "Weekly Performance Log",
      lastEdited: "2 HOURS AGO",
      responses: 14,
    },
    {
      id: 2,
      name: "Pre-Workout Supplement Survey",
      lastEdited: "1 DAY AGO",
      responses: 8,
    },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold mb-2">Create a New Form</h2>
          <p className="text-gray-600">Select a form type to start building from a specialized template.</p>
        </div>
        <button
          onClick={() => onCreateForm()}
          className="bg-black text-white px-6 py-2.5 rounded-lg hover:bg-gray-800 transition-colors text-sm font-medium"
        >
          Start from Scratch
        </button>
      </div>

      {/* Form Templates Grid */}
      <div className="grid grid-cols-4 gap-6 mb-12">
        {formTemplates.map((template) => (
          <button
            key={template.id}
            onClick={() => onCreateForm(template.id)}
            className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg hover:border-indigo-300 transition-all text-left group"
          >
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${template.color}`}>
              <template.icon className="w-6 h-6" />
            </div>
            <h3 className="font-semibold text-base mb-2 group-hover:text-indigo-600 transition-colors">
              {template.name}
            </h3>
            <p className="text-sm text-gray-600 mb-4 leading-relaxed">{template.description}</p>
            <div className="flex flex-wrap gap-1.5">
              {template.tags.map((tag, index) => (
                <span
                  key={index}
                  className="text-[10px] px-2 py-1 bg-gray-100 text-gray-600 rounded uppercase tracking-wide font-medium"
                >
                  {tag}
                </span>
              ))}
            </div>
          </button>
        ))}
      </div>

      {/* Recent Forms */}
      <div>
        <h3 className="text-sm font-bold uppercase tracking-wider text-gray-900 mb-4">RECENT FORMS</h3>
        <div className="space-y-3">
          {recentForms.map((form) => (
            <button
              key={form.id}
              onClick={() => onCreateForm(`edit-${form.id}`)}
              className="w-full bg-white rounded-lg border border-gray-200 p-4 hover:bg-gray-50 transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center group-hover:bg-indigo-50 transition-colors">
                  <FileText className="w-5 h-5 text-gray-600 group-hover:text-indigo-600 transition-colors" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-sm">{form.name}</div>
                  <div className="text-xs text-gray-500">
                    LAST EDITED {form.lastEdited} • {form.responses} RESPONSES
                  </div>
                </div>
              </div>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <MoreVertical className="w-4 h-4 text-gray-400" />
              </button>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
