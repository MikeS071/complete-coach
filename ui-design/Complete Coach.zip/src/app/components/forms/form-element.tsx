import { AlignLeft, AlignJustify, CheckSquare, Phone, Mail, Calendar, Image, ChevronDown, Check } from "lucide-react";

interface FormElementProps {
  type: string;
  label: string;
  color: string;
  onClick?: () => void;
}

export function FormElement({ type, label, color, onClick }: FormElementProps) {
  const icons: { [key: string]: any } = {
    "short-text": AlignLeft,
    "long-text": AlignJustify,
    "multiple-choice": CheckSquare,
    "phone": Phone,
    "email": Mail,
    "date": Calendar,
    "photo": Image,
    "dropdown": ChevronDown,
    "checkbox": Check,
  };

  const Icon = icons[type] || AlignLeft;

  return (
    <button
      onClick={onClick}
      className={`w-full ${color} rounded-lg p-3 flex items-center gap-3 hover:opacity-80 transition-opacity`}
    >
      <Icon className="w-4 h-4" />
      <span className="text-sm font-medium">{label}</span>
    </button>
  );
}
