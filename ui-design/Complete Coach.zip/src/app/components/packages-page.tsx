import { Package, DollarSign, Users, Star, TrendingUp, Edit, Copy, Trash2 } from "lucide-react";

export function PackagesPage() {
  const packages = [
    {
      id: 1,
      name: "Platinum Elite",
      price: 599,
      billing: "monthly",
      activeClients: 12,
      description: "Complete coaching with 24/7 support",
      features: [
        "Custom training programs",
        "Personalized meal plans",
        "Weekly check-ins",
        "24/7 text support",
        "Supplement guidance",
        "Progress tracking app"
      ],
      color: "indigo",
      revenue: 7188,
    },
    {
      id: 2,
      name: "Gold Standard",
      price: 399,
      billing: "monthly",
      activeClients: 18,
      description: "Premium coaching with weekly support",
      features: [
        "Custom training programs",
        "Macro tracking",
        "Bi-weekly check-ins",
        "Email support",
        "Group Q&A sessions"
      ],
      color: "yellow",
      revenue: 7182,
    },
    {
      id: 3,
      name: "Silver Start",
      price: 199,
      billing: "monthly",
      activeClients: 8,
      description: "Essential coaching for beginners",
      features: [
        "Template programs",
        "Basic nutrition guide",
        "Monthly check-ins",
        "Email support"
      ],
      color: "gray",
      revenue: 1592,
    },
    {
      id: 4,
      name: "12-Week Transform",
      price: 1499,
      billing: "one-time",
      activeClients: 4,
      description: "Intensive transformation program",
      features: [
        "12-week custom program",
        "Full meal planning",
        "Weekly video calls",
        "Priority support",
        "Before/after photos"
      ],
      color: "purple",
      revenue: 5996,
    },
  ];

  const colorClasses = {
    indigo: "bg-indigo-50 text-indigo-700 border-indigo-200",
    yellow: "bg-yellow-50 text-yellow-700 border-yellow-200",
    gray: "bg-gray-50 text-gray-700 border-gray-200",
    purple: "bg-purple-50 text-purple-700 border-purple-200",
  };

  const totalRevenue = packages.reduce((sum, pkg) => sum + pkg.revenue, 0);
  const totalClients = packages.reduce((sum, pkg) => sum + pkg.activeClients, 0);

  return (
    <div className="p-8">
      {/* Page Title */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Packages & Pricing</h2>
        <p className="text-gray-600">Manage your coaching packages and track revenue performance.</p>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase tracking-wider">Total Packages</span>
            <Package className="w-4 h-4 text-gray-400" />
          </div>
          <div className="text-3xl font-bold">{packages.length}</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase tracking-wider">Monthly Revenue</span>
            <DollarSign className="w-4 h-4 text-green-600" />
          </div>
          <div className="text-3xl font-bold">${totalRevenue.toLocaleString()}</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase tracking-wider">Active Clients</span>
            <Users className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-3xl font-bold">{totalClients}</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase tracking-wider">Avg. Package Price</span>
            <TrendingUp className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-3xl font-bold">${Math.round(packages.filter(p => p.billing === 'monthly').reduce((sum, p) => sum + p.price, 0) / packages.filter(p => p.billing === 'monthly').length)}</div>
        </div>
      </div>

      {/* Packages Grid */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold">All Packages</h3>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition-colors flex items-center gap-2">
          <Package className="w-4 h-4" />
          Create Package
        </button>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {packages.map((pkg) => (
          <div key={pkg.id} className={`rounded-xl p-6 border-2 ${colorClasses[pkg.color as keyof typeof colorClasses]}`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h4 className="text-xl font-bold mb-1">{pkg.name}</h4>
                <p className="text-sm opacity-80">{pkg.description}</p>
              </div>
              <div className="flex gap-2">
                <button className="p-2 hover:bg-white/50 rounded-lg transition-colors">
                  <Edit className="w-4 h-4" />
                </button>
                <button className="p-2 hover:bg-white/50 rounded-lg transition-colors">
                  <Copy className="w-4 h-4" />
                </button>
                <button className="p-2 hover:bg-white/50 rounded-lg transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="mb-4">
              <div className="text-4xl font-bold mb-1">
                ${pkg.price}
                <span className="text-lg font-normal opacity-70">/{pkg.billing === 'monthly' ? 'mo' : 'once'}</span>
              </div>
            </div>

            <div className="mb-4">
              <h5 className="text-xs font-semibold uppercase tracking-wider mb-2 opacity-70">Features</h5>
              <ul className="space-y-1.5">
                {pkg.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <Star className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-4 border-t border-current/20">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs opacity-70 mb-1">Active Clients</div>
                  <div className="text-2xl font-bold">{pkg.activeClients}</div>
                </div>
                <div>
                  <div className="text-xs opacity-70 mb-1">Revenue</div>
                  <div className="text-2xl font-bold">${pkg.revenue.toLocaleString()}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
