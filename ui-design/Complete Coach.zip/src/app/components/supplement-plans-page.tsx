import { useState } from "react";
import { Plus, Edit, MoreVertical, TrendingUp } from "lucide-react";

export function SupplementPlansPage() {
  const [activeTab, setActiveTab] = useState<"active" | "library">("active");

  const activeProtocols = [
    {
      id: 1,
      clientName: "Alex Rivera",
      protocol: "Vitamin D3 + K2",
      supplements: ["Vitamin D", "Vitamin K"],
      duration: "8 weeks/day",
      status: "Active",
      compliance: 95,
    },
    {
      id: 2,
      clientName: "James Chen",
      protocol: "Multi Hypertrophy Stack",
      supplements: ["Creatine", "Beta-Alanine", "L-Citrulline"],
      duration: "12 weeks/day",
      status: "In Review",
      compliance: 67,
    },
  ];

  const protocolLibrary = [
    {
      id: 1,
      name: "Vitamin D3 + K2",
      category: "General Health",
      description: "Bone health support and immune optimization. Essential for bone density and calcium absorption.",
      supplements: 2,
    },
    {
      id: 2,
      name: "Creatine Monohydrate",
      category: "Performance",
      description: "Strength and muscle mass support for high-intensity performance and cellular energy production and cellular health.",
      supplements: 1,
    },
    {
      id: 3,
      name: "Magnesium Bisglycinate",
      category: "Recovery",
      description: "Sleep quality and muscle recovery support. Improved sleep quality and reduced muscle cramps.",
      supplements: 1,
    },
  ];

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold mb-2">Supplementation Hub</h2>
            <p className="text-gray-600">Manage client protocols and track compliance</p>
          </div>
          <button className="flex items-center gap-2 bg-orange-500 text-white px-5 py-2.5 rounded-lg hover:bg-orange-600 transition-colors">
            <Plus className="w-4 h-4" />
            Assign Plan
          </button>
        </div>
      </div>

      {/* Compliance Stats */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm text-gray-500 uppercase tracking-wider">Protocol Compliance</h3>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <TrendingUp className="w-4 h-4 text-indigo-600" />
            </button>
          </div>
          <div className="mb-2">
            <div className="text-4xl font-bold text-gray-900 mb-1">94.2%</div>
            <div className="text-sm text-gray-500">37/39 clients adhering</div>
          </div>
          <div className="text-xs text-green-600 font-medium">
            +2.3% from last month (average protocol compliance)
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-xl p-6 text-white">
          <div className="mb-4">
            <div className="text-sm text-indigo-200 uppercase tracking-wider mb-2">Active Plans</div>
            <div className="text-4xl font-bold">5</div>
            <div className="text-sm text-indigo-200 mt-1">Clients</div>
          </div>
          <div className="text-xs text-indigo-200">Across 25% of total base</div>
        </div>

        <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl p-6 text-white">
          <div className="mb-4">
            <div className="text-sm text-purple-200 uppercase tracking-wider mb-2">Library</div>
            <div className="text-4xl font-bold">12</div>
            <div className="text-sm text-purple-200 mt-1">Protocols</div>
          </div>
          <div className="text-xs text-purple-200">Pending review across clients</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("active")}
            className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "active"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Active Protocols
          </button>
          <button
            onClick={() => setActiveTab("library")}
            className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "library"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Protocol Library
          </button>
        </div>
        {activeTab === "active" && (
          <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
            View Detailed Reports →
          </button>
        )}
        {activeTab === "library" && (
          <div className="flex items-center gap-2">
            <button className="text-sm text-gray-600 hover:text-gray-900">Vitamins</button>
            <button className="text-sm text-gray-600 hover:text-gray-900">Performance</button>
            <button className="text-sm text-gray-600 hover:text-gray-900">Recovery</button>
          </div>
        )}
      </div>

      {/* Active Protocols Table */}
      {activeTab === "active" && (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Client
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Primary Protocol
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Daily Stack
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Status
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Compliance
                </th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {activeProtocols.map((protocol) => (
                <tr key={protocol.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <span className="font-medium text-gray-900">{protocol.clientName}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-700">{protocol.protocol}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">{protocol.supplements.join(", ")}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                        protocol.status === "Active"
                          ? "bg-green-100 text-green-700"
                          : "bg-orange-100 text-orange-700"
                      }`}
                    >
                      {protocol.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                        <div
                          className={`h-2 rounded-full ${
                            protocol.compliance >= 90 ? "bg-green-600" : "bg-orange-600"
                          }`}
                          style={{ width: `${protocol.compliance}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600">{protocol.compliance}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-indigo-50 rounded-lg transition-colors text-indigo-600">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-600">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Protocol Library Grid */}
      {activeTab === "library" && (
        <div className="grid grid-cols-3 gap-6">
          {protocolLibrary.map((protocol) => (
            <div
              key={protocol.id}
              className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg hover:border-indigo-300 transition-all cursor-pointer"
            >
              <div className="flex items-start justify-between mb-4">
                <div
                  className={`w-12 h-12 rounded-lg flex items-center justify-center text-xl font-bold ${
                    protocol.category === "General Health"
                      ? "bg-green-100 text-green-700"
                      : protocol.category === "Performance"
                      ? "bg-purple-100 text-purple-700"
                      : "bg-blue-100 text-blue-700"
                  }`}
                >
                  {protocol.category === "General Health"
                    ? "🌟"
                    : protocol.category === "Performance"
                    ? "⚡"
                    : "🌙"}
                </div>
                <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                  {protocol.category}
                </span>
              </div>

              <h3 className="font-bold text-gray-900 mb-2">{protocol.name}</h3>
              <p className="text-sm text-gray-600 mb-4 line-clamp-3">{protocol.description}</p>

              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">{protocol.supplements} supplement{protocol.supplements !== 1 ? 's' : ''}</span>
                <button className="text-indigo-600 hover:text-indigo-700 font-medium">
                  View Details →
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
