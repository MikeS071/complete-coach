import { useState } from "react";
import { ChevronLeft, Upload, Plus, Minus } from "lucide-react";
import { useNavigate } from "react-router";

export function AddExercisePage() {
  const navigate = useNavigate();
  const [exerciseName, setExerciseName] = useState("");
  const [category, setCategory] = useState("Compound");
  const [equipment, setEquipment] = useState("Dumbbells");
  const [sets, setSets] = useState(3);
  const [targetReps, setTargetReps] = useState([8, 12]);
  const [selectedMuscles, setSelectedMuscles] = useState<string[]>(["Chest", "Shoulders"]);
  const [coachingCues, setCoachingCues] = useState([
    "Retract scapula",
    "Drive elbows to hips",
    "Control eccentric phase"
  ]);
  const [newCue, setNewCue] = useState("");

  const muscleGroups = [
    { name: "Chest", color: "blue" },
    { name: "Back", color: "gray" },
    { name: "Glutes", color: "gray" },
    { name: "Hamstrings", color: "gray" },
    { name: "Shoulders", color: "orange" },
    { name: "Triceps", color: "gray" },
    { name: "Torso", color: "gray" },
    { name: "Quads", color: "gray" },
  ];

  const toggleMuscle = (muscle: string) => {
    if (selectedMuscles.includes(muscle)) {
      setSelectedMuscles(selectedMuscles.filter(m => m !== muscle));
    } else {
      setSelectedMuscles([...selectedMuscles, muscle]);
    }
  };

  const addCoachingCue = () => {
    if (newCue.trim()) {
      setCoachingCues([...coachingCues, newCue]);
      setNewCue("");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/training/exercises")}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold">Add New Exercise</h1>
            </div>
          </div>
          <button className="bg-indigo-600 text-white px-6 py-2.5 rounded-lg hover:bg-indigo-700 transition-colors font-medium">
            Save Exercise
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-8 max-w-6xl mx-auto">
        <div className="grid grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Exercise Basics */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <span className="text-purple-600 font-bold text-sm">📝</span>
                </div>
                <h3 className="font-bold text-gray-900">Exercise Basics</h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Exercise Name
                  </label>
                  <input
                    type="text"
                    value={exerciseName}
                    onChange={(e) => setExerciseName(e.target.value)}
                    placeholder="e.g. Incline DB Press"
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option>Compound</option>
                      <option>Isolation</option>
                      <option>Cardio</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Equipment
                    </label>
                    <select
                      value={equipment}
                      onChange={(e) => setEquipment(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option>Dumbbells</option>
                      <option>Barbell</option>
                      <option>Machine</option>
                      <option>Cable</option>
                      <option>Bodyweight</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="mt-4 p-3 bg-orange-50 border border-orange-200 rounded-lg flex items-start gap-2">
                <span className="text-orange-600 text-xl">⚠️</span>
                <div className="text-xs text-orange-700">
                  <strong>Keep naming precise and clear</strong> to maintain searchability across clients
                </div>
              </div>
            </div>

            {/* Anatomy Filter */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-sm">🎯</span>
                </div>
                <h3 className="font-bold text-gray-900">Anatomy Filter</h3>
              </div>

              <p className="text-sm text-gray-600 mb-4">
                Filter anatomical targets for precise protocols
              </p>

              <div className="flex flex-wrap gap-2">
                {muscleGroups.map((muscle) => (
                  <button
                    key={muscle.name}
                    onClick={() => toggleMuscle(muscle.name)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      selectedMuscles.includes(muscle.name)
                        ? muscle.name === "Chest"
                          ? "bg-blue-600 text-white"
                          : muscle.name === "Shoulders"
                          ? "bg-orange-500 text-white"
                          : "bg-indigo-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    {muscle.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Volume Defaults */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <span className="text-purple-600 font-bold text-sm">📊</span>
                </div>
                <h3 className="font-bold text-gray-900">Volume Defaults</h3>
              </div>

              <div className="space-y-6">
                {/* Sets Counter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Sets
                  </label>
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => setSets(Math.max(1, sets - 1))}
                      className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <Minus className="w-4 h-4 text-gray-600" />
                    </button>
                    <div className="flex-1 text-center">
                      <div className="text-3xl font-bold text-gray-900">{sets}</div>
                    </div>
                    <button
                      onClick={() => setSets(sets + 1)}
                      className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <Plus className="w-4 h-4 text-gray-600" />
                    </button>
                  </div>
                  <div className="text-center mt-2">
                    <span className="text-xs text-gray-500 uppercase tracking-wider">Sets Per WO</span>
                  </div>
                </div>

                {/* Target Reps Range */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-sm font-medium text-gray-700">
                      Target Reps
                    </label>
                    <span className="text-sm font-bold text-gray-900">
                      {targetReps[0]} - {targetReps[1]}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    value={targetReps[1]}
                    onChange={(e) => setTargetReps([targetReps[0], parseInt(e.target.value)])}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-center">
                      <div className="text-xs text-gray-500 uppercase tracking-wider">Set Criteria</div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">90</div>
                    <div className="text-xs text-gray-500 mt-1">Target Sets</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">6</div>
                    <div className="text-xs text-gray-500 mt-1">Target Reps</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Video Demonstration */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <span className="text-indigo-600 font-bold text-sm">🎥</span>
                </div>
                <h3 className="font-bold text-gray-900">Video Demonstration</h3>
              </div>

              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-all cursor-pointer">
                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-8 h-8 text-indigo-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Upload Exercise Video</h4>
                <p className="text-sm text-gray-500 mb-4">
                  Maximum size 500MB • MP4, MOV
                </p>
                <button className="bg-white border border-gray-300 text-gray-700 px-6 py-2.5 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm">
                  SELECT FILE
                </button>
              </div>
            </div>

            {/* Coaching Cues/Notes */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <span className="text-green-600 font-bold text-sm">💡</span>
                </div>
                <h3 className="font-bold text-gray-900">Coaching Cues/Notes</h3>
              </div>

              <div className="space-y-2 mb-4">
                {coachingCues.map((cue, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-gray-50 rounded-lg">
                    <div className="w-5 h-5 bg-indigo-600 text-white rounded flex items-center justify-center text-xs font-bold mt-0.5 flex-shrink-0">
                      {index + 1}
                    </div>
                    <span className="text-sm text-gray-700 flex-1">{cue}</span>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newCue}
                  onChange={(e) => setNewCue(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && addCoachingCue()}
                  placeholder="Add a new coaching cue..."
                  className="flex-1 p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  onClick={addCoachingCue}
                  className="px-4 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              <button className="w-full mt-3 text-sm text-indigo-600 hover:text-indigo-700 font-medium">
                ADD MORE NOTE
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Action */}
        <div className="mt-8">
          <button
            onClick={() => navigate("/training/exercises")}
            className="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition-colors font-medium"
          >
            Save Exercise
          </button>
        </div>
      </div>
    </div>
  );
}
