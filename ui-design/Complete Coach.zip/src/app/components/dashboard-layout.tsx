import { Outlet, Link, useLocation } from "react-router";
import { LayoutGrid, Dumbbell, Apple, GraduationCap, Pill, Users, FileText, Search, Bell, Settings, Zap, Share2, Users2, Package, ChevronDown, Database, BookOpen, Library, Utensils, ClipboardList, CheckCircle, MessageCircle, ClipboardCheck } from "lucide-react";
import { useState } from "react";

export function DashboardLayout() {
  const location = useLocation();
  const [isClientsDropdownOpen, setIsClientsDropdownOpen] = useState(false);
  const [isTrainingDropdownOpen, setIsTrainingDropdownOpen] = useState(false);
  const [isNutritionDropdownOpen, setIsNutritionDropdownOpen] = useState(false);
  const [isSupplementationDropdownOpen, setIsSupplementationDropdownOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: "check-in",
      title: "New Check-In Submitted",
      message: "Julian Reynolds submitted their weekly check-in",
      time: "5 minutes ago",
      unread: true,
    },
    {
      id: 2,
      type: "message",
      title: "New Message",
      message: "Sarah Williams: 'Quick question about my meal plan...'",
      time: "1 hour ago",
      unread: true,
    },
    {
      id: 3,
      type: "form",
      title: "Form Completed",
      message: "Marcus Chen completed the onboarding questionnaire",
      time: "2 hours ago",
      unread: true,
    },
    {
      id: 4,
      type: "check-in",
      title: "Check-In Reminder",
      message: "3 clients have pending check-ins due today",
      time: "3 hours ago",
      unread: false,
    },
    {
      id: 5,
      type: "message",
      title: "New Message",
      message: "David Thompson: 'Thanks for the workout update!'",
      time: "Yesterday",
      unread: false,
    },
  ]);

  const markAsRead = (id: number) => {
    setNotifications(notifications.map(n =>
      n.id === id ? { ...n, unread: false } : n
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, unread: false })));
  };

  const navItems = [
    { path: "/", label: "Dashboard", icon: LayoutGrid },
    { path: "/training", label: "Training", icon: Dumbbell },
    { path: "/nutrition", label: "Nutrition", icon: Apple },
    { path: "/education", label: "Education", icon: GraduationCap },
    { path: "/supplementation", label: "Supplementation", icon: Pill },
    { path: "/clients", label: "Clients", icon: Users },
    { path: "/forms", label: "Forms", icon: FileText },
    { path: "/social-media", label: "Social Media", icon: Share2 },
    { path: "/team-management", label: "Team Management", icon: Users2 },
    { path: "/packages", label: "Packages", icon: Package },
  ];

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-52 bg-white border-r border-gray-200 flex flex-col">
        {/* Logo */}
        <div className="p-5 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-sm">COMPLETE COACH</div>
              <div className="text-xs text-gray-500">Elevating Fitness Coaching</div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3">
          {navItems.map((item) => {
            if (item.path === "/training") {
              return (
                <div key={item.path}>
                  <button
                    onClick={() => setIsTrainingDropdownOpen(!isTrainingDropdownOpen)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition-colors ${
                      isActive(item.path)
                        ? "bg-indigo-50 text-indigo-600"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="text-sm flex-1 text-left">{item.label}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform ${
                        isTrainingDropdownOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {isTrainingDropdownOpen && (
                    <div className="ml-4 mt-1 space-y-1">
                      <Link
                        to="/training/programs"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/training/programs"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <Library className="w-4 h-4" />
                        <span className="text-sm">Training Programs</span>
                      </Link>
                      <Link
                        to="/training/exercises"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/training/exercises"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <BookOpen className="w-4 h-4" />
                        <span className="text-sm">Exercise Database</span>
                      </Link>
                    </div>
                  )}
                </div>
              );
            }

            if (item.path === "/nutrition") {
              return (
                <div key={item.path}>
                  <button
                    onClick={() => setIsNutritionDropdownOpen(!isNutritionDropdownOpen)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition-colors ${
                      isActive(item.path)
                        ? "bg-indigo-50 text-indigo-600"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="text-sm flex-1 text-left">{item.label}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform ${
                        isNutritionDropdownOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {isNutritionDropdownOpen && (
                    <div className="ml-4 mt-1 space-y-1">
                      <Link
                        to="/nutrition/meal-plans"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/nutrition/meal-plans"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <Utensils className="w-4 h-4" />
                        <span className="text-sm">Meal Plans</span>
                      </Link>
                      <Link
                        to="/nutrition/food-database"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/nutrition/food-database"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <Database className="w-4 h-4" />
                        <span className="text-sm">Food Database</span>
                      </Link>
                    </div>
                  )}
                </div>
              );
            }

            if (item.path === "/supplementation") {
              return (
                <div key={item.path}>
                  <button
                    onClick={() => setIsSupplementationDropdownOpen(!isSupplementationDropdownOpen)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition-colors ${
                      isActive(item.path)
                        ? "bg-indigo-50 text-indigo-600"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="text-sm flex-1 text-left">{item.label}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform ${
                        isSupplementationDropdownOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {isSupplementationDropdownOpen && (
                    <div className="ml-4 mt-1 space-y-1">
                      <Link
                        to="/supplementation/plans"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/supplementation/plans"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <ClipboardList className="w-4 h-4" />
                        <span className="text-sm">Supplement Plans</span>
                      </Link>
                      <Link
                        to="/supplementation/database"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/supplementation/database"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <Database className="w-4 h-4" />
                        <span className="text-sm">Supplement Database</span>
                      </Link>
                    </div>
                  )}
                </div>
              );
            }

            if (item.path === "/clients") {
              return (
                <div key={item.path}>
                  <button
                    onClick={() => setIsClientsDropdownOpen(!isClientsDropdownOpen)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition-colors ${
                      isActive(item.path)
                        ? "bg-indigo-50 text-indigo-600"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="text-sm flex-1 text-left">{item.label}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform ${
                        isClientsDropdownOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {isClientsDropdownOpen && (
                    <div className="ml-4 mt-1 space-y-1">
                      <Link
                        to="/clients"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/clients"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <Users className="w-4 h-4" />
                        <span className="text-sm">All Clients</span>
                      </Link>
                      <Link
                        to="/clients/check-ins"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/clients/check-ins"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-sm">Check-Ins</span>
                      </Link>
                      <Link
                        to="/clients/crm"
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                          location.pathname === "/clients/crm"
                            ? "bg-indigo-50 text-indigo-600"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <Database className="w-4 h-4" />
                        <span className="text-sm">CRM</span>
                      </Link>
                    </div>
                  )}
                </div>
              );
            }

            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition-colors ${
                  isActive(item.path)
                    ? "bg-indigo-50 text-indigo-600"
                    : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span className="text-sm">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Coach Profile */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center gap-3 mb-3">
            <img
              src="https://images.unsplash.com/photo-1525296416200-59aaed194d0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwcHJvZmVzc2lvbmFsJTIwd29tYW58ZW58MXx8fHwxNzc2NjcxMzc4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Coach Sarah"
              className="w-10 h-10 rounded-full object-cover"
            />
            <div className="flex-1">
              <div className="text-sm font-medium">Coach Sarah</div>
              <div className="text-xs text-gray-500">Head Curator</div>
            </div>
          </div>
          <button className="w-full bg-indigo-600 text-white text-sm py-2.5 rounded-lg hover:bg-indigo-700 transition-colors">
            + New Client
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold"></h1>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search tasks, clients, or pipeline"
                className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm w-80 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="relative">
              <button
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative"
              >
                <Bell className="w-5 h-5 text-gray-600" />
                {notifications.some(n => n.unread) && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
                )}
              </button>

              {isNotificationsOpen && (
                <>
                  <div
                    className="fixed inset-0 z-30"
                    onClick={() => setIsNotificationsOpen(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 w-96 bg-white border border-gray-200 rounded-xl shadow-xl z-40 max-h-[500px] overflow-hidden flex flex-col">
                    {/* Header */}
                    <div className="p-4 border-b border-gray-200">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-bold text-gray-900">Notifications</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
                            {notifications.filter(n => n.unread).length} New
                          </span>
                          {notifications.some(n => n.unread) && (
                            <button
                              onClick={markAllAsRead}
                              className="text-xs text-indigo-600 hover:text-indigo-700 font-medium"
                            >
                              Mark All Read
                            </button>
                          )}
                        </div>
                      </div>
                      <p className="text-xs text-gray-500">Stay updated on client activity</p>
                    </div>

                    {/* Notifications List */}
                    <div className="flex-1 overflow-y-auto">
                      {notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors ${
                            notification.unread ? "bg-indigo-50/50" : ""
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                              notification.type === "check-in"
                                ? "bg-green-100"
                                : notification.type === "message"
                                ? "bg-blue-100"
                                : "bg-purple-100"
                            }`}>
                              {notification.type === "check-in" ? (
                                <CheckCircle className={`w-5 h-5 ${
                                  notification.type === "check-in" ? "text-green-600" : ""
                                }`} />
                              ) : notification.type === "message" ? (
                                <MessageCircle className="w-5 h-5 text-blue-600" />
                              ) : (
                                <ClipboardCheck className="w-5 h-5 text-purple-600" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 mb-1">
                                <h4 className="font-semibold text-sm text-gray-900">
                                  {notification.title}
                                </h4>
                                {notification.unread && (
                                  <div className="w-2 h-2 bg-indigo-600 rounded-full flex-shrink-0 mt-1"></div>
                                )}
                              </div>
                              <p className="text-sm text-gray-600 mb-1">{notification.message}</p>
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-gray-400">{notification.time}</span>
                                {notification.unread && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      markAsRead(notification.id);
                                    }}
                                    className="text-xs text-indigo-600 hover:text-indigo-700 font-medium"
                                  >
                                    Mark as Read
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Footer */}
                    <div className="p-3 border-t border-gray-200 bg-gray-50">
                      <button className="w-full text-center text-sm text-indigo-600 hover:text-indigo-700 font-medium">
                        View All Notifications
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <Settings className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
