import { Search, Filter, Play, Star, Target, ChevronDown, Plus } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router";

export function ExerciseDatabasePage() {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const categories = ["All", "Chest", "Back", "Quads", "Hamstrings", "Shoulders", "Abs", "Core"];

  const exercises = [
    {
      id: 1,
      name: "High-Bar Back Squat",
      category: "Quads",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&h=300&fit=crop",
      videos: 3,
      variations: 5,
    },
    {
      id: 2,
      name: "Incline DB Press",
      category: "Chest",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop",
      videos: 2,
      variations: 4,
    },
    {
      id: 3,
      name: "Wide-Grip Pull-Ups",
      category: "Back",
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&h=300&fit=crop",
      videos: 4,
      variations: 3,
    },
    {
      id: 4,
      name: "Seated Cable Row",
      category: "Back",
      rating: 4.6,
      image: "https://images.unsplash.com/photo-1605296867424-35fc25c9212a?w=400&h=300&fit=crop",
      videos: 2,
      variations: 6,
    },
    {
      id: 5,
      name: "Bulgarian Split Squat",
      category: "Quads",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&h=300&fit=crop",
      videos: 3,
      variations: 4,
    },
    {
      id: 6,
      name: "Hanging Knee Raises",
      category: "Abs",
      rating: 4.5,
      image: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=300&fit=crop",
      videos: 2,
      variations: 3,
    },
    {
      id: 7,
      name: "Conventional Deadlift",
      category: "Hamstrings",
      rating: 5.0,
      image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=300&fit=crop",
      videos: 5,
      variations: 7,
    },
    {
      id: 8,
      name: "Military Push-Up",
      category: "Chest",
      rating: 4.4,
      image: "https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&h=300&fit=crop",
      videos: 2,
      variations: 8,
    },
  ];

  const filteredExercises = exercises
    .filter(ex => selectedCategory === "All" || ex.category === selectedCategory)
    .filter(ex =>
      ex.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ex.category.toLowerCase().includes(searchQuery.toLowerCase())
    );

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-3xl font-bold mb-2">The Movement Vault</h2>
            <p className="text-gray-600">
              A curated collection of biomechanically optimized demonstrations. Filter by anatomical target or equipment consistency to build safe programming.
            </p>
          </div>
          <button
            onClick={() => navigate("/training/exercises/add")}
            className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Exercise
          </button>
        </div>
      </div>

      {/* Filter Pills */}
      <div className="flex items-center gap-3 mb-8">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedCategory === category
                ? "bg-orange-500 text-white"
                : "bg-white text-gray-700 border border-gray-200 hover:border-orange-300"
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Action Bar */}
      <div className="flex items-center gap-4 mb-8">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search exercises..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-white hover:bg-gray-50 transition-colors">
            <Target className="w-4 h-4" />
            Muscle
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-white hover:bg-gray-50 transition-colors">
            <Filter className="w-4 h-4" />
            Favorites
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-white hover:bg-gray-50 transition-colors">
            <Play className="w-4 h-4" />
            Exercises
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-white hover:bg-gray-50 transition-colors">
            <Filter className="w-4 h-4" />
            Latest
          </button>
        </div>
      </div>

      {/* Exercise Grid */}
      <div className="grid grid-cols-4 gap-6">
        {filteredExercises.map((exercise) => (
          <div
            key={exercise.id}
            className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg hover:border-indigo-300 transition-all cursor-pointer group"
          >
            {/* Exercise Image */}
            <div className="relative h-48 bg-gray-900 overflow-hidden">
              <img
                src={exercise.image}
                alt={exercise.name}
                className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute top-3 right-3 bg-black/50 backdrop-blur-sm px-2 py-1 rounded flex items-center gap-1 text-white">
                <Play className="w-3 h-3" />
                <span className="text-xs">{exercise.videos}</span>
              </div>
            </div>

            {/* Exercise Info */}
            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold text-gray-900 flex-1">{exercise.name}</h3>
                <button className="p-1 hover:bg-yellow-50 rounded transition-colors">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                </button>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded">
                  {exercise.category}
                </span>
                <div className="flex items-center gap-1">
                  <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                  <span className="text-xs text-gray-600">{exercise.rating}</span>
                </div>
              </div>
              <p className="text-xs text-gray-500">
                {exercise.variations} variations available
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Load More */}
      <div className="mt-8 text-center">
        <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm flex items-center gap-1 mx-auto">
          Explore More Movements
          <ChevronDown className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
