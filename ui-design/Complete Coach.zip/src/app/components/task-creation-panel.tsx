import { useState } from "react";
import { X, Calendar as CalendarIcon, Flag } from "lucide-react";
import { Calendar } from "./ui/calendar";
import { format } from "date-fns";

interface TaskCreationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateTask?: (task: {
    text: string;
    date: Date | undefined;
    priority: "high" | "medium" | "low";
    category: string;
  }) => void;
}

export function TaskCreationPanel({ isOpen, onClose, onCreateTask }: TaskCreationPanelProps) {
  const [taskText, setTaskText] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [showCalendar, setShowCalendar] = useState(false);
  const [priority, setPriority] = useState<"high" | "medium" | "low">("medium");
  const [category, setCategory] = useState("client-leads");

  const categories = [
    { value: "client-leads", label: "Client Leads" },
    { value: "current-client-care", label: "Current Client Care" },
    { value: "business-operations", label: "Business / Operations" },
    { value: "social-media", label: "Social Media" },
  ];

  const handleCreate = () => {
    if (!taskText.trim()) return;

    if (onCreateTask) {
      onCreateTask({
        text: taskText,
        date: selectedDate,
        priority,
        category,
      });
    }

    // Reset form
    setTaskText("");
    setSelectedDate(undefined);
    setPriority("medium");
    setCategory("client-leads");
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Slide-in Panel */}
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-lg bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-1">Create New Task</h2>
            <p className="text-orange-100 text-sm">Add a task to your workload</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto h-[calc(100%-140px)]">
          {/* Task Description */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Task Description
            </label>
            <textarea
              value={taskText}
              onChange={(e) => setTaskText(e.target.value)}
              placeholder="Enter task details..."
              className="w-full p-3 border border-gray-300 rounded-lg text-sm resize-none focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              rows={4}
            />
          </div>

          {/* Category Selection */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Category
            </label>
            <div className="grid grid-cols-2 gap-3">
              {categories.map((cat) => (
                <button
                  key={cat.value}
                  onClick={() => setCategory(cat.value)}
                  className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                    category === cat.value
                      ? "border-orange-500 bg-orange-50 text-orange-700"
                      : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Priority Selection */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Priority
            </label>
            <div className="flex gap-3">
              <button
                onClick={() => setPriority("high")}
                className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                  priority === "high"
                    ? "border-red-500 bg-red-50 text-red-700"
                    : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
                }`}
              >
                <Flag className="w-4 h-4" />
                High
              </button>
              <button
                onClick={() => setPriority("medium")}
                className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                  priority === "medium"
                    ? "border-yellow-500 bg-yellow-50 text-yellow-700"
                    : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
                }`}
              >
                <Flag className="w-4 h-4" />
                Medium
              </button>
              <button
                onClick={() => setPriority("low")}
                className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                  priority === "low"
                    ? "border-green-500 bg-green-50 text-green-700"
                    : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
                }`}
              >
                <Flag className="w-4 h-4" />
                Low
              </button>
            </div>
          </div>

          {/* Date Selection */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Due Date (Optional)
            </label>
            <div className="relative">
              <button
                onClick={() => setShowCalendar(!showCalendar)}
                className="w-full flex items-center gap-3 p-3 border border-gray-300 rounded-lg text-sm hover:border-orange-400 transition-colors bg-white"
              >
                <CalendarIcon className="w-5 h-5 text-gray-500" />
                <span className={selectedDate ? "text-gray-900" : "text-gray-500"}>
                  {selectedDate ? format(selectedDate, "MMMM dd, yyyy") : "Select a date"}
                </span>
              </button>

              {showCalendar && (
                <div className="absolute top-full left-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-xl z-10 p-3">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-sm">Select Due Date</h3>
                    <button
                      onClick={() => setShowCalendar(false)}
                      className="p-1 hover:bg-gray-100 rounded transition-colors"
                    >
                      <X className="w-4 h-4 text-gray-500" />
                    </button>
                  </div>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => {
                      setSelectedDate(date);
                      setShowCalendar(false);
                    }}
                    className="rounded-lg"
                  />
                  {selectedDate && (
                    <button
                      onClick={() => {
                        setSelectedDate(undefined);
                        setShowCalendar(false);
                      }}
                      className="w-full mt-2 py-2 text-sm text-red-600 hover:bg-red-50 rounded transition-colors"
                    >
                      Clear Date
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="absolute bottom-0 left-0 right-0 p-6 bg-gray-50 border-t border-gray-200">
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleCreate}
              disabled={!taskText.trim()}
              className="flex-1 px-4 py-3 bg-orange-600 text-white rounded-lg text-sm font-medium hover:bg-orange-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Task
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
