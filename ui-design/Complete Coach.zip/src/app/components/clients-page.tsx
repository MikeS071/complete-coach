import { Search, Filter, Eye, MoreVertical, Upload, Download, ChevronDown, Check } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";
import { useNavigate } from "react-router";

export function ClientsPage() {
  const navigate = useNavigate();
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "archived" | "new" | "deactivated">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const [sortAZ, setSortAZ] = useState(false);
  const [filterByCheckInDay, setFilterByCheckInDay] = useState<string[]>([]);

  const athletes = [
    {
      id: 1,
      name: "Marcus Rodriguez",
      package: "Elite Performance",
      compliance: 96,
      checkInDay: "Monday",
      latestCheckIn: "Apr 14, 2026",
      image: "https://images.unsplash.com/photo-1530029081-120107a0c377?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRpYyUyMG1hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc3NjY3MzYyMnww&ixlib=rb-4.1.0&q=80&w=1080",
      status: "active",
      startDate: "Jan 15, 2026"
    },
    {
      id: 2,
      name: "Emma Thompson",
      package: "Standard Package",
      compliance: 88,
      checkInDay: "Tuesday",
      latestCheckIn: "Apr 15, 2026",
      image: "https://images.unsplash.com/photo-1580058572462-98e2c0e0e2f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRpYyUyMHdvbWFuJTIwZml0bmVzc3xlbnwxfHx8fDE3NzY2NzM2MjN8MA&ixlib=rb-4.1.0&q=80&w=1080",
      status: "active",
      startDate: "Feb 3, 2026"
    },
    {
      id: 3,
      name: "David Chen",
      package: "Premium Package",
      compliance: 92,
      checkInDay: "Wednesday",
      latestCheckIn: "Apr 16, 2026",
      image: "https://images.unsplash.com/photo-1769535348343-1efdd2eb5f3f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGF0aGxldGUlMjBtYWxlfGVufDF8fHx8MTc3NjY3MzYyM3ww&ixlib=rb-4.1.0&q=80&w=1080",
      status: "active",
      startDate: "Dec 10, 2025"
    },
    {
      id: 4,
      name: "Sarah Martinez",
      package: "Standard Package",
      compliance: 84,
      checkInDay: "Thursday",
      latestCheckIn: "Apr 17, 2026",
      image: "https://images.unsplash.com/photo-1597079997518-cd1fa15d42e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwd29tYW4lMjBzdHJvbmd8ZW58MXx8fHwxNzc2NjczNjIzfDA&ixlib=rb-4.1.0&q=80&w=1080",
      status: "new",
      startDate: "Apr 14, 2026"
    },
    {
      id: 5,
      name: "James Wilson",
      package: "Elite Performance",
      compliance: 78,
      checkInDay: "Friday",
      latestCheckIn: "Apr 18, 2026",
      image: "https://images.unsplash.com/photo-1601986313624-28c11ac26334?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRlJTIwbWFuJTIwdHJhaW5pbmd8ZW58MXx8fHwxNzc2NjczNjIzfDA&ixlib=rb-4.1.0&q=80&w=1080",
      status: "deactivated",
      startDate: "Nov 20, 2025"
    },
    {
      id: 6,
      name: "Jessica Taylor",
      package: "Premium Package",
      compliance: 94,
      checkInDay: "Saturday",
      latestCheckIn: "Apr 19, 2026",
      image: "https://images.unsplash.com/photo-1692197174597-1d85555c9b33?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBhdGhsZXRlJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzc2NjczNjI0fDA&ixlib=rb-4.1.0&q=80&w=1080",
      status: "active",
      startDate: "Feb 15, 2026"
    },
    {
      id: 7,
      name: "Michael Brown",
      package: "Standard Package",
      compliance: 90,
      checkInDay: "Sunday",
      latestCheckIn: "Apr 20, 2026",
      image: "https://images.unsplash.com/photo-1622214661964-6c7298b5ffd0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcG9ydHMlMjBtYW4lMjBtdXNjdWxhcnxlbnwxfHx8fDE3NzY2NzM2MjR8MA&ixlib=rb-4.1.0&q=80&w=1080",
      status: "active",
      startDate: "Jan 5, 2026"
    },
    {
      id: 8,
      name: "Ashley Davis",
      package: "Elite Performance",
      compliance: 86,
      checkInDay: "Monday",
      latestCheckIn: "Apr 14, 2026",
      image: "https://images.unsplash.com/photo-1648863397001-cd77a7e98bd8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwYXRobGV0ZSUyMHdvbWFufGVufDF8fHx8MTc3NjY3MzYyNXww&ixlib=rb-4.1.0&q=80&w=1080",
      status: "new",
      startDate: "Apr 16, 2026"
    },
    {
      id: 9,
      name: "Robert Lee",
      package: "Premium Package",
      compliance: 82,
      checkInDay: "Tuesday",
      latestCheckIn: "Apr 15, 2026",
      image: "https://images.unsplash.com/photo-1601986313624-28c11ac26334?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRlJTIwbWFuJTIwdHJhaW5pbmd8ZW58MXx8fHwxNzc2NjczNjIzfDA&ixlib=rb-4.1.0&q=80&w=1080",
      status: "archived",
      startDate: "Aug 5, 2025"
    }
  ];

  const checkInDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  const toggleCheckInDay = (day: string) => {
    setFilterByCheckInDay(prev => 
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  // Apply filters and sorting
  let filteredAthletes = athletes.filter(athlete => {
    const matchesSearch = athlete.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === "all" || athlete.status === filterStatus;
    const matchesCheckInDay = filterByCheckInDay.length === 0 || filterByCheckInDay.includes(athlete.checkInDay);
    return matchesSearch && matchesStatus && matchesCheckInDay;
  });

  // Sort A-Z if enabled
  if (sortAZ) {
    filteredAthletes = [...filteredAthletes].sort((a, b) => a.name.localeCompare(b.name));
  }

  const totalClients = athletes.length;
  const activeClients = athletes.filter(a => a.status === "active").length;
  
  // Calculate new clients this week (clients added in current calendar week)
  const today = new Date("2026-04-20"); // Monday, April 20, 2026
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay() + 1); // Monday of this week
  
  const newClientsThisWeek = athletes.filter(a => {
    const startDate = new Date(a.startDate);
    return startDate >= startOfWeek && startDate <= today;
  }).length;
  
  const checkInsDue = 7;

  // Handle CSV export
  const handleExport = () => {
    const csvContent = [
      ["Name", "Package", "Compliance", "Check-in Day", "Latest Check-in", "Status", "Start Date"],
      ...filteredAthletes.map(a => [
        a.name,
        a.package,
        `${a.compliance}%`,
        a.checkInDay,
        a.latestCheckIn,
        a.status,
        a.startDate
      ])
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `clients-export-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  // Handle CSV import (placeholder)
  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        // In a real app, you would parse the CSV and update the data
        alert(`Import feature: Would import ${file.name}`);
      }
    };
    input.click();
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Client Roster</h1>
        <p className="text-gray-600">Manage and monitor your client performance</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-sm text-gray-500 mb-2">Total Clients</div>
          <div className="text-4xl font-bold text-indigo-600">{totalClients}</div>
          <div className="text-xs text-gray-500 mt-2">{activeClients} currently active</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-sm text-gray-500 mb-2">New Clients This Week</div>
          <div className="text-4xl font-bold text-green-600">{String(newClientsThisWeek).padStart(2, '0')}</div>
          <div className="text-xs text-gray-500 mt-2">Added this calendar week</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-sm text-gray-500 mb-2">Check-ins Due</div>
          <div className="text-4xl font-bold text-orange-600">{String(checkInsDue).padStart(2, '0')}</div>
          <div className="text-xs text-gray-500 mt-2">Requiring attention</div>
        </div>
      </div>

      {/* Search and Filter Bar */}
      <div className="bg-white rounded-xl p-4 border border-gray-200 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search clients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setFilterStatus("all")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "all"
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterStatus("active")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "active"
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              Active
            </button>
            <button
              onClick={() => setFilterStatus("archived")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "archived"
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              Archived
            </button>
            <button
              onClick={() => setFilterStatus("new")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "new"
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              New
            </button>
            <button
              onClick={() => setFilterStatus("deactivated")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterStatus === "deactivated"
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              Deactivated
            </button>

            {/* Filter Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowFilterDropdown(!showFilterDropdown)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 flex items-center gap-2 transition-colors"
              >
                <Filter className="w-4 h-4" />
                Filter
                <ChevronDown className="w-4 h-4" />
              </button>
              {showFilterDropdown && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 p-3 z-10">
                  <div className="mb-3 pb-3 border-b border-gray-200">
                    <button
                      onClick={() => setSortAZ(!sortAZ)}
                      className="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors"
                    >
                      <span className="text-sm text-gray-700">Sort A-Z</span>
                      {sortAZ && <Check className="w-4 h-4 text-indigo-600" />}
                    </button>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-gray-500 uppercase mb-2 px-2">
                      Check-in Day
                    </div>
                    {checkInDays.map(day => (
                      <button
                        key={day}
                        onClick={() => toggleCheckInDay(day)}
                        className="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <span className="text-sm text-gray-700">{day}</span>
                        {filterByCheckInDay.includes(day) && (
                          <Check className="w-4 h-4 text-indigo-600" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Import/Export Button */}
            <div className="relative">
              <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 flex items-center gap-2 transition-colors group">
                <Upload className="w-4 h-4" />
                <Download className="w-4 h-4" />
                <ChevronDown className="w-4 h-4" />
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 p-2 z-10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                <button
                  onClick={handleImport}
                  className="w-full flex items-center gap-2 p-2 hover:bg-gray-50 rounded-lg transition-colors text-left"
                >
                  <Upload className="w-4 h-4 text-gray-600" />
                  <span className="text-sm text-gray-700">Import CSV</span>
                </button>
                <button
                  onClick={handleExport}
                  className="w-full flex items-center gap-2 p-2 hover:bg-gray-50 rounded-lg transition-colors text-left"
                >
                  <Download className="w-4 h-4 text-gray-600" />
                  <span className="text-sm text-gray-700">Export CSV</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Clients List */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {/* Table Header */}
        <div className="grid grid-cols-12 gap-4 px-6 py-4 bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-700">
          <div className="col-span-3">Client</div>
          <div className="col-span-2">Package</div>
          <div className="col-span-2">Compliance Score</div>
          <div className="col-span-2">Check-in Day</div>
          <div className="col-span-2">Latest Check-in</div>
          <div className="col-span-1">Actions</div>
        </div>

        {/* Table Body */}
        <div className="divide-y divide-gray-200">
          {filteredAthletes.map((athlete) => (
            <div
              key={athlete.id}
              onClick={() => navigate(`/clients/${athlete.id}`)}
              className="grid grid-cols-12 gap-4 px-6 py-4 items-center hover:bg-gray-50 transition-colors cursor-pointer"
            >
              {/* Client Info */}
              <div className="col-span-3 flex items-center gap-3">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 flex-shrink-0">
                  <ImageWithFallback
                    src={athlete.image}
                    alt={athlete.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="font-medium text-gray-900">{athlete.name}</div>
                  <div className="text-xs text-gray-500">{athlete.startDate}</div>
                </div>
              </div>

              {/* Package */}
              <div className="col-span-2">
                <div className="text-sm text-gray-900">{athlete.package}</div>
              </div>

              {/* Compliance Score */}
              <div className="col-span-2">
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        athlete.compliance >= 90
                          ? "bg-green-500"
                          : athlete.compliance >= 80
                          ? "bg-orange-500"
                          : "bg-red-500"
                      }`}
                      style={{ width: `${athlete.compliance}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-700 w-10">
                    {athlete.compliance}%
                  </span>
                </div>
              </div>

              {/* Check-in Day */}
              <div className="col-span-2">
                <div className="text-sm text-gray-700">{athlete.checkInDay}</div>
              </div>

              {/* Latest Check-in */}
              <div className="col-span-2">
                <div className="text-sm text-gray-700">{athlete.latestCheckIn}</div>
              </div>

              {/* Actions */}
              <div className="col-span-1 flex items-center gap-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/clients/${athlete.id}`);
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Eye className="w-4 h-4 text-gray-600" />
                </button>
                <button 
                  onClick={(e) => e.stopPropagation()}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <MoreVertical className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* No Results */}
      {filteredAthletes.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-200 mt-6">
          <p className="text-gray-500">No clients found matching your filters.</p>
        </div>
      )}
    </div>
  );
}