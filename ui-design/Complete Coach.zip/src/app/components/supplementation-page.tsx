import { Plus, Search, Filter, Package, TrendingUp, Users, ShoppingCart } from "lucide-react";

export function SupplementationPage() {
  const protocols = [
    {
      id: 1,
      name: "Performance Stack",
      supplements: ["Creatine Monohydrate", "Beta-Alanine", "Citrulline Malate", "Caffeine"],
      clients: 22,
      adherence: 85,
      category: "Performance",
    },
    {
      id: 2,
      name: "Recovery Essentials",
      supplements: ["Whey Protein", "Omega-3", "Vitamin D", "Magnesium"],
      clients: 30,
      adherence: 92,
      category: "Recovery",
    },
    {
      id: 3,
      name: "Endurance Support",
      supplements: ["Electrolytes", "BCAAs", "Iron", "B-Complex"],
      clients: 15,
      adherence: 78,
      category: "Endurance",
    },
    {
      id: 4,
      name: "Joint Health Protocol",
      supplements: ["Glucosamine", "Chondroitin", "Collagen", "Turmeric"],
      clients: 12,
      adherence: 88,
      category: "Health",
    },
  ];

  const inventory = [
    { name: "Creatine Monohydrate", stock: 45, reorder: 20, unit: "bottles" },
    { name: "Whey Protein Isolate", stock: 12, reorder: 30, unit: "bottles" },
    { name: "Omega-3 Fish Oil", stock: 67, reorder: 25, unit: "bottles" },
    { name: "Vitamin D3", stock: 8, reorder: 15, unit: "bottles" },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold mb-2">Supplementation</h2>
          <p className="text-gray-600">Manage supplement protocols and track athlete compliance</p>
        </div>
        <button className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Create Protocol
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
              <Package className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">79</div>
          <div className="text-sm text-gray-600">Active Protocols</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">86%</div>
          <div className="text-sm text-gray-600">Avg. Adherence</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">79</div>
          <div className="text-sm text-gray-600">Athletes Enrolled</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
              <ShoppingCart className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-1">4</div>
          <div className="text-sm text-gray-600">Items Low Stock</div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search protocols..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <Filter className="w-4 h-4" />
          Filters
        </button>
      </div>

      {/* Protocols Grid */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        {protocols.map((protocol) => (
          <div key={protocol.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-40 bg-gradient-to-br from-purple-500 to-pink-600 relative overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1763668331599-487470fb85b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXBwbGVtZW50cyUyMHZpdGFtaW5zJTIwYm90dGxlc3xlbnwxfHx8fDE3NzY2NzE0Njl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt={protocol.name}
                className="w-full h-full object-cover opacity-40"
              />
              <div className="absolute top-4 left-4 bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
                {protocol.category}
              </div>
              <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
                {protocol.clients} athletes
              </div>
            </div>
            <div className="p-6">
              <h3 className="font-bold text-lg mb-3">{protocol.name}</h3>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Supplements</div>
                <div className="flex flex-wrap gap-2">
                  {protocol.supplements.map((supp, i) => (
                    <span key={i} className="bg-white border border-gray-200 px-2 py-1 rounded text-xs">
                      {supp}
                    </span>
                  ))}
                </div>
              </div>
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Adherence Rate</span>
                  <span className="font-medium text-green-600">{protocol.adherence}%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div
                    className="bg-green-600 h-2 rounded-full transition-all"
                    style={{ width: `${protocol.adherence}%` }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors">
                  Manage Protocol
                </button>
                <button className="px-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  Edit
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Inventory Management */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-bold text-lg">Inventory Status</h3>
          <button className="text-indigo-600 hover:text-indigo-700 text-sm font-medium">View Full Inventory</button>
        </div>
        <div className="space-y-4">
          {inventory.map((item, i) => (
            <div key={i} className="flex items-center justify-between py-4 border-b border-gray-100 last:border-0">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <div className="font-medium">{item.name}</div>
                  <div className="text-sm text-gray-500">Reorder at {item.reorder} {item.unit}</div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <div className="font-semibold text-lg">{item.stock}</div>
                  <div className="text-xs text-gray-500">{item.unit} in stock</div>
                </div>
                {item.stock < item.reorder && (
                  <button className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-orange-200 transition-colors">
                    Reorder Now
                  </button>
                )}
                {item.stock >= item.reorder && (
                  <div className="px-4 py-2 bg-green-100 text-green-700 rounded-lg text-sm font-medium">
                    In Stock
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
