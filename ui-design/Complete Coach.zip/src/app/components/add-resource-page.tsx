import { useState } from "react";
import { ChevronLeft, Upload, X } from "lucide-react";
import { useNavigate } from "react-router";

export function AddResourcePage() {
  const navigate = useNavigate();
  const [resourceTitle, setResourceTitle] = useState("");
  const [category, setCategory] = useState("Training");
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState("");
  const [description, setDescription] = useState("");
  const [distribution, setDistribution] = useState<string[]>(["Assign to Clients"]);

  const categories = ["Training", "Nutrition", "Recovery", "Mindset"];
  const distributionOptions = [
    { id: "assign", label: "Assign to Clients", icon: "👥" },
    { id: "library", label: "Add to Library", icon: "📚" },
    { id: "morning", label: "Morning", icon: "☀️" },
    { id: "anytime", label: "Anytime", icon: "⏰" },
  ];

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const toggleDistribution = (option: string) => {
    if (distribution.includes(option)) {
      setDistribution(distribution.filter(d => d !== option));
    } else {
      setDistribution([...distribution, option]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/education")}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold">Educational Vault</h1>
              <p className="text-sm text-gray-500">Learn and optimize your community</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="px-5 py-2.5 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm">
              Manage Resources
            </button>
            <button className="bg-indigo-600 text-white px-5 py-2.5 rounded-lg hover:bg-indigo-700 transition-colors font-medium">
              Publish as Resource
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-3 gap-8">
          {/* Left Column - Upload & Metadata */}
          <div className="col-span-2 space-y-6">
            {/* Upload New Resource */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-sm">📤</span>
                </div>
                <h3 className="font-bold text-gray-900">Upload New Resource</h3>
              </div>

              <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-all cursor-pointer">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-10 h-10 text-gray-400" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Drag files here to start uploading</h4>
                <p className="text-sm text-gray-500 mb-4">Supports PDF, MP4, MOV, JPG, PNG</p>
                <button className="bg-white border border-gray-300 text-gray-700 px-6 py-2.5 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm">
                  Browse Files
                </button>
              </div>
            </div>

            {/* Resource Metadata */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <span className="text-purple-600 font-bold text-sm">📝</span>
                </div>
                <h3 className="font-bold text-gray-900">Resource Metadata</h3>
              </div>

              <div className="space-y-5">
                {/* Resource Title */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Resource Title
                  </label>
                  <input
                    type="text"
                    value={resourceTitle}
                    onChange={(e) => setResourceTitle(e.target.value)}
                    placeholder="e.g. Advanced Hypertrophy Principles PDF"
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Tags */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tags
                  </label>
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {tags.map((tag) => (
                        <div
                          key={tag}
                          className="bg-indigo-100 text-indigo-700 px-3 py-1.5 rounded-full text-sm font-medium flex items-center gap-2"
                        >
                          {tag}
                          <button
                            onClick={() => removeTag(tag)}
                            className="hover:bg-indigo-200 rounded-full p-0.5 transition-colors"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newTag}
                        onChange={(e) => setNewTag(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && addTag()}
                        placeholder="hypertrophy, strength, recovery, diet..."
                        className="flex-1 p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                      <button
                        onClick={addTag}
                        className="px-5 py-3 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm font-medium transition-colors"
                      >
                        Add Tag
                      </button>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (optional)
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Briefly describe what this resource covers and who should use it"
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    rows={4}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Distribution & Preview */}
          <div className="space-y-6">
            {/* Distribution */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <span className="text-green-600 font-bold text-sm">🎯</span>
                </div>
                <h3 className="font-bold text-gray-900">Distribution</h3>
              </div>

              <div className="space-y-3">
                {distributionOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => toggleDistribution(option.label)}
                    className={`w-full flex items-center gap-3 p-4 rounded-lg border-2 transition-all ${
                      distribution.includes(option.label)
                        ? "border-indigo-500 bg-indigo-50"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <span className="text-2xl">{option.icon}</span>
                    <div className="flex-1 text-left">
                      <div className={`font-medium text-sm ${
                        distribution.includes(option.label) ? "text-indigo-700" : "text-gray-900"
                      }`}>
                        {option.label}
                      </div>
                    </div>
                    {distribution.includes(option.label) && (
                      <div className="w-5 h-5 bg-indigo-600 rounded-full flex items-center justify-center">
                        <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Live Preview */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <span className="text-indigo-600 font-bold text-sm">👁️</span>
                </div>
                <h3 className="font-bold text-gray-900">Live Preview</h3>
              </div>

              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop"
                  alt="Preview"
                  className="w-full h-48 object-cover opacity-80"
                />
                <div className="p-4 bg-gray-800">
                  <h4 className="font-bold text-white mb-1">
                    {resourceTitle || "Resource Title"}
                  </h4>
                  <p className="text-sm text-gray-400">
                    {category} • {tags.length} tag{tags.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
