import { useState } from "react";
import { Search, Send, Phone, Video, MoreVertical, Paperclip, Smile, MessageSquare } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router";

interface Conversation {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unread: number;
  online: boolean;
}

interface Message {
  id: number;
  sender: "coach" | "client";
  text: string;
  time: string;
}

export function MessagesPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const clientIdFromUrl = searchParams.get("client");

  const conversations: Conversation[] = [
    {
      id: "1",
      name: "Sarah Johnson",
      avatar: "https://images.unsplash.com/photo-1689600944138-da3b150d9cb8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHdvbWFuJTIwaGVhZHNob3R8ZW58MXx8fHwxNzc2NjE4NzU1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      lastMessage: "Thanks for the updated meal plan!",
      time: "2m ago",
      unread: 2,
      online: true,
    },
    {
      id: "2",
      name: "Marcus Chen",
      avatar: "https://images.unsplash.com/photo-1577744168855-0391d2ed2b3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwZml0bmVzcyUyMGNvYWNoJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzc2Njc3NTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      lastMessage: "Can we reschedule tomorrow's session?",
      time: "15m ago",
      unread: 1,
      online: true,
    },
    {
      id: "3",
      name: "Emma Rodriguez",
      avatar: "https://images.unsplash.com/photo-1768853972795-2739a9685567?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRpYyUyMHdvbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzc2Njc3NTAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      lastMessage: "Just finished today's workout! 🔥",
      time: "1h ago",
      unread: 0,
      online: false,
    },
    {
      id: "4",
      name: "Jordan Williams",
      avatar: "https://images.unsplash.com/photo-1762753674498-73ec49feafc4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHByb2Zlc3Npb25hbCUyMG1hbiUyMGhlYWRzaG90fGVufDF8fHx8MTc3NjY1NDg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      lastMessage: "Looking forward to the check-in tomorrow",
      time: "3h ago",
      unread: 0,
      online: false,
    },
    {
      id: "5",
      name: "Alex Thompson",
      avatar: "https://images.unsplash.com/photo-1530029081-120107a0c377?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwYXRobGV0ZSUyMHBvcnRyYWl0fGVufDF8fHx8MTc3NjY3MTM3OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      lastMessage: "Protein shake recipe you mentioned?",
      time: "5h ago",
      unread: 0,
      online: true,
    },
  ];

  const [selectedConversation, setSelectedConversation] = useState<string>(
    clientIdFromUrl || conversations[0].id
  );
  const [messageInput, setMessageInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const currentConversation = conversations.find((c) => c.id === selectedConversation);

  const messages: Record<string, Message[]> = {
    "1": [
      { id: 1, sender: "client", text: "Hey! I've been following the meal plan for a week now", time: "10:30 AM" },
      { id: 2, sender: "coach", text: "That's great to hear! How are you feeling so far?", time: "10:32 AM" },
      { id: 3, sender: "client", text: "Much better! Energy levels are up and I'm not feeling as bloated", time: "10:35 AM" },
      { id: 4, sender: "coach", text: "Perfect! That's exactly what we want to see. Keep it up! 💪", time: "10:36 AM" },
      { id: 5, sender: "client", text: "Thanks for the updated meal plan!", time: "11:45 AM" },
    ],
    "2": [
      { id: 1, sender: "client", text: "Hi coach, I have a scheduling conflict tomorrow", time: "9:15 AM" },
      { id: 2, sender: "coach", text: "No problem! What time works better for you?", time: "9:20 AM" },
      { id: 3, sender: "client", text: "Can we reschedule tomorrow's session?", time: "9:25 AM" },
    ],
    "3": [
      { id: 1, sender: "client", text: "Just finished today's workout! 🔥", time: "2:30 PM" },
      { id: 2, sender: "coach", text: "Amazing work! How did the HIIT section feel?", time: "2:35 PM" },
      { id: 3, sender: "client", text: "Challenging but I pushed through!", time: "2:40 PM" },
    ],
    "4": [
      { id: 1, sender: "client", text: "Ready for tomorrow's check-in!", time: "Yesterday" },
      { id: 2, sender: "coach", text: "Great! Make sure to take your progress photos", time: "Yesterday" },
      { id: 3, sender: "client", text: "Looking forward to the check-in tomorrow", time: "Today" },
    ],
    "5": [
      { id: 1, sender: "client", text: "What was that protein shake recipe you mentioned?", time: "8:00 AM" },
      { id: 2, sender: "coach", text: "1 scoop whey, 1 banana, 1 tbsp peanut butter, almond milk", time: "8:05 AM" },
      { id: 3, sender: "client", text: "Protein shake recipe you mentioned?", time: "8:10 AM" },
    ],
  };

  const currentMessages = messages[selectedConversation] || [];

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      // In a real app, this would send the message to the backend
      setMessageInput("");
    }
  };

  const filteredConversations = conversations.filter((conv) =>
    conv.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-[calc(100vh-88px)]">
      {/* Conversations Sidebar */}
      <div className="w-96 bg-white border-r border-gray-200 flex flex-col">
        {/* Search Header */}
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-2xl font-bold mb-4">Messages</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.map((conversation) => (
            <div
              key={conversation.id}
              onClick={() => setSelectedConversation(conversation.id)}
              className={`p-4 border-b border-gray-100 cursor-pointer transition-colors ${
                selectedConversation === conversation.id
                  ? "bg-indigo-50 border-l-4 border-l-indigo-600"
                  : "hover:bg-gray-50"
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="relative flex-shrink-0">
                  <img
                    src={conversation.avatar}
                    alt={conversation.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  {conversation.online && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-sm truncate">{conversation.name}</h3>
                    <span className="text-xs text-gray-500 flex-shrink-0 ml-2">{conversation.time}</span>
                  </div>
                  <p className="text-sm text-gray-600 truncate">{conversation.lastMessage}</p>
                </div>
                {conversation.unread > 0 && (
                  <div className="flex-shrink-0 w-5 h-5 bg-indigo-600 text-white text-xs rounded-full flex items-center justify-center">
                    {conversation.unread}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Message Thread */}
      <div className="flex-1 flex flex-col bg-gray-50">
        {currentConversation ? (
          <>
            {/* Chat Header */}
            <div className="bg-white border-b border-gray-200 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src={currentConversation.avatar}
                    alt={currentConversation.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  {currentConversation.online && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                  )}
                </div>
                <div>
                  <h3 className="font-semibold">{currentConversation.name}</h3>
                  <p className="text-xs text-gray-500">
                    {currentConversation.online ? "Active now" : "Offline"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <Phone className="w-5 h-5 text-gray-600" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <Video className="w-5 h-5 text-gray-600" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <MoreVertical className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {currentMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === "coach" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-md ${
                      message.sender === "coach"
                        ? "bg-indigo-600 text-white"
                        : "bg-white text-gray-900 border border-gray-200"
                    } rounded-2xl px-4 py-3`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.sender === "coach" ? "text-indigo-200" : "text-gray-500"
                      }`}
                    >
                      {message.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <div className="bg-white border-t border-gray-200 p-4">
              <div className="flex items-end gap-3">
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0">
                  <Paperclip className="w-5 h-5 text-gray-600" />
                </button>
                <div className="flex-1 relative">
                  <textarea
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    placeholder="Type a message..."
                    rows={1}
                    className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:border-indigo-500 resize-none"
                  />
                  <button className="absolute right-3 bottom-3 hover:bg-gray-100 rounded-lg p-1 transition-colors">
                    <Smile className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
                <button
                  onClick={handleSendMessage}
                  className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex-shrink-0 flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Send
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p>Select a conversation to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
