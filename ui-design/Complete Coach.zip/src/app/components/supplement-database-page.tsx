import { useState } from "react";
import { Search, Plus, X } from "lucide-react";

interface Supplement {
  id: string;
  name: string;
  category: string;
  timing: string;
  dosage: string;
  image: string;
}

export function SupplementDatabasePage() {
  const [showAddPanel, setShowAddPanel] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [supplements, setSupplements] = useState<Supplement[]>([
    {
      id: "1",
      name: "Magnesium Glycinate",
      category: "Evening",
      timing: "Once evening",
      dosage: "400mg",
      image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=200&h=200&fit=crop",
    },
    {
      id: "2",
      name: "Creatine Monohydrate",
      category: "Anytime",
      timing: "Once anytime",
      dosage: "5g",
      image: "https://images.unsplash.com/photo-1579722820308-d746b13b215b?w=200&h=200&fit=crop",
    },
    {
      id: "3",
      name: "Omega-3 High EPA",
      category: "Morning",
      timing: "Twice with meals",
      dosage: "2g",
      image: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=200&h=200&fit=crop",
    },
  ]);

  const [newSupplement, setNewSupplement] = useState({
    name: "",
    category: "",
    timing: "",
    dosage: "",
  });

  const handleAddSupplement = () => {
    if (!newSupplement.name) return;

    const supplement: Supplement = {
      id: String(supplements.length + 1),
      name: newSupplement.name,
      category: newSupplement.category || "Custom",
      timing: newSupplement.timing || "As needed",
      dosage: newSupplement.dosage || "Variable",
      image: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=200&h=200&fit=crop",
    };

    setSupplements([...supplements, supplement]);
    setNewSupplement({ name: "", category: "", timing: "", dosage: "" });
    setShowAddPanel(false);
  };

  const filteredSupplements = supplements.filter(supplement =>
    supplement.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    supplement.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-3xl font-bold">Supplementation Library</h2>
              <span className="bg-purple-100 text-purple-700 text-xs px-3 py-1 rounded-full font-medium uppercase">
                Master Compendium
              </span>
            </div>
            <p className="text-gray-600">
              Manage your entire protocol for performance and recovery. Curate precise methodology for data-optimized client results.
            </p>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-500 uppercase tracking-wider mb-2">Total Entries</div>
              <div className="text-4xl font-bold text-indigo-600">{supplements.length}</div>
            </div>
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center">
              <span className="text-2xl">💊</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-500 uppercase tracking-wider mb-2">Categories</div>
              <div className="text-4xl font-bold text-purple-600">18</div>
            </div>
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
              <span className="text-2xl">📋</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Bar */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search supplements or protocols..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button
          onClick={() => setShowAddPanel(true)}
          className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Entry
        </button>
      </div>

      {/* Supplements Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">Supplements & Nutrients</h3>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {filteredSupplements.map((supplement) => (
            <div
              key={supplement.id}
              className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg hover:border-indigo-300 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gray-900 rounded-lg overflow-hidden flex-shrink-0">
                  <img
                    src={supplement.image}
                    alt={supplement.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-gray-900 truncate">{supplement.name}</h4>
                  <p className="text-xs text-gray-500">{supplement.dosage}</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${
                      supplement.category === "Evening" ? "bg-blue-600" :
                      supplement.category === "Morning" ? "bg-orange-500" :
                      "bg-purple-600"
                    }`} />
                    <span className="text-gray-600">{supplement.category}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Timing</span>
                  <span className="text-gray-900 font-medium">{supplement.timing}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add New Supplement Slide-In Panel */}
      {showAddPanel && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 transition-opacity"
            onClick={() => setShowAddPanel(false)}
          />

          {/* Slide-in Panel */}
          <div className="fixed top-0 right-0 h-full w-full max-w-lg bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold mb-1">New Protocol</h2>
                <p className="text-indigo-100 text-sm">Add supplement to library</p>
              </div>
              <button
                onClick={() => setShowAddPanel(false)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto h-[calc(100%-200px)]">
              {/* Supplement Name */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Supplement Name
                </label>
                <input
                  type="text"
                  value={newSupplement.name}
                  onChange={(e) => setNewSupplement({ ...newSupplement, name: e.target.value })}
                  placeholder="e.g., Vitamin D3"
                  className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Category */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Supplement Category
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {["Morning", "Evening", "Anytime"].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setNewSupplement({ ...newSupplement, category: cat })}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        newSupplement.category === cat
                          ? "border-indigo-500 bg-indigo-50 text-indigo-700"
                          : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
                      }`}
                    >
                      <div className="flex items-center justify-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          cat === "Morning" ? "bg-orange-500" :
                          cat === "Evening" ? "bg-blue-600" :
                          "bg-purple-600"
                        }`} />
                        {cat}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Optimal Timing */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Optimal Timing
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {["Morning", "Mid-day", "Evening", "Anytime"].map((timing) => (
                    <button
                      key={timing}
                      onClick={() => setNewSupplement({ ...newSupplement, timing: `Once ${timing.toLowerCase()}` })}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        newSupplement.timing === `Once ${timing.toLowerCase()}`
                          ? "border-indigo-500 bg-indigo-50 text-indigo-700"
                          : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
                      }`}
                    >
                      {timing}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dosage */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Standard Dosage
                </label>
                <input
                  type="text"
                  value={newSupplement.dosage}
                  onChange={(e) => setNewSupplement({ ...newSupplement, dosage: e.target.value })}
                  placeholder="e.g., 5000 IU"
                  className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Time & Schedule */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Time & Schedule
                </label>
                <textarea
                  placeholder="Add optional timing instructions or special considerations..."
                  className="w-full p-3 border border-gray-300 rounded-lg text-sm resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  rows={4}
                />
              </div>
            </div>

            {/* Footer Actions */}
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-gray-50 border-t border-gray-200">
              <div className="flex gap-3">
                <button
                  onClick={() => setShowAddPanel(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  Save as Draft
                </button>
                <button
                  onClick={handleAddSupplement}
                  disabled={!newSupplement.name}
                  className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Create Protocol
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
