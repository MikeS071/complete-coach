import { createBrowserRouter } from "react-router";
import { DashboardLayout } from "./components/dashboard-layout";
import { DashboardPage } from "./components/dashboard-page";
import { TrainingPage } from "./components/training-page";
import { NutritionPage } from "./components/nutrition-page";
import { EducationPage } from "./components/education-page";
import { AddResourcePage } from "./components/add-resource-page";
import { SupplementationPage } from "./components/supplementation-page";
import { ClientsPage } from "./components/clients-page";
import { ClientProfile } from "./components/client-profile";
import { CheckInManagementPage } from "./components/check-in-management-page";
import { FormsPage } from "./components/forms-page";
import { SocialMediaPage } from "./components/social-media-page";
import { TeamManagementPage } from "./components/team-management-page";
import { PackagesPage } from "./components/packages-page";
import { MessagesPage } from "./components/messages-page";
import { CRMPage } from "./components/crm-page";
import { TrainingProgramsPage } from "./components/training-programs-page";
import { ExerciseDatabasePage } from "./components/exercise-database-page";
import { AddExercisePage } from "./components/add-exercise-page";
import { MealPlansPage } from "./components/meal-plans-page";
import { FoodDatabasePage } from "./components/food-database-page";
import { SupplementPlansPage } from "./components/supplement-plans-page";
import { SupplementDatabasePage } from "./components/supplement-database-page";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: DashboardLayout,
    children: [
      { index: true, Component: DashboardPage },
      { path: "training", Component: TrainingPage },
      { path: "training/programs", Component: TrainingProgramsPage },
      { path: "training/exercises", Component: ExerciseDatabasePage },
      { path: "training/exercises/add", Component: AddExercisePage },
      { path: "nutrition", Component: NutritionPage },
      { path: "nutrition/meal-plans", Component: MealPlansPage },
      { path: "nutrition/food-database", Component: FoodDatabasePage },
      { path: "education", Component: EducationPage },
      { path: "education/add", Component: AddResourcePage },
      { path: "supplementation", Component: SupplementationPage },
      { path: "supplementation/plans", Component: SupplementPlansPage },
      { path: "supplementation/database", Component: SupplementDatabasePage },
      { path: "clients", Component: ClientsPage },
      { path: "clients/crm", Component: CRMPage },
      { path: "clients/check-ins", Component: CheckInManagementPage },
      { path: "clients/:id", Component: ClientProfile },
      { path: "forms", Component: FormsPage },
      { path: "social-media", Component: SocialMediaPage },
      { path: "team-management", Component: TeamManagementPage },
      { path: "packages", Component: PackagesPage },
      { path: "messages", Component: MessagesPage },
    ],
  },
]);
